$('.sl').slick({
	autoplay: true,
	autoplaySpeed: 2500,
	dots: true
});

$(document).ready (function () {
	$('#form').validate({   
	rules:{
		"email":{
			required:true,
			email:true
		}
	},
	messages:{
		"email":{
			required:"Проверьте свой E-mail",
			 email:"Неправильный E-mail"
			}
		},
		submitHandler: function(form){
			$(form).ajaxSubmit({
				success: function() {
					swal("Ваше сообщение отправлено!");
				} 
			});
		}
	});
});

var App = angular.module('route', ['ngRoute'])
.factory('pagination', function( $sce ) {
	var currentPage = 0;
	var itemsPerPage = 14;
	var products = [];
	return {
		setProducts: function( newProducts ) {
			products = newProducts
		},
		getPageProducts: function(num) {
			var num = angular.isUndefined(num) ? 0 : num;
			var first = itemsPerPage * num;
			var last = first + itemsPerPage;
			currentPage = num;
			last = last > products.length ? products.length : last;
			return products.slice(first, last);
		},
		getTotalPagesNum: function() {
			return Math.ceil( products.length / itemsPerPage );
		},
		getPaginationList: function() {
			var pagesNum = this.getTotalPagesNum();
			var paginationList = [];
			paginationList.push({
				name: $sce.trustAsHtml('&laquo;'),
				link: 'prev'
			});
			for (var i = 0; i < pagesNum; i++) {
				var name = i + 1;
				paginationList.push({
					name: $sce.trustAsHtml( String(name) ),
					link: i
				});
			};
			paginationList.push({
				name: $sce.trustAsHtml('&raquo;'),
				link: 'next'
			});
			if (pagesNum > 2) {
				return paginationList;
			}else {
				return null;
			}
		},
		getPrevPageProducts: function() {
			var prevPageNum = currentPage - 1;
			if ( prevPageNum < 0 ) prevPageNum = 0;
			return this.getPageProducts( prevPageNum );
		},
		getNextPageProducts: function() {
			var nextPageNum = currentPage + 1;
			var pagesNum = this.getTotalPagesNum();
			if ( nextPageNum >= pagesNum ) nextPageNum = pagesNum - 1;
			return this.getPageProducts( nextPageNum );
		},
		getCurrentPageNum: function() {
			return currentPage;
		},
	}
});

$('#search').keypress(function(e){
	if(e.keyCode==13){
		document.location.href = "#/search";
	}
});

App.config(['$routeProvider', function($routeProvide) {
	$routeProvide
	.when('/',{
		templateUrl:'temp/main.html',
		controller:'MainController'
	})
	.when('/room',{
		templateUrl:'temp/room.html',
		controller:'RoomController'
	})
	.when('/about',{
		templateUrl:'temp/about.html',
		controller:'AboutController'
	})
	.when('/contact',{
		templateUrl:'temp/contact.html',
		controller:'ContactController'
	})
	.when('/search',{
		templateUrl:'temp/search.html',
		controller:'SearchController'
	})
	.otherwise({
		redirectTo: '/'
	});
}]);

App.controller('MainController', function( $scope, $http, pagination ){
	document.documentElement.scrollTop = 0;
	$http.get('articles.json').success(function(data){
		$scope.menuObj = data;
		pagination.setProducts( data.products );
		$scope.products = pagination.getPageProducts( $scope.currentPage );
		$scope.paginationList = pagination.getPaginationList();
	});
	$scope.showPage = function(page) {
		if ( page == 'prev' ) {
			$scope.products = pagination.getPrevPageProducts();
		}else if ( page == 'next' ) {
			$scope.products = pagination.getNextPageProducts();
		}else {
			$scope.products = pagination.getPageProducts( page );
		}
	}
	$scope.currentPageNum = function() {
		return pagination.getCurrentPageNum();
	}
});

App.controller('RoomController', function( $scope, $http, pagination ){
	document.documentElement.scrollTop = 0;
	$http.get('articles.json').success(function(data){
		$scope.menuObj = data;
		pagination.setProducts( data.products );
		$scope.products = pagination.getPageProducts( $scope.currentPage );
		$scope.paginationList = pagination.getPaginationList();
	});
	$scope.showPage = function(page) {
		if ( page == 'prev' ) {
			$scope.products = pagination.getPrevPageProducts();
		}else if ( page == 'next' ) {
			$scope.products = pagination.getNextPageProducts();
		}else {
			$scope.products = pagination.getPageProducts( page );
		}
	}
	$scope.currentPageNum = function() {
		return pagination.getCurrentPageNum();
	}
});

App.controller('AboutController', function( $scope, $http, pagination ){
	document.documentElement.scrollTop = 0;
});

App.controller('ContactController', function( $scope, $http, pagination ){
	document.documentElement.scrollTop = 0;
});

App.controller('SearchController', function( $scope, $http, pagination ){
	$http.get('articles.json').success(function(data){
		$scope.searchs = data;
	});
});