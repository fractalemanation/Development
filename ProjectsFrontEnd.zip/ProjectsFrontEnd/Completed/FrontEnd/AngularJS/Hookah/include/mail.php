﻿<?php
/*$recepient = "mail@gmail.com;
$sitename = "Hookah";

$name = trim($_POST["name"]);
$email = trim($_POST["email"]);
$site = trim($_POST["site"]);
$text = trim($_POST["text"]);
$message = "Name: $name \nE-mail: $email \nSite: $site \nText: $text";

$pagetitle = "New application from the site \"$sitename\"";
mail($recepient, $pagetitle, $message, "From: admin@gmail.com");
mail($email, $pagetitle, "Your review was successfully sent!\n".$message, "From: admin@gmail.com");*/
?>