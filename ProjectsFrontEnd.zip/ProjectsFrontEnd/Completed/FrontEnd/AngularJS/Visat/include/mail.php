﻿<?php
include ('smtp-func.php');
$recepient = "admin@visat-sumy.com";
$sitename = "visat-sumy.com";

$name = trim($_POST["name"]);
$email = trim($_POST["email"]);
$phone = trim($_POST["phone"]);
$text = trim($_POST["text"]);
$message = "Имя: $name \nEmail: $email \nТелефон: $phone \nТекст: $text";

$pagetitle = "Новая заявка с сайта \"$sitename\"";

smtpmail($recepient, $pagetitle, $message, "From: admin@visat-sumy.com");
smtpmail($email, $pagetitle, "Ваш отзыв успешно отправлен!\n".$message, "From: admin@visat-sumy.com");
?>