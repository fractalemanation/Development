<?php
include ('smtp-func.php');
$recepient = "admin@visat-sumy.com";
$sitename = "visat-sumy.com";

$name = trim($_POST["name"]);
$email = trim($_POST["ema"]);
$phone = trim($_POST["phone"]);
$vacancy = trim($_POST["vacanc"]);
$text = trim($_POST["text"]);
$message = "Имя: $name \nEmail: $email \nТелефон: $phone\nКондиционер: $vacancy\nТекст: $text";

$pagetitle = "Новая заявка с сайта \"$sitename\"";

smtpmail($recepient, $pagetitle, $message, "From: admin@visat-sumy.com");
smtpmail($email, $pagetitle, "Ваш отзыв успешно отправлен!\n".$message, "From: admin@visat-sumy.com");
?>