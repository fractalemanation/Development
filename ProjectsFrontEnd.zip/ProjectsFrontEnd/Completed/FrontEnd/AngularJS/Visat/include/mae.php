<?php
include ('smtp-func.php');
$recepient = "fractalemanation@gmail.com";
$sitename = "visat-sumy.com";

$name = trim($_POST["name"]);
$email = trim($_POST["emae"]);
$phone = trim($_POST["phone"]);
$vacancy = trim($_POST["vacance"]);
$text = trim($_POST["text"]);
$message = "Имя: $name \nEmail: $email \nТелефон: $phone\Оборудование: $vacancy\nТекст: $text";

$pagetitle = "Новая заявка с сайта \"$sitename\"";

smtpmail($recepient, $pagetitle, $message, "From: admin@visat-sumy.com");
smtpmail($email, $pagetitle, "Ваш отзыв успешно отправлен!\n".$message, "From: admin@visat-sumy.com");
?>