$('.sl').slick({
	autoplay: true,
	autoplaySpeed: 2500
});

$('.sl1').slick({
	autoplay: true,
	autoplaySpeed: 2500,
	centerMode: true,
	centerPadding: '200px'
});

$('.geolm').click(function() {
	$('#ifm1').slideDown();
});
$('#del1').click(function() {
	$('#ifm1').fadeOut();
});

$(document).ready(function() {  
$('#form').validate({   
rules:{
	"reg_captcha":{
		required:true,
		remote: {
			type: "post",
			url: "/include/check_captcha.php"
		}
	},
	"email":{
		required:true,
		email:true
	}
},
messages:{
	"reg_captcha":{
		required:"Введите код!",
		remote: "Неверный код!"
	},
	"email":{
		required:"Укажите свой E-mail",
		 email:"Не корректный E-mail"
		}
	},
	submitHandler: function(form){
		$(form).ajaxSubmit({
			success: function() {
				swal("Ваше сообщение успешно отправлено!");
				$('#block-captcha > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
				$(".cvalue").val("");
			} 
		});
	}
});
});

$('#reloadcaptcha').click(function() {
	$('#block-captcha > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
});

$(document).ready(function() {  
$('#form1').validate({   
rules:{
	"reg_captch":{
		required:true,
		remote: {
			type: "post",
			url: "/include/check_captch.php"
		}
	},
	"emai":{
		required:true,
		email:true
	}
},
messages:{
	"reg_captch":{
		required:"Введите код!",
		remote: "Неверный код!"
	},
	"emai":{
		required:"Укажите свой E-mail",
		 email:"Не корректный E-mail"
		}
	},
	submitHandler: function(form){
		$(form).ajaxSubmit({
			success: function() {
				swal("Ваше сообщение успешно отправлено!");
				$('#block-captcha > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
				$(".cvalue").val("");
			} 
		});
	}
});
});

$('#reloadcaptch').click(function() {
	$('#block-captch > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
});

$(document).ready(function() {  
$('#form2').validate({   
rules:{
	"reg_captc":{
		required:true,
		remote: {
			type: "post",
			url: "/include/check_captc.php"
		}
	},
	"ema":{
		required:true,
		email:true
	}
},
messages:{
	"reg_captc":{
		required:"Введите код!",
		remote: "Неверный код!"
	},
	"ema":{
		required:"Укажите свой E-mail",
		 email:"Не корректный E-mail"
		}
	},
	submitHandler: function(form){
		$(form).ajaxSubmit({
			success: function() {
				swal("Ваше сообщение успешно отправлено!");
				$('#block-captc > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
				$(".cvalue").val("");
			} 
		});
	}
});
});

$('#reloadcaptc').click(function() {
	$('#block-captc > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
});

$(document).ready(function() {  
$('#form3').validate({   
rules:{
	"reg_captche":{
		required:true,
		remote: {
			type: "post",
			url: "/include/check_captche.php"
		}
	},
	"emae":{
		required:true,
		email:true
	}
},
messages:{
	"reg_captche":{
		required:"Введите код!",
		remote: "Неверный код!"
	},
	"emae":{
		required:"Укажите свой E-mail",
		 email:"Не корректный E-mail"
		}
	},
	submitHandler: function(form){
		$(form).ajaxSubmit({
			success: function() {
				swal("Ваше сообщение успешно отправлено!");
				$('#block-captche > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
				$(".cvalue").val("");
			} 
		});
	}
});
});

$('#reloadcaptche').click(function() {
	$('#block-captche > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
});

var app = angular.module('app', ['ngRoute']);
app.config(['$routeProvider', function($routeProvide) {
	$routeProvide
	.when('/',{
		templateUrl:'temp/main.html',
		controller:'Ctrl'
	})
	.when('/equipment',{
		templateUrl:'temp/equipment.html',
		controller:'EquipmentCtrl'
	})
	.when('/antens',{
		templateUrl:'temp/ant.html',
		controller:'AntCtrl'
	})
	.when('/tv',{
		templateUrl:'temp/tv.html',
		controller:'TableCtrl'
	})
	.when('/kondicionery',{
		templateUrl:'temp/kon.html',
		controller:'KonCtrl'
	})
	.when('/InstKondicionery',{
		templateUrl:'temp/instkon.html',
		controller:'Inst'
	})
	.when('/feedback',{
		templateUrl:'temp/back.html',
		controller:'Back'
	})
	.otherwise({
		redirectTo: '/'
	});
}]);
app.controller('Ctrl',['$scope','$http','$location', function($scope, $http, $location) {
	document.documentElement.scrollTop = 0;
	$scope.vacance = '';
	$http.get('adminPanel/equipment.json').success(function(data, status, headers, config) {
		$scope.equipments = data;
		$scope.image = data[0].images[0].src;
	});
	$scope.setImage = function (img) {
		$scope.image = img;
		$('.gallery').slideDown();
	}
	$scope.closeImage = function () {
		$('.gallery').slideUp();
	}
	$scope.eslide = function (equip) {
		$('#block-dre').slideDown();
		$scope.vacance = equip;
	}
	$scope.ehslide = function () {
		$('#block-dre').fadeOut();
	}
}]);
app.controller('Inst',['$scope','$http','$location', function($scope, $http, $location) {
	document.documentElement.scrollTop = 0;
}]);
app.controller('Back',['$scope','$http','$location', function($scope, $http, $location) {
	document.documentElement.scrollTop = 0;
}]);
app.controller('TableCtrl',['$scope','$http','$location', function($scope, $http, $location) {
	document.documentElement.scrollTop = 0;
	$http.get('adminPanel/item1.json').success(function(data, status, headers, config) {
		$scope.phones1 = data;
	});
	$http.get('adminPanel/item2.json').success(function(data, status, headers, config) {
		$scope.phones2 = data;
	});
	$http.get('adminPanel/item3.json').success(function(data, status, headers, config) {
		$scope.phones3 = data;
	});
}]);
app.controller('EquipmentCtrl',['$scope','$http','$location', function($scope, $http, $location) {
	document.documentElement.scrollTop = 0;
	$scope.vacance = '';
	$http.get('adminPanel/equipment.json').success(function(data, status, headers, config) {
		$scope.equipments = data;
		$scope.image = data[0].images[0].src;
	});
	$scope.setImage = function (img) {
		$scope.image = img;
		$('.gallery').slideDown();
	}
	$scope.closeImage = function () {
		$('.gallery').slideUp();
	}
	$scope.eslide = function (equip) {
		$('#block-dre').slideDown();
		$scope.vacance = equip;
	}
	$scope.ehslide = function () {
		$('#block-dre').fadeOut();
	}
}]);
app.controller('AntCtrl',['$scope','$http','$location', function($scope, $http, $location) {
	document.documentElement.scrollTop = 0;
	$scope.vacancy = '';
	$http.get('adminPanel/antens.json').success(function(data, status, headers, config) {
		$scope.antens = data;
	});
	$scope.slide = function (anten) {
		$('#block-dr').slideDown();
		$scope.vacancy = anten;
	}
	$scope.hslide = function () {
		$('#block-dr').fadeOut();
	}
}]);
app.controller('KonCtrl',['$scope','$http','$location', function($scope, $http, $location) {
	document.documentElement.scrollTop = 0;
	$scope.vacanc = '';
	$http.get('adminPanel/konds.json').success(function(data, status, headers, config) {
		$scope.konds = data;
	});
	$scope.kslide = function (kon) {
		$('#block-dr1').slideDown ();
		$scope.vacanc = kon;
	}
	$scope.khslide = function () {
		$('#block-dr1').fadeOut();
	}
}]);