$('.sl').slick({
	autoplay: true,
	autoplaySpeed: 7500
});

(function($) {
  var $li = $('.img-list').find('> li'),
      $links = $li.find('> a'),
      $lightbox = $('.lightbox'),
      $next = $('.next'),
      $prev = $('.prev'),
      $overlay = $('.overlay'),
      liIndex,
      targetImg;
  
  var imgSources = [
  'images/img-1-lg.jpg',
  'images/img-2-lg.jpg',
  'images/img-3-lg.jpg',
  'images/img-4-lg.jpg'
  ];

  var imgs = [];
  for (var i = 0; i < imgSources.length; i++) {
    imgs[i] = new Image();
    imgs[i].src = imgSources[i];
  }

  function replaceImg(src) {
    $lightbox.find('img').attr('src', src);
  }

  function getHref(index) {
    return $li.eq(index).find('>a').attr('href');
  }

  function closeLigtbox() {
    $lightbox.fadeOut();
  }

  $overlay.click(closeLigtbox);

  $links.click(function(e) {
    e.preventDefault();
    targetImg = $(this).attr('href');
    liIndex = $(this).parent().index();
    replaceImg(targetImg);
    $lightbox.fadeIn();
  });

   $next.click( function() {  
    if ( (liIndex + 1) < $li.length ) { 
      targetImg = getHref(liIndex + 1);
      liIndex ++;
    } else {
      targetImg = getHref(0);
      liIndex = 0;
    }
    replaceImg(targetImg);
  });

   $prev.click( function() {  
    if ( (liIndex) > 0 ) { 
      targetImg = getHref(liIndex - 1);
      liIndex --;
    } else {
      targetImg = getHref($li.length - 1);
      liIndex = $li.length - 1;
    }
    replaceImg(targetImg);
  });
  
})(jQuery);

$('#search').keypress(function(e){
	if(e.keyCode==13){
		document.location.href = "#/search";
	}
});

var i = localStorage.length;
	 
var app = angular.module('app', ['ngRoute'])
.factory('pagination', function( $sce ) {
	var currentPage = 0;
	var itemsPerPage = 24;
	var products = [];
	return {
		setProducts: function( newProducts ) {
			products = newProducts
		},
		getPageProducts: function(num) {
			var num = angular.isUndefined(num) ? 0 : num;
			var first = itemsPerPage * num;
			var last = first + itemsPerPage;
			currentPage = num;
			last = last > products.length ? products.length : last;
			return products.slice(first, last);
		},
		getTotalPagesNum: function() {
			return Math.ceil( products.length / itemsPerPage );
		},
		getPaginationList: function() {
			var pagesNum = this.getTotalPagesNum();
			var paginationList = [];
			paginationList.push({
				name: $sce.trustAsHtml('&laquo;'),
				link: 'prev'
			});
			for (var i = 0; i < pagesNum; i++) {
				var name = i + 1;
				paginationList.push({
					name: $sce.trustAsHtml( String(name) ),
					link: i
				});
			};
			paginationList.push({
				name: $sce.trustAsHtml('&raquo;'),
				link: 'next'
			});
			if (pagesNum > 2) {
				return paginationList;
			}else {
				return null;
			}
		},
		getPrevPageProducts: function() {
			var prevPageNum = currentPage - 1;
			if ( prevPageNum < 0 ) prevPageNum = 0;
			return this.getPageProducts( prevPageNum );
		},
		getNextPageProducts: function() {
			var nextPageNum = currentPage + 1;
			var pagesNum = this.getTotalPagesNum();
			if ( nextPageNum >= pagesNum ) nextPageNum = pagesNum - 1;
			return this.getPageProducts( nextPageNum );
		},
		getCurrentPageNum: function() {
			return currentPage;
		},
	}
});

app.config(['$routeProvider', function($routeProvide) {
	$routeProvide
	.when('/',{
		templateUrl:'temp/main.html',
		controller:'Ctrl'
	})
	.when('/actors',{
		templateUrl:'temp/actors.html',
		controller:'ACtrl'
	})
	.when('/producers',{
		templateUrl:'temp/producers.html',
		controller:'PCtrl'
	})
	.when('/crime',{
		templateUrl:'temp/crime.html',
		controller:'Ctrl'
	})
	.when('/fantastic',{
		templateUrl:'temp/fantastic.html',
		controller:'Ctrl'
	})
	.when('/horror',{
		templateUrl:'temp/horror.html',
		controller:'Ctrl'
	})
	.when('/action',{
		templateUrl:'temp/action.html',
		controller:'Ctrl'
	})
	.when('/adventure',{
		templateUrl:'temp/adventure.html',
		controller:'Ctrl'
	})
	.when('/comedy',{
		templateUrl:'temp/comedy.html',
		controller:'Ctrl'
	})
	.when('/drama',{
		templateUrl:'temp/drama.html',
		controller:'Ctrl'
	})
	.when('/melodrama',{
		templateUrl:'temp/melodrama.html',
		controller:'Ctrl'
	})
	.when('/historical',{
		templateUrl:'temp/historical.html',
		controller:'Ctrl'
	})
	.when('/travel',{
		templateUrl:'temp/travel.html',
		controller:'Ctrl'
	})
	.when('/detective',{
		templateUrl:'temp/detective.html',
		controller:'Ctrl'
	})
	.when('/sport',{
		templateUrl:'temp/sport.html',
		controller:'Ctrl'
	})
	.when('/thriller',{
		templateUrl:'temp/thriller.html',
		controller:'Ctrl'
	})
	.when('/fantasy',{
		templateUrl:'temp/fantasy.html',
		controller:'Ctrl'
	})
	.when('/search',{
		templateUrl:'temp/search.html',
		controller:'Search'
	})
	.when('/:itemId',{
		templateUrl:'temp/detail.html',
		controller:'DetailCtrl'
	})
	.when('/actor/:itemId',{
		templateUrl:'temp/detaila.html',
		controller:'DetailsCtrl'
	})
	.when('/producer/:itemId',{
		templateUrl:'temp/detailp.html',
		controller:'DetailsCtrl'
	})
	.otherwise({
		redirectTo: '/'
	});
}]);

app.controller('Ctrl', function( $scope, $http, pagination ){
	document.title = 'Фильмы смотреть онлайн бесплатно в hd качестве';
	$http.get('adminPanel/menu.json').success(function(data){
		$scope.menuObj = data;
		pagination.setProducts( data.products );
		$scope.products = pagination.getPageProducts( $scope.currentPage );
		$scope.paginationList = pagination.getPaginationList();
	});
	
	$scope.showPage = function(page) {
		if ( page == 'prev' ) {
			$scope.products = pagination.getPrevPageProducts();
		}else if ( page == 'next' ) {
			$scope.products = pagination.getNextPageProducts();
		}else {
			$scope.products = pagination.getPageProducts( page );
		}
	}
	$scope.currentPageNum = function() {
		return pagination.getCurrentPageNum();
	};
});

app.controller('ACtrl', function( $scope, $http, pagination ){
	document.title = 'Актеры';
	$http.get('adminPanel/menua.json').success(function(data){
		$scope.menuObj = data;
		pagination.setProducts( data.products );
		$scope.products = pagination.getPageProducts( $scope.currentPage );
		$scope.paginationList = pagination.getPaginationList();
	});
	
	$scope.showPage = function(page) {
		if ( page == 'prev' ) {
			$scope.products = pagination.getPrevPageProducts();
		}else if ( page == 'next' ) {
			$scope.products = pagination.getNextPageProducts();
		}else {
			$scope.products = pagination.getPageProducts( page );
		}
	}
	$scope.currentPageNum = function() {
		return pagination.getCurrentPageNum();
	};
});
app.controller('PCtrl', function( $scope, $http, pagination ){
	document.title = 'Режиссеры';
	$http.get('adminPanel/menup.json').success(function(data){
		$scope.menuObj = data;
		pagination.setProducts( data.products );
		$scope.products = pagination.getPageProducts( $scope.currentPage );
		$scope.paginationList = pagination.getPaginationList();
	});
	
	$scope.showPage = function(page) {
		if ( page == 'prev' ) {
			$scope.products = pagination.getPrevPageProducts();
		}else if ( page == 'next' ) {
			$scope.products = pagination.getNextPageProducts();
		}else {
			$scope.products = pagination.getPageProducts( page );
		}
	}
	$scope.currentPageNum = function() {
		return pagination.getCurrentPageNum();
	};
});

app.controller('DetailCtrl',['$scope','$http','$location', '$routeParams',function($scope,$http,$location,$routeParams) {
	$scope.itemId = $routeParams.itemId;
	var url = 'adminPanel/videos/'+$routeParams.itemId+'.json';
	$http.get(url).success(function(data) {
		$scope.item = data;
		document.title = data.name;
	$scope.func = function () {
		$('#lblockk').append('<a class="litem" id="l'+ localStorage.length +'" href="#/' + $routeParams.itemId + '"><div class="lvideo"><img width="360px" height="200px" src="' + data.limg + '" /><div class="playv">►</div><div class="ltime">' + data.ltime +'</div><div class="ltext">' + data.name + '</div></div></a>');

		var litem = '<a class="litem" id="l'+ localStorage.length +'" href="#/' + $routeParams.itemId + '"><div class="lvideo"><img width="360px" height="200px" src="' + data.limg + '" /><div class="playv">►</div><div class="ltime">' + data.ltime +'</div><div class="ltext">' + data.name + '</div></div></a>';
		localStorage.setItem(i++, litem);
		$("#lmd").hide();
	}
	});
}]);

app.controller('DetailsCtrl',['$scope','$http','$location', '$routeParams',function($scope,$http,$location,$routeParams) {
	$scope.itemId = $routeParams.itemId;

	$http.get('adminPanel/menu.json').success(function(data) {
		$scope.item = data;
	});
}]);

app.controller('Search', function( $scope, $http, pagination ){
	$http.get('adminPanel/menu.json').success(function(data){
		$scope.videos = data;
	});
});

$('.glk').click(function() {
	$('#lblock').slideDown(200);
	$('.glk').hide();
	$('.glks').show();
	for (var i = 0; i <= localStorage.length; i++) $('#lblockk').append(localStorage.getItem(i))
	if (localStorage.length > 4) $("#lmd").hide();
});

$('.glks').click(function() {
	$('#lblock').slideUp(200);
	$('.glks').hide();
	$('.glk').show();
});

$('.removek').click (function () {
	localStorage.clear();
	$('.litem').remove();
	$("#lmd").show();
});

/*$(document).ready(function() {
    $('#block-body').scrollTop(0);
});

window.onload = function() {
	window.scrollTo(0, 0);
}*/
/*$(".removeB").click(function() {
    var id = this.id;
    $('#l'+ id +'').remove();
    localStorage.removeItem(id);
});
<div><div class="removeB" id="'+ localStorage.length +'">Очистить данное видео из корзины</div></div>*/
//setTimeout('if (localStorage.length > 0) $("#lmd").hide()', 2500);