$(function(){
var x;
if(navigator.cookieEnabled){
if($.cookie('lang')&&$("select[name='lang']").val()!==$.cookie('lang')){
x = $.cookie('lang');
$("select[name='lang']").val(x);
$.get('include/json.php',
{lang:x},
function(data){
data = JSON.parse(data);
$('div[class="lang_0"]').html(data["0"]);
$('div[class="lang_1"]').html(data["1"]);
$('div[class="lang_2"]').html(data["2"]);
$('div[class="lang_3"]').html(data["3"]);
$('div[class="lang_4"]').html(data["4"]);
$('div[class="lang_5"]').html(data["5"]);
$('div[class="lang_6"]').html(data["6"]);
$('div[class="lang_7"]').html(data["7"]);
$('div[class="lang_8"]').html(data["8"]);
$('div[class="lang_9"]').html(data["9"]);
$('div[class="lang_10"]').html(data["10"]);
$('div[class="lang_11"]').html(data["11"]);
$('div[class="lang_12"]').html(data["12"]);
$('div[class="lang_13"]').html(data["13"]);
$('div[class="lang_14"]').html(data["14"]);
$('p[class="lang_15"]').html(data["15"]);
$('div[class="lang_16"]').html(data["16"]);
$('div[class="lang_17"]').html(data["17"]);
$('div[class="lang_18"]').html(data["18"]);
$('p[class="lang_19"]').html(data["19"]);
$('p[class="lang_20"]').html(data["20"]);
$('div[class="lang_21"]').html(data["21"]);
$('p[class="lang_22"]').html(data["22"]);
$('p[class="lang_23"]').html(data["23"]);
$('div[class="lang_24"]').html(data["24"]);
$('p[class="lang_25"]').html(data["25"]);
$('p[class="lang_26"]').html(data["26"]);
$('div[class="lang_27"]').html(data["27"]);
$('p[class="lang_28"]').html(data["28"]);
$('div[class="lang_29"]').html(data["29"]);
$('div[class="lang_30"]').html(data["30"]);
$('div[class="lang_31"]').html(data["31"]);
$('div[class="lang_32"]').html(data["32"]);
$('div[class="lang_33"]').html(data["33"]);
$('div[class="lang_34"]').html(data["34"]);
$('div[class="lang_35"]').html(data["35"]);
$('div[class="lang_36"]').html(data["36"]);
$('div[class="lang_37"]').html(data["37"]);
$('div[class="lang_38"]').html(data["38"]);
$('div[class="lang_39"]').html(data["39"]);
$('div[class="lang_40"]').html(data["40"]);
$('div[class="lang_41"]').html(data["41"]);
$('div[class="lang_42"]').html(data["42"]);
$('div[class="lang_43"]').html(data["43"]);
$('div[class="lang_44"]').html(data["44"]);
$('div[class="lang_45"]').html(data["45"]);
$('div[class="lang_46"]').html(data["46"]);
$('div[class="lang_47"]').html(data["47"]);
$('div[class="lang_48"]').html(data["48"]);
$('div[class="lang_49"]').html(data["49"]);
$('div[class="lang_50"]').html(data["50"]);
$('div[class="lang_51"]').html(data["51"]);
$('div[class="lang_52"]').html(data["52"]);
$('div[class="lang_53"]').html(data["53"]);
$('div[class="lang_54"]').html(data["54"]);
$('div[class="lang_55"]').html(data["55"]);
$('div[class="lang_56"]').html(data["56"]);
$('div[class="lang_57"]').html(data["57"]);
$('div[class="lang_58"]').html(data["58"]);
$('div[class="lang_59"]').html(data["59"]);
$('div[class="lang_60"]').html(data["60"]);
$('div[class="lang_61"]').html(data["61"]);
$('div[class="lang_62"]').html(data["62"]);
$('div[class="lang_63"]').html(data["63"]);
$('div[class="lang_64"]').html(data["64"]);
$('div[class="lang_65"]').html(data["65"]);
$('div[class="lang_66"]').html(data["66"]);
$('div[class="lang_67"]').html(data["67"]);
$('div[class="lang_68"]').html(data["68"]);
$('div[class="lang_69"]').html(data["69"]);
$('div[class="lang_70"]').html(data["70"]);
$('div[class="lang_71"]').html(data["71"]);
$('div[class="lang_72"]').html(data["72"]);
$('div[class="lang_73"]').html(data["73"]);
$('div[class="lang_74"]').html(data["74"]);
$('p[class="lang_75"]').html(data["75"]);
});


/*if (x == "1") {
	$('#block-news').show();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
}
else if (x == "2") {
	$('#block-news2').show();
	$('#block-news').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker2").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev2",
	btnNext: "#news-next2",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (x == "3") {
	$('#block-news3').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker3").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev3",
	btnNext: "#news-next3",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (x == "4") {
	$('#block-news4').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news5').hide();
	$("#newsticker4").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev4",
	btnNext: "#news-next4",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (x == "5") {
	$('#block-news5').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$("#newsticker5").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev5",
	btnNext: "#news-next5",
	visible: 3,
	auto: 3000,
	speed: 500
});
}*/


}
}

$("select[name='lang']").on('change', function(){
x = $("select[name='lang']").val();
$.get('include/json.php',
{lang:x},
function(data){
data = JSON.parse(data);
$('div[class="lang_0"]').html(data["0"]);
$('div[class="lang_1"]').html(data["1"]);
$('div[class="lang_2"]').html(data["2"]);
$('div[class="lang_3"]').html(data["3"]);
$('div[class="lang_4"]').html(data["4"]);
$('div[class="lang_5"]').html(data["5"]);
$('div[class="lang_6"]').html(data["6"]);
$('div[class="lang_7"]').html(data["7"]);
$('div[class="lang_8"]').html(data["8"]);
$('div[class="lang_9"]').html(data["9"]);
$('div[class="lang_10"]').html(data["10"]);
$('div[class="lang_11"]').html(data["11"]);
$('div[class="lang_12"]').html(data["12"]);
$('div[class="lang_13"]').html(data["13"]);
$('div[class="lang_14"]').html(data["14"]);
$('p[class="lang_15"]').html(data["15"]);
$('div[class="lang_16"]').html(data["16"]);
$('div[class="lang_17"]').html(data["17"]);
$('div[class="lang_18"]').html(data["18"]);
$('p[class="lang_19"]').html(data["19"]);
$('p[class="lang_20"]').html(data["20"]);
$('div[class="lang_21"]').html(data["21"]);
$('p[class="lang_22"]').html(data["22"]);
$('p[class="lang_23"]').html(data["23"]);
$('div[class="lang_24"]').html(data["24"]);
$('p[class="lang_25"]').html(data["25"]);
$('p[class="lang_26"]').html(data["26"]);
$('div[class="lang_27"]').html(data["27"]);
$('p[class="lang_28"]').html(data["28"]);
$('div[class="lang_29"]').html(data["29"]);
$('div[class="lang_30"]').html(data["30"]);
$('div[class="lang_31"]').html(data["31"]);
$('div[class="lang_32"]').html(data["32"]);
$('div[class="lang_33"]').html(data["33"]);
$('div[class="lang_34"]').html(data["34"]);
$('div[class="lang_35"]').html(data["35"]);
$('div[class="lang_36"]').html(data["36"]);
$('div[class="lang_37"]').html(data["37"]);
$('div[class="lang_38"]').html(data["38"]);
$('div[class="lang_39"]').html(data["39"]);
$('div[class="lang_40"]').html(data["40"]);
$('div[class="lang_41"]').html(data["41"]);
$('div[class="lang_42"]').html(data["42"]);
$('div[class="lang_43"]').html(data["43"]);
$('div[class="lang_44"]').html(data["44"]);
$('div[class="lang_45"]').html(data["45"]);
$('div[class="lang_46"]').html(data["46"]);
$('div[class="lang_47"]').html(data["47"]);
$('div[class="lang_48"]').html(data["48"]);
$('div[class="lang_49"]').html(data["49"]);
$('div[class="lang_50"]').html(data["50"]);
$('div[class="lang_51"]').html(data["51"]);
$('div[class="lang_52"]').html(data["52"]);
$('div[class="lang_53"]').html(data["53"]);
$('div[class="lang_54"]').html(data["54"]);
$('div[class="lang_55"]').html(data["55"]);
$('div[class="lang_56"]').html(data["56"]);
$('div[class="lang_57"]').html(data["57"]);
$('div[class="lang_58"]').html(data["58"]);
$('div[class="lang_59"]').html(data["59"]);
$('div[class="lang_60"]').html(data["60"]);
$('div[class="lang_61"]').html(data["61"]);
$('div[class="lang_62"]').html(data["62"]);
$('div[class="lang_63"]').html(data["63"]);
$('div[class="lang_64"]').html(data["64"]);
$('div[class="lang_65"]').html(data["65"]);
$('div[class="lang_66"]').html(data["66"]);
$('div[class="lang_67"]').html(data["67"]);
$('div[class="lang_68"]').html(data["68"]);
$('div[class="lang_69"]').html(data["69"]);
$('div[class="lang_70"]').html(data["70"]);
$('div[class="lang_71"]').html(data["71"]);
$('div[class="lang_72"]').html(data["72"]);
$('div[class="lang_73"]').html(data["73"]);
$('div[class="lang_74"]').html(data["74"]);
$('p[class="lang_75"]').html(data["75"]);

/*if (x == "1") {
	$('#block-news').show();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
}
else if (x == "2") {
	$('#block-news2').show();
	$('#block-news').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker2").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev2",
	btnNext: "#news-next2",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (x == "3") {
	$('#block-news3').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker3").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev3",
	btnNext: "#news-next3",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (x == "4") {
	$('#block-news4').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news5').hide();
	$("#newsticker4").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev4",
	btnNext: "#news-next4",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (x == "5") {
	$('#block-news5').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$("#newsticker5").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev5",
	btnNext: "#news-next5",
	visible: 3,
	auto: 3000,
	speed: 500
});
}*/

if(navigator.cookieEnabled){
	$.cookie('lang',x, {expires: 365, path:'/'});
}
});
});
});


$(function(){
var s;
if(navigator.cookieEnabled){
if($.cookie('lang')&&$("select[name='lang']").val()!==$.cookie('lang')){
s = $.cookie('lang');

if (s == "1") {
	$('#block-news').show();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
}
else if (s == "2") {
	$('#block-news2').show();
	$('#block-news').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker2").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev2",
	btnNext: "#news-next2",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (s == "3") {
	$('#block-news3').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker3").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev3",
	btnNext: "#news-next3",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (s == "4") {
	$('#block-news4').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news5').hide();
	$("#newsticker4").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev4",
	btnNext: "#news-next4",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (s == "5") {
	$('#block-news5').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$("#newsticker5").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev5",
	btnNext: "#news-next5",
	visible: 3,
	auto: 3000,
	speed: 500
});
}

}
}

$("select[name='lang']").on('change', function(){
s = $("select[name='lang']").val();

if (s == "1") {
	$('#block-news').show();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
}
else if (s == "2") {
	$('#block-news2').show();
	$('#block-news').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker2").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev2",
	btnNext: "#news-next2",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (s == "3") {
	$('#block-news3').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker3").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev3",
	btnNext: "#news-next3",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (s == "4") {
	$('#block-news4').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news5').hide();
	$("#newsticker4").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev4",
	btnNext: "#news-next4",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (s == "5") {
	$('#block-news5').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$("#newsticker5").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev5",
	btnNext: "#news-next5",
	visible: 3,
	auto: 3000,
	speed: 500
});
}

if(navigator.cookieEnabled){
	$.cookie('lang',s, {expires: 365, path:'/'});
}
});
});


$("#block-sort-name").click (function () {
	$("#block-sort-ul").slideToggle(200);
});

$("#block-filter-name1").click (function () {
	$("#block-filter-ul1").slideToggle(200);
});

$("#block-filter-name").click (function () {
	$("#block-filter-ul").slideToggle(200);
});

$("#block-filter-name_2").click (function () {
	$("#block-filter-ul_2").slideToggle(200);
});

$("#block-filter-name_3").click (function () {
	$("#block-filter-ul_3").slideToggle(200);
});

$("#block-filter-name_4").click (function () {
	$("#block-filter-ul_4").slideToggle(200);
});

$('#input-search').bind('textchange', function() {
	var input_search = $("#input-search").val();
	if (input_search.length >= 1 && input_search.length < 150) {
		$.ajax ({
			type: "POST",
			url: "include/search.php",
			data: "text="+input_search,
			dataType: "html",
			cache: false,
			success: function(data) {
				if (data > '') {
					$("#result-search").show().html(data);
				}else {
					$("#result-search").hide();
				}
			}
		});
	}else {
		$("#result-search").hide();
	}
});

$(document).ready(function () {
	$(".dr").bind("click", function () {
		$("#block-dr").slideDown(500);
		var id_row = this.id;
		$('#vacancy option').each(function () {
			if ($(this).val() == id_row) {
				this.selected = true;
				}else {
					this.selected = false;
				}
		});
	});
	$(".hide-dr").bind("click", hidedr);
	function hidedr() {
		$("#block-dr").slideUp(500);
	}
});

$(document).ready(function() {
$(".show").bind("click", show);
$(".shide").bind("click", shide);
$(".hide").bind("click", hide);
function show() {
	$("#navig").show(500);
	$(".show").hide();
	$(".shide").show();
}
function shide(){
		$("#navig").hide(500);
		$(".shide").hide();
		$(".show").show();
}
function hide(){
		$("#navig").hide(500);
		$(".shide").hide();
		$(".show").show();
}
});

$('.geol').click(function() {
	$('#ifm2').slideToggle(500);
	$('#ifm1').hide();
});

$('.geolm').click(function() {
	$('#ifm1').slideToggle(500);
	$('#ifm2').hide();
});

$('#del1').click(function() {
	$('#ifm1').slideUp(400);
});

$('#del2').click(function() {
	$('#ifm2').slideUp(400);
});

$(document).ready(function() {  
$('#form').validate({   
rules:{
                        "reg_captcha":{
                            required:true,
                            remote: {
                            type: "post",    
                            url: "include/check_captcha.php"
							}
							}
							},
					
                    messages:{
                        "reg_captcha":{
                            required:"Введите код!",
                            remote: "Неверный код!"
                        }
                    },
					submitHandler: function(form) {
						$('#form').submit(function () {
						$.ajax({
							type: "POST",
							url: "include/mail.php",
							data: $(this).serialize()
						}).done(function() {
							$(this).find("input").val("");
							swal("Ваше сообщение успешно отправлено!");
							$("#form").trigger("reset");
						});
						return false;
});
					}
});
});

$('#reloadcaptcha').click(function() {
	$('#block-captcha > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
});

$(document).ready(function() {  
$('#for').validate({   
rules:{
                        "reg_captch":{
                            required:true,
                            remote: {
                            type: "post",    
                            url: "include/check_captch.php"
							}
							}
							},
					
                    messages:{
                        "reg_captch":{
                            required:"Введите код!",
                            remote: "Неверный код!"
                        }
                    },
					submitHandler: function(form) {
						$("#for").submit(function() {
							$.ajax({
								type: "POST",
								url: "include/send.php",
								data: $(this).serialize()
								}).done(function() {
									$(this).find("input").val("");
									swal("Ваше сообщение успешно отправлено!");
									$("#for").trigger("reset");
								});
								return false;
});
					}
});
});

$('#reloadcaptch').click(function() {
	$('#block-captch > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
});

$('.sl').slick({
	autoplay: true,
	autoplaySpeed: 2500
});

$("#newsticker").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev",
	btnNext: "#news-next",
	visible: 3,
	auto: 3000,
	speed: 500
});