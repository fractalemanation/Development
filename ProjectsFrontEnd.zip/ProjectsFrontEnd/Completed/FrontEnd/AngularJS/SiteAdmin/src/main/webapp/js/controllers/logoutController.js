siteAdminApp.controller('logoutController', function($scope, $http) {
	logoutToken($http);
	removeTokenAndRedirect();
});