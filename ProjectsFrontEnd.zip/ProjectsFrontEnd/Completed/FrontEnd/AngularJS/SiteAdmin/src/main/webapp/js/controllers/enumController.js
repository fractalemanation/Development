siteAdminApp.controller('enumController', ['$scope', '$http', '$stateParams', '$state', function ($scope, $http, $stateParams, $state) {
    checkToken($http);
    switchTab("#enums_tab");
    $scope.enumName = $stateParams.enumName;
    $scope.enum = {};

   // $("[name='custom-checkbox']").bootstrapSwitch();

    init();

    function init() {

        var avt = 'Bearer ' + localStorage.getItem("id_token");
        $http({
            url: wsBaseUri + "enums/get/" + $scope.enumName,
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.state = response.data;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert(response.data.description);
                    } else if (response.status == 401) {
                        alert("Invalid username or password!");
                    }
                });
    }
}]);