siteAdminApp.controller('addUsersController', ['$scope', '$http', function ($scope, $http) {
    checkToken($http);
    switchTab("#users_tab");
    var Base64 = {
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    encode: function (e) {
        var t = "";
        var n, r, i, s, o, u, a;
        var f = 0;
        e = Base64._utf8_encode(e);
        while (f < e.length) {
            n = e.charCodeAt(f++);
            r = e.charCodeAt(f++);
            i = e.charCodeAt(f++);
            s = n >> 2;
            o = (n & 3) << 4 | r >> 4;
            u = (r & 15) << 2 | i >> 6;
            a = i & 63;
            if (isNaN(r)) {
                u = a = 64
            }
            else if (isNaN(i)) {
                a = 64
            }
            t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a)
        } return t
    },
    decode: function (e) {
        var t = "";
        var n, r, i;
        var s, o, u, a;
        var f = 0;
        e = e.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (f < e.length) {
            s = this._keyStr.indexOf(e.charAt(f++));
            o = this._keyStr.indexOf(e.charAt(f++));
            u = this._keyStr.indexOf(e.charAt(f++));
            a = this._keyStr.indexOf(e.charAt(f++));
            n = s << 2 | o >> 4;
            r = (o & 15) << 4 | u >> 2;
            i = (u & 3) << 6 | a; t = t + String.fromCharCode(n);
            if (u != 64) {
                t = t + String.fromCharCode(r)
            }
            if (a != 64) {
                t = t + String.fromCharCode(i)
            }
        }
        t = Base64._utf8_decode(t); return t
    },
    _utf8_encode: function (e) {
        e = e.replace(/\r\n/g, "\n");
        var t = "";
        for (var n = 0; n < e.length; n++) {
            var r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r)
            }
            else if (r > 127 && r < 2048) {
                t += String.fromCharCode(r >> 6 | 192);
                t += String.fromCharCode(r & 63 | 128)
            }
            else {
                t += String.fromCharCode(r >> 12 | 224);
                t += String.fromCharCode(r >> 6 & 63 | 128);
                t += String.fromCharCode(r & 63 | 128)
            }
        } return t
    },
    _utf8_decode: function (e) {
        var t = "";
        var n = 0;
        var r = c1 = c2 = 0;
        while (n < e.length) {
            r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r);
                n++
            }
            else if (r > 191 && r < 224) {
                c2 = e.charCodeAt(n + 1);
                t += String.fromCharCode((r & 31) << 6 | c2 & 63);
                n += 2
            }
            else {
                c2 = e.charCodeAt(n + 1);
                c3 = e.charCodeAt(n + 2);
                t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
                n += 3
            }
        } return t
    }
}

    var iz1 = 0;
    $scope.addUser = function() {
    var val1 = $('#email').val ();
    var val2 = $('#name').val ();
    var val3 = Base64.encode($('#password').val ());
    val3.slice(0, -1);
    var tval5 = '';
        if ($("#mpl10").prop("checked")) {
            tval5 = "mpl";
        }
        if ($("#pl_manager10").prop("checked")) {
            tval5 = "pl_manager";
        }
        if ($("#ua_manager10").prop("checked")) {
            tval5 = "ua_manager";
        }
        if ($("#agent10").prop("checked")) {
            tval5 = "agent";
        }
        if ($("#pl_manager_agent10").prop("checked")) {
            tval5 = "pl_manager_agent";
        }
        if ($("#ua_manager_agent10").prop("checked")) {
            tval5 = "ua_manager_agent";
        }
        var carts1 = {
        	"email": val1,
            "name": val2,
            "password": val3,
    	    "userRole": tval5
    	};
        //alert (JSON.stringify (carts1)); 
if (val1 == '' || val2 == '' || val3 == '' || tval5 == '') {
	alert ('Заполните всё!');
} else {
	var url7 = "http://admin.merkurij.pl/site-admin-ws/rest/users/create";
	var avt = 'Bearer ' + localStorage.getItem("id_token");

	userAdd();
	function userAdd() {
        $http({
          url : url7,
          method : "POST",
          headers : {
           Authorization : avt,
           'Content-Type' : 'application/json'
          },
          data : carts1
         })
         .then(
           function successCallback(response) {
            alert ('Все успешно добавлено!');
            return true;
           },
           function errorCallback(response) {
            if (response.status == 400) {
                alert (response.data.description);
                alert (JSON.stringify (carts1));
            } else if (response.status == 401) {
                alert ("Invalid username or password!");
            }
            return false;
        });
     }
 }
}
}]);