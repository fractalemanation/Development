siteAdminApp.controller('changeUserPasswordController', [
    '$scope', '$element', 'close', 'user', '$http',
    function ($scope, $element, close, user, $http) {
        checkToken($http);

        $scope.user = user;

        //  This close function doesn't need to use jQuery or bootstrap, because
        //  the button has the 'data-dismiss' attribute.
        $scope.close = function () {
            // close({
            //     template: $scope.template
            // }, 500); // close, but give 500ms for bootstrap to animate

            var avt = 'Bearer ' + localStorage.getItem("id_token");
            var user = $scope.user;
            user.password = Base64.encode($scope.password);

            $http({
                url: wsBaseUri + "users/update_password",
                method: "POST",
                headers: {
                    Authorization: avt,
                    'Content-Type': 'application/json'
                },
                data: user
            })
                .then(
                    function successCallback(response) {
                        alert('Пароль изменен!');
                        $state.go('users');
                    },
                    function errorCallback(response) {
                        if (response.status == 400) {
                            alert(response.data.description);
                        } else if (response.status == 401) {
                            alert("Invalid username or password!");
                        }
                    });
        };

        //  This cancel function must use the bootstrap, 'modal' function because
        //  the doesn't have the 'data-dismiss' attribute.
        $scope.cancel = function () {

            //  Manually hide the modal.
            $element.modal('hide');

            //  Now call close, returning control to the caller.
            // close({
            //     template: null
            // }, 500); // close, but give 500ms for bootstrap to animate
        };
    }]);