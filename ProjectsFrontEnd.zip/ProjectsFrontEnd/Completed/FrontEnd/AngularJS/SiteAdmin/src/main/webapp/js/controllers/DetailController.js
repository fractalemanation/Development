siteAdminApp.controller('DetailController', ['$scope', '$http', '$stateParams', '$state', function ($scope, $http, $stateParams, $state) {
    checkToken($http);
    switchTab("#detail_tab");
    $scope.enumId = $stateParams.enumId;
    $scope.enum = {};

    init();

    function init() {

        var avt = 'Bearer ' + localStorage.getItem("id_token");
        $http({
            url: wsBaseUri + "enums/get/" + $scope.enumId,
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.enum = response.data;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert(response.data.description);
                    } else if (response.status == 401) {
                        alert("Invalid username or password!");
                    }
                });
    }
}]);