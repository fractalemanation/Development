siteAdminApp.controller('addEnumsController', ['$scope', '$http', '$state', function ($scope, $http, $state) {
    checkToken($http);
    switchTab("#enums_tab");

    $scope.enumDetails = [
        {
            'name': "",
            'description': ""
        }
    ];

    $scope.addNew = function (enumDetail) {
        $scope.enumDetails.push({
            'name': "",
            'description': ""
        });
    };

    $scope.remove = function () {
        var newDataList = [];
        $scope.selectedAll = false;
        angular.forEach($scope.enumDetails, function (selected) {
            if (!selected.selected) {
                newDataList.push(selected);
            }
        });
        $scope.enumDetails = newDataList;
    };

    $scope.checkAll = function () {
        angular.forEach($scope.enumDetails, function (enumDetail) {
            enumDetail.selected = $scope.selectedAll;
        });
        if ($scope.selectedAll) {
            $scope.selectedAll = true;
        } else {
            $scope.selectedAll = false;
        }

    };

    $scope.eddEnum = function () {
        var cart = {
            "name": $scope.enumName,
            "description": $scope.enumDescription,
            "values": $scope.enumDetails
        };

        var url7 = "http://admin.merkurij.pl/site-admin-ws/rest/enums/add";
        var avt = 'Bearer ' + localStorage.getItem("id_token");

        $http({
            url: url7,
            method: "POST",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            },
            data: cart
        })
            .then(
                function successCallback(response) {
                    alert('Все успешно добавлено!');
                    $state.go('enums');
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert(response.data.description);
                    } else if (response.status == 401) {
                        alert("Invalid username or password!");
                    }
                });
    }
}]);