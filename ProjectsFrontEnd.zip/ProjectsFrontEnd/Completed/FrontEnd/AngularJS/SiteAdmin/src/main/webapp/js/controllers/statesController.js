siteAdminApp.controller('statesController', function($scope, $http) {
    checkToken($http);
    switchTab("#states_tab");

    var url7 = "http://admin.merkurij.pl/site-admin-ws/rest/states/get_all";
    var avt = 'Bearer ' + localStorage.getItem("id_token");

    mStatesGetAll();
    function mStatesGetAll() {
        $http({
            url : url7,
            method : "GET",
            headers : {
                Authorization : avt,
                'Content-Type' : 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.states = response.data;
                    return true;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert (response.data.description);
                    } else if (response.status == 401) {
                        alert ("Invalid username or password!");
                    }
                    return false;
                });
    }
});
