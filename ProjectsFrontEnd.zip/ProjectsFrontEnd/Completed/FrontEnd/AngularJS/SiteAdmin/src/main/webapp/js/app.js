/*function add1() {
        $('#addd').append('<br/><input class="input" type="text" placeholder="Номер" name="tnumber" /><br/><input class="input" type="text" placeholder="Название" name="fname" /><input class="input" type="text" placeholder="Описание" name="fdesc" /><br /><input type="checkbox" id="req" name="req" /><label for="req">requared</label> <input type="checkbox" id="ns" name="ns" /><label for="ns">notShow</label><br/><input type="checkbox" id="mpl1" name="mpl" /><label for="mpl1">mpl</label> <input type="checkbox" id="pl_manager2" name="pl_manager" /><label for="pl_manager2">pl_manager</label> <input type="checkbox" id="ua_manager3" name="ua_manager" /><label for="ua_manager3">ua_manager</label> <input type="checkbox" id="agent4" name="agent" /><label for="agent4">agent</label> <input type="checkbox" id="pl_manager_agent5" name="pl_manager_agent" /><label for="pl_manager_agent5">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent6" name="ua_manager_agent" /><label for="ua_manager_agent6">ua_manager_agent</label>');
    }*/

//var wsBaseUri = "/site-admin-ws/rest";

var wsBaseUri = "http://admin.merkurij.pl/site-admin-ws/rest/";

var siteAdminApp = angular.module('siteAdminApp',
    ['ui.router', 'ngTable', 'angularModalService']);
siteAdminApp.directive('onlyDigits', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attr, ctrl) {
            function inputValue(val) {
                if (val) {
                    var digits = val.replace(/[^0-9.-]/g, '');

                    if (digits !== val) {
                        ctrl.$setViewValue(digits);
                        ctrl.$render();
                    }
                    return parseFloat(digits);
                }
                return undefined;
            }

            ctrl.$parsers.push(inputValue);
        }
    };
});

siteAdminApp.run(['$http', '$rootScope', function($http, $rootScope) {

    $http({
        url : 'http://admin.merkurij.pl/site-admin-ws/rest/users/get_info',
        method : "GET",
        headers : {
            Authorization : 'Bearer ' + localStorage.getItem("id_token"),
            'Content-Type' : 'application/json'
        }
    })
        .then(
            function successCallback(response) {
                $rootScope.username = response.data.name;
            },
            function errorCallback(response) {

            });
}]);

siteAdminApp.config(function ($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/states');

    $stateProvider
        .state('job_applications', {
            url: '/job_applications',
            templateUrl: './view/job_applications.html',
            controller: 'jobApplicationsController'
        })
        .state('states', {
            url: '/states',
            templateUrl: './view/states.html',
            controller: 'statesController'
        })
        .state('state', {
            url: '/state/:stateId',
            templateUrl: './view/state.html',
            controller: 'stateController'
        })
        .state('addstates', {
            url: '/addstates',
            templateUrl: './view/addstate.html',
            controller: 'addStatesController'
        })
        .state('enums', {
            url: '/enums',
            templateUrl: './view/enums.html',
            controller: 'enumsController'
        })
        .state('addenums', {
            url: '/addenums',
            templateUrl: './view/addenum.html',
            controller: 'addEnumsController'
        })
        .state('transitions', {
            url: '/transitions',
            templateUrl: './view/transitions.html',
            controller: 'transitionsController'
        })
        .state('transition', {
            url: '/transitions/:transitionId',
            templateUrl: './view/transition.html',
            controller: 'transitionController'
        })
        .state('addtransitions', {
            url: '/addtransitions',
            templateUrl: './view/addtransition.html',
            controller: 'addTransitionsController'
        })
        .state('users', {
            url: '/users',
            templateUrl: './view/users.html',
            controller: 'usersController'
        })
        .state('addusers', {
            url: '/addusers',
            templateUrl: './view/adduser.html',
            controller: 'addUsersController'
        })
        .state('enum', {
            url: '/enum/:enumName',
            templateUrl: './view/enum.html',
            controller: 'enumController'
        })
        .state('detail', {
            url: '/detail/:enumId',
            templateUrl: './view/detail.html',
            controller: 'DetailController'
        })
        .state('logout', {
            url: '/logout',
            controller: 'logoutController'
        });

});

//siteAdminApp.service('getVacancys', [ '$http', '$q', function($http, $q) {
//	var deferred = $q.defer();
//	$http.get(wsBaseUri + '/vacancys/get_all').then(function(data) {
//		deferred.resolve(data);
//	}, function(error) {
//		console.log('error ' + error);
//	});
//	return deferred.promise;
//
//} ]);

function switchTab(tab) {
    $("#job_applications_tab").removeAttr("class");
    $("#states_tab").removeAttr("class");
    $("#transitions_tab").removeAttr("class");
    $("#enums_tab").removeAttr("class");
    $("#users_tab").removeAttr("class");
    $("#detail_tab").removeAttr("class");

    $(tab).attr("class", "active");
}