var field = new Array ();
var fap = 0;intval1 = 0;intval2 = 0;intval3 = 0;intval4 = 0;intval5 = 0;intval6 = 0;intval7 = 0;intval8 = 0;intval9 = 0;intval10 = 0;intval11 = 0;
var intvar1 = 0;intvar2 = 0;intvar3 = 0;intvar4 = 0;intvar5 = 0;intvar6 = 0;intvar7 = 0;intvar8 = 0;intvar9 = 0;intvar10 = 0;intvar11 = 0;
var intvalarr1 = 0;intvalarr2 = 0;intvalarr3 = 0;intvalarr4 = 0;intvalarr5 = 0;intvalarr6 = 0;intvalarr7 = 0;intvalarr8 = 0;intvalarr9 = 0;intvalarr10 = 0;intvalarr11 = 0;
var forcheck1 = 0;forcheck2 = 0;forcheck3 = 0;forcheck4 = 0;forcheck5 = 0;forcheck6 = 0;forcheck7 = 0;forcheck8 = 0;
var checkval1 = false;checkval2 = false;checkval3 = false;checkval4 = false;checkval5 = false;checkval6 = false;checkval7 = false;
var remove1 = 0;remove2 = 0;remove3 = 0;remove4 = 0;remove5 = 0;
var asn = 0;asd = 0;asn1 = 0;asd1 = 0;asn2 = 0;asd2 = 0;asn3 = 0;asd3 = 0;asn4 = 0;asd4 = 0;
var imsn = 0;ims = 0;imsn1 = 0;ims1 = 0;imsn2 = 0;ims2 = 0;imsn3 = 0;ims3 = 0;imsn4 = 0;ims4 = 0;
var imds = 0;imdsn = 0;imds1 = 0;imdsn1 = 0;imds2 = 0;imdsn2 = 0;imds3 = 0;imdsn3 = 0;imds4 = 0;imdsn4 = 0;
var iz = 0;
var gle = new Array ();

function addint () {
    $('#idsdobs').append ('<p><input type="checkbox" id="remove1'+ remove1++ +'" /> <input class="input" type="text" name="fmm1number'+ asn++ +'" placeholder="Номер INT" /> <input class="input" type="text" name="fmm1desc'+ asd++ +'" placeholder="Описание INT" /></p>');
}
function addstring () {
    $('#idsdobs').append ('<p><input type="checkbox" id="remove2'+ remove2++ +'" /> <input class="input" type="text" name="fmm2number'+ asn1++ +'" placeholder="Номер STRING" /> <input class="input" type="text" name="fmm2desc'+ asd1++ +'" placeholder="Описание STRING" /></p>');
}
function adddate () {
    $('#idsdobs').append ('<p><input type="checkbox" id="remove3'+ remove3++ +'" /> <input class="input" type="text" name="fmm3number'+ asn2++ +'" placeholder="Номер DATE" /> <input class="input" type="text" name="fmm3desc'+ asd2++ +'" placeholder="Описание DATE" /></p>');
}
function addsse () {
    $('#idsdobs').append ('<p><input type="checkbox" id="remove4'+ remove4++ +'" /> <input class="input" type="text" name="fmm4number'+ asn3++ +'" placeholder="Номер SINGLE_SELECTION_ENUM" /> <input class="input" type="text" name="fmm4desc'+ asd3++ +'" placeholder="Описание SINGLE_SELECTION_ENUM" /></p>');
}
function addmse () {
    $('#idsdobs').append ('<p><input type="checkbox" id="remove5'+ remove5++ +'" /> <input class="input" type="text" name="fmm5number'+ asn4++ +'" placeholder="Номер MULTIPLE_SELECTION_ENUM" /> <input class="input" type="text" name="fmm5desc'+ asd4++ +'" placeholder="Описание MULTIPLE_SELECTION_ENUM" /></p>');
}

siteAdminApp.controller('addTransitionsController', function ($scope, $http, $compile) {
    checkToken($http);
    switchTab("#transitions_tab");

    $scope.svu = 'Выбрать StateIdBefore';
    $scope.svuv = '';
    if (localStorage.length > 1) {
        $scope.svu = localStorage.getItem(1);
        $scope.svuv = localStorage.getItem(1);
    }

    var avt = 'Bearer ' + localStorage.getItem("id_token");
    statesGetList();
    function statesGetList() {
        $http({
            url: "http://admin.merkurij.pl/site-admin-ws/rest/states/get_list",
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.gls = response.data;
                    return true;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert(response.data.description);
                    } else if (response.status == 401) {
                        alert("Invalid username or password!");
                    }
                    return false;
                });
    }
    enumsGetList();
    function enumsGetList() {
        $http({
            url: "http://admin.merkurij.pl/site-admin-ws/rest/enums/get_types",
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.gle = response.data;
                    return true;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert(response.data.description);
                    } else if (response.status == 401) {
                        alert("Invalid username or password!");
                    }
                    return false;
                });
    }
    systemGetList();
    function systemGetList() {
        $http({
            url: "http://admin.merkurij.pl/site-admin-ws/rest/system_fields/get_values",
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.gles = response.data;
                    return true;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert(response.data.description);
                    } else if (response.status == 401) {
                        alert("Invalid username or password!");
                    }
                    return false;
                });
    }

    $scope.INT = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tnumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fname'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fdesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label></p>');
        checkval1 = true;
    }
    $scope.STRING = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tsnumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fsname'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fsdesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label></p>');
        checkval2 = true;
    }
    $scope.DATE = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tdnumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fdname'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fddesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label></p>');
        checkval3 = true;
    }
    $scope.SINGLE_SELECTION_ENUM = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tssenumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fssename'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fssedesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label><br/><select id="smt" name="sie"><option value="">Выбрать FieldEnumId</option></select></p>');
        var articleHTML= angular.element('<option ng-repeat="article in gls">{{article.name}}</option>');
        var compileAppendedArticleHTML= $compile(articleHTML);
        var element = compileAppendedArticleHTML($scope);
        $("select[name='sie']").append(element);
        checkval4 = true;
    }
    $scope.MULTIPLE_SELECTION_ENUM = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tmsenumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fmsename'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fmsedesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label><br/><select id="smt" name="se"><option value="">Выбрать FieldEnumId</option></select></p>');
        var articleHTML= angular.element('<option ng-repeat="article in gle">{{article.name}}</option>');
        var compileAppendedArticleHTML= $compile(articleHTML);
        var element = compileAppendedArticleHTML($scope);
        $("select[name='se']").append(element);
        checkval5 = true;
    }
    $scope.MIXED = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tmnumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fmname'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fmdesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label><br/><button class="btn btn-primary addnew" onclick="addint()">INT</button> <button class="btn btn-primary addnew" onclick="addstring()">STRING</button> <button class="btn btn-primary addnew" onclick="adddate()">DATE</button> <button class="btn btn-primary addnew" onclick="addsse()">SINGLE_SELECTION_ENUM</button> <button class="btn btn-primary addnew" onclick="addmse()">MULTIPLE_SELECTION_ENUM</button><br/><br/><font id="idsdobs"></font></p>');
        checkval6 = true;
        $('.remove').show();
    }
    $scope.SYSTEM = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tsysnumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fsysname'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fsysdesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label><br/><select id="smt" name="sis"><option value="">Выбрать FieldSystemId</option></select></p>');
        var articleHTML= angular.element('<option ng-repeat="article in gles">{{article.name}}</option>');
        var compileAppendedArticleHTML= $compile(articleHTML);
        var element = compileAppendedArticleHTML($scope);
        $("select[name='sis']").append(element);
        checkval7 = true;
    }

    $scope.Remove = function () {
        for (var i = 0; i <= 100; i++) {
            if ($('#remove1'+i).prop('checked')) {
                $("input[name='fmm1number"+ i +"']").remove ();
                $("input[name='fmm1desc"+ i +"']").remove ();
                $("#remove1"+i).remove ();
            }
        }
        for (var i = 0; i <= 100; i++) {
            if ($('#remove2'+i).prop('checked')) {
                $("input[name='fmm2number"+ i +"']").remove ();
                $("input[name='fmm2desc"+ i +"']").remove ();
                $("#remove2"+i).remove ();
            }
        }
        for (var i = 0; i <= 100; i++) {
            if ($('#remove3'+i).prop('checked')) {
                $("input[name='fmm3number"+ i +"']").remove ();
                $("input[name='fmm3desc"+ i +"']").remove ();
                $("#remove3"+i).remove ();
            }
        }
        for (var i = 0; i <= 100; i++) {
            if ($('#remove4'+i).prop('checked')) {
                $("input[name='fmm4number"+ i +"']").remove ();
                $("input[name='fmm4desc"+ i +"']").remove ();
                $("#remove4"+i).remove ();
            }
        }
        for (var i = 0; i <= 100; i++) {
            if ($('#remove5'+i).prop('checked')) {
                $("input[name='fmm5number"+ i +"']").remove ();
                $("input[name='fmm5desc"+ i +"']").remove ();
                $("#remove5"+i).remove ();
            }
        }
    }

    $scope.TransitionsAdd = function () {
        var tval1 = $("input[name='tname']").val();
        var tval2 = $("input[name='tdesc']").val();
        var tval3;
        if ($('#cc').prop('checked')) {
            tval3 = true;
        } else {
            tval3 = false;
        }
        var tval4;
        if ($('#oo').prop('checked')) {
            tval4 = true;
        } else {
            tval4 = false;
        }
        var tval5 = new Array();
        if ($("#mpl").prop("checked")) {
            tval5[iz++] = "mpl";
        }
        if ($("#pl_manager").prop("checked")) {
            tval5[iz++] = "pl_manager";
        }
        if ($("#ua_manager").prop("checked")) {
            tval5[iz++] = "ua_manager";
        }
        if ($("#agent").prop("checked")) {
            tval5[iz++] = "agent";
        }
        if ($("#pl_manager_agent").prop("checked")) {
            tval5[iz++] = "pl_manager_agent";
        }
        if ($("#ua_manager_agent").prop("checked")) {
            tval5[iz++] = "ua_manager_agent";
        }
        var tval8 = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('#req'+i).prop('checked')) {
                tval8[intvalarr4++] = true;
            } else {
                tval8[intvalarr4++] = false;
            }
        }
        var tval9 = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('#ns'+i).prop('checked')) {
                tval9[intvalarr5++] = true;
            } else {
                tval9[intvalarr5++] = false;
            }
        }
        var tval10 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm1number'+ i +'"').val() > '') {
                tval10[imsn++] = $('input[name="fmm1number'+ i +'"').val();
            }
        }
        var tval101 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm1desc'+ i +'"').val() > '') {
                tval101[ims++] = $('input[name="fmm1desc'+ i +'"').val();
            }
        }
        var tval11 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm2number'+ i +'"').val() > '') {
                tval11[imsn1++] = $('input[name="fmm2number'+ i +'"').val();
            }
        }
        var tval102 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm2desc'+ i +'"').val() > '') {
                tval102[ims1++] = $('input[name="fmm2desc'+ i +'"').val();
            }
        }
        var tval103 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm3number'+ i +'"').val() > '') {
                tval103[imsn2++] = $('input[name="fmm3number'+ i +'"').val();
            }
        }
        var tval104 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm3desc'+ i +'"').val() > '') {
                tval104[ims2++] = $('input[name="fmm3desc'+ i +'"').val();
            }
        }
        var tval105 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm4number'+ i +'"').val() > '') {
                tval105[imsn3++] = $('input[name="fmm4number'+ i +'"').val();
            }
        }
        var tval106 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm4desc'+ i +'"').val() > '') {
                tval106[ims3++] = $('input[name="fmm4desc'+ i +'"').val();
            }
        }
        var tval107 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm5number'+ i +'"').val() > '') {
                tval107[imsn4++] = $('input[name="fmm5number'+ i +'"').val();
            }
        }
        var tval108 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm5desc'+ i +'"').val() > '') {
                tval108[ims4++] = $('input[name="fmm5desc'+ i +'"').val();
            }
        }
        var tval12 = $("select[name='sib']").val();
        var tval13 = $("select[name='sia']").val();
        var tval15one = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($("#mpl"+ i +"").prop("checked")) {
                tval15one[intvalarr6++] = "mpl";
            } else {
                tval15one[intvalarr6++] = "not chosen";
            }
        }
        var tval15two = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($("#pl_manager"+ i +"").prop("checked")) {
                tval15two[intvalarr7++] = "pl_manager";
            } else {
                tval15two[intvalarr7++] = "not chosen";
            }
        }
        var tval15three = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($("#ua_manager"+ i +"").prop("checked")) {
                tval15three[intvalarr8++] = "ua_manager";
            } else {
                tval15three[intvalarr8++] = "not chosen";
            }
        }
        var tval15four = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($("#agent"+ i +"").prop("checked")) {
                tval15four[intvalarr9++] = "agent";
            } else {
                tval15four[intvalarr9++] = "not chosen";
            }
        }
        var tval15five = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($("#pl_manager_agent"+ i +"").prop("checked")) {
                tval15five[intvalarr10++] = "pl_manager_agent";
            } else {
                tval15five[intvalarr10++] = "not chosen";
            }
        }
        var tval15six = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($("#ua_manager_agent"+ i +"").prop("checked")) {
                tval15six[intvalarr11++] = "ua_manager_agent";
            } else {
                tval15six[intvalarr11++] = "not chosen";
            }
        }
        var tval16 = $("select[name='sie']").val();
        var tval16e = $("select[name='se']").val();
        var tval17 = $("select[name='sis']").val();
        tval110 = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="tnumber'+ i +'"').val() > '') {
                tval110[intvalarr1++] = $('input[name="tnumber'+ i +'"]').val ();
            }
        }
        tval110s = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="tsnumber'+ i +'"').val() > '') {
                tval110s[intvalarr1++] = $('input[name="tsnumber'+ i +'"]').val ();
            }
        }
        tval110d = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="tdnumber'+ i +'"').val() > '') {
                tval110d[intvalarr1++] = $('input[name="tdnumber'+ i +'"]').val ();
            }
        }
        tval110sse = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="tssenumber'+ i +'"').val() > '') {
                tval110sse[intvalarr1++] = $('input[name="tssenumber'+ i +'"]').val ();
            }
        }
        tval110mse = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="tmsenumber'+ i +'"').val() > '') {
                tval110mse[intvalarr1++] = $('input[name="tmsenumber'+ i +'"]').val ();
            }
        }
        tval110m = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="tmnumber'+ i +'"').val() > '') {
                tval110m[intvalarr1++] = $('input[name="tmnumber'+ i +'"]').val ();
            }
        }
        tval110sys = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="tsysnumber'+ i +'"').val() > '') {
                tval110sys[intvalarr1++] = $('input[name="tsysnumber'+ i +'"]').val ();
            }
        }
        tval111 = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fname'+ i +'"').val() > '') {
                tval111[intvalarr2++] = $('input[name="fname'+ i +'"]').val ();
            }
        }
        tval111s = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fsname'+ i +'"').val() > '') {
                tval111s[intvalarr2++] = $('input[name="fsname'+ i +'"]').val ();
            }
        }
        tval111d = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fdname'+ i +'"').val() > '') {
                tval111d[intvalarr2++] = $('input[name="fdname'+ i +'"]').val ();
            }
        }
        tval111sse = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fssename'+ i +'"').val() > '') {
                tval111sse[intvalarr2++] = $('input[name="fssename'+ i +'"]').val ();
            }
        }
        tval111mse = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmsename'+ i +'"').val() > '') {
                tval111mse[intvalarr2++] = $('input[name="fmsename'+ i +'"]').val ();
            }
        }
        tval111m = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmname'+ i +'"').val() > '') {
                tval111m[intvalarr2++] = $('input[name="fmname'+ i +'"]').val ();
            }
        }
        tval111sys = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fsysname'+ i +'"').val() > '') {
                tval111sys[intvalarr2++] = $('input[name="fsysname'+ i +'"]').val ();
            }
        }
        tval112 = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fdesc'+ i +'"').val() > '') {
                tval112[intvalarr3++] = $('input[name="fdesc'+ i +'"]').val ();
            }
        }
        tval112s = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fsdesc'+ i +'"').val() > '') {
                tval112s[intvalarr3++] = $('input[name="fsdesc'+ i +'"]').val ();
            }
        }
        tval112d = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fddesc'+ i +'"').val() > '') {
                tval112d[intvalarr3++] = $('input[name="fddesc'+ i +'"]').val ();
            }
        }
        tval112sse = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fssedesc'+ i +'"').val() > '') {
                tval112sse[intvalarr3++] = $('input[name="fssedesc'+ i +'"]').val ();
            }
        }
        tval112mse = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmsedesc'+ i +'"').val() > '') {
                tval112mse[intvalarr3++] = $('input[name="fmsedesc'+ i +'"]').val ();
            }
        }
        tval112m = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmdesc'+ i +'"').val() > '') {
                tval112m[intvalarr3++] = $('input[name="fmdesc'+ i +'"]').val ();
            }
        }
        tval112sys = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fsysdesc'+ i +'"').val() > '') {
                tval112sys[intvalarr3++] = $('input[name="fsysdesc'+ i +'"]').val ();
            }
        }
        if (checkval1 == true) {
            for (var i = 0; i <= 100; i++) {
                if ($('input[name="tnumber'+ i +'"').val () > '') {
                    field[fap++] = [{
                        "number": tval110[intvar1++],
                        "name": tval111[intvar2++],
                        "description": tval112[intvar3++],
                        "fieldType": "INT",
                        "required": tval8[intvar4++],
                        "notShow": tval9[intvar5++],
                        "noAccessUserRoles": [tval15one[intvar6++],tval15two[intvar7++],tval15three[intvar8++],tval15four[intvar9++],tval15five[intvar10++],tval15six[intvar11++]]
                    }];
                }
            }
        }
        if (checkval2 == true) {
            for (var i = 0; i <= 100; i++) {
                if ($('input[name="tsnumber'+ i +'"').val () > '') {
                    field[fap++] = [{
                        "number": tval110s[intvar1++],
                        "name": tval111s[intvar2++],
                        "description": tval112s[intvar3++],
                        "fieldType": "STRING",
                        "required": tval8[intvar4++],
                        "notShow": tval9[intvar5++],
                        "noAccessUserRoles": [tval15one[intvar6++],tval15two[intvar7++],tval15three[intvar8++],tval15four[intvar9++],tval15five[intvar10++],tval15six[intvar11++]]
                    }];
                }
            }
        }
        if (checkval3 == true) {
            for (var i = 0; i <= 100; i++) {
                if ($('input[name="tdnumber'+ i +'"').val () > '') {
                    field[fap++] = [{
                        "number": tval110d[intvar1++],
                        "name": tval111d[intvar2++],
                        "description": tval112d[intvar3++],
                        "fieldType": "DATE",
                        "required": tval8[intvar4++],
                        "notShow": tval9[intvar5++],
                        "noAccessUserRoles": [tval15one[intvar6++],tval15two[intvar7++],tval15three[intvar8++],tval15four[intvar9++],tval15five[intvar10++],tval15six[intvar11++]]
                    }];
                }
            }
        }
        if (checkval4 == true) {
            for (var i = 0; i <= 100; i++) {
                if ($('input[name="tssenumber'+ i +'"').val () > '') {
                    field[fap++] = [{
                        "number": tval110sse[intvar1++],
                        "name": tval111sse[intvar2++],
                        "description": tval112sse[intvar3++],
                        "fieldType": "SINGLE_SELECTION_ENUM",
                        "required": tval8[intvar4++],
                        "notShow": tval9[intvar5++],
                        "noAccessUserRoles": [tval15one[intvar6++],tval15two[intvar7++],tval15three[intvar8++],tval15four[intvar9++],tval15five[intvar10++],tval15six[intvar11++]],
                        "fieldEnumId": tval16
                    }];
                }
            }
        }
        if (checkval5 == true) {
            for (var i = 0; i <= 100; i++) {
                if ($('input[name="tmsenumber'+ i +'"').val () > '') {
                    field[fap++] = [{
                        "number": tval110mse[intvar1++],
                        "name": tval111mse[intvar2++],
                        "description": tval112mse[intvar3++],
                        "fieldType": "MULTIPLE_SELECTION_ENUM",
                        "required": tval8[intvar4++],
                        "notShow": tval9[intvar5++],
                        "noAccessUserRoles": [tval15one[intvar6++],tval15two[intvar7++],tval15three[intvar8++],tval15four[intvar9++],tval15five[intvar10++],tval15six[intvar11++]],
                        "fieldEnumId": tval16e
                    }];
                }
            }
        }
        if (checkval6 == true) {
            for (var i = 0; i <= 100; i++) {
                if ($('input[name="tmnumber'+ i +'"').val () > '') {
                    field[fap++] = [{
                        "number": tval110m[intvar1++],
                        "name": tval111m[intvar2++],
                        "description": tval112m[intvar3++],
                        "fieldType": "MIXED",
                        "required": tval8[intvar4++],
                        "notShow": tval9[intvar5++],
                        "noAccessUserRoles": [tval15one[intvar6++],tval15two[intvar7++],tval15three[intvar8++],tval15four[intvar9++],tval15five[intvar10++],tval15six[intvar11++]],
                        "mixedType": []
                    }];
                    if (field.length == 1) {
                        for (var i = 1; i <= 100; i++) {
                            if (tval10.length >= i) field[0][0].mixedType.push({"number": tval10[imdsn++],"description": tval101[imds++],"fieldType": "INT"});
                            if (tval11.length >= i) field[0][0].mixedType.push({"number": tval11[imdsn1++],"description": tval102[imds1++],"fieldType": "STRING"});
                            if (tval103.length >= i) field[0][0].mixedType.push({"number": tval103[imdsn2++],"description": tval104[imds2++],"fieldType": "DATE"});
                            if (tval105.length >= i) field[0][0].mixedType.push({"number": tval105[imdsn3++],"description": tval106[imds3++],"fieldType": "SINGLE_SELECTION_ENUM"});
                            if (tval107.length >= i) field[0][0].mixedType.push({"number": tval107[imdsn4++],"description": tval108[imds4++],"fieldType": "MULTIPLE_SELECTION_ENUM"});
                        }
                    }
                    if (field.length == 2) {
                        for (var i = 1; i <= 100; i++) {
                            if (tval10.length >= i) field[1][0].mixedType.push({"number": tval10[imdsn++],"description": tval101[imds++],"fieldType": "INT"});
                            if (tval11.length >= i) field[1][0].mixedType.push({"number": tval11[imdsn1++],"description": tval102[imds1++],"fieldType": "STRING"});
                            if (tval103.length >= i) field[1][0].mixedType.push({"number": tval103[imdsn2++],"description": tval104[imds2++],"fieldType": "DATE"});
                            if (tval105.length >= i) field[1][0].mixedType.push({"number": tval105[imdsn3++],"description": tval106[imds3++],"fieldType": "SINGLE_SELECTION_ENUM"});
                            if (tval107.length >= i) field[1][0].mixedType.push({"number": tval107[imdsn4++],"description": tval108[imds4++],"fieldType": "MULTIPLE_SELECTION_ENUM"});
                        }
                    }
                    if (field.length == 3) {
                        for (var i = 1; i <= 100; i++) {
                            if (tval10.length >= i) field[2][0].mixedType.push({"number": tval10[imdsn++],"description": tval101[imds++],"fieldType": "INT"});
                            if (tval11.length >= i) field[2][0].mixedType.push({"number": tval11[imdsn1++],"description": tval102[imds1++],"fieldType": "STRING"});
                            if (tval103.length >= i) field[2][0].mixedType.push({"number": tval103[imdsn2++],"description": tval104[imds2++],"fieldType": "DATE"});
                            if (tval105.length >= i) field[2][0].mixedType.push({"number": tval105[imdsn3++],"description": tval106[imds3++],"fieldType": "SINGLE_SELECTION_ENUM"});
                            if (tval107.length >= i) field[2][0].mixedType.push({"number": tval107[imdsn4++],"description": tval108[imds4++],"fieldType": "MULTIPLE_SELECTION_ENUM"});
                        }
                    }
                    if (field.length == 4) {
                        for (var i = 1; i <= 100; i++) {
                            if (tval10.length >= i) field[3][0].mixedType.push({"number": tval10[imdsn++],"description": tval101[imds++],"fieldType": "INT"});
                            if (tval11.length >= i) field[3][0].mixedType.push({"number": tval11[imdsn1++],"description": tval102[imds1++],"fieldType": "STRING"});
                            if (tval103.length >= i) field[3][0].mixedType.push({"number": tval103[imdsn2++],"description": tval104[imds2++],"fieldType": "DATE"});
                            if (tval105.length >= i) field[3][0].mixedType.push({"number": tval105[imdsn3++],"description": tval106[imds3++],"fieldType": "SINGLE_SELECTION_ENUM"});
                            if (tval107.length >= i) field[3][0].mixedType.push({"number": tval107[imdsn4++],"description": tval108[imds4++],"fieldType": "MULTIPLE_SELECTION_ENUM"});
                        }
                    }
                    if (field.length == 5) {
                        for (var i = 1; i <= 100; i++) {
                            if (tval10.length >= i) field[4][0].mixedType.push({"number": tval10[imdsn++],"description": tval101[imds++],"fieldType": "INT"});
                            if (tval11.length >= i) field[4][0].mixedType.push({"number": tval11[imdsn1++],"description": tval102[imds1++],"fieldType": "STRING"});
                            if (tval103.length >= i) field[4][0].mixedType.push({"number": tval103[imdsn2++],"description": tval104[imds2++],"fieldType": "DATE"});
                            if (tval105.length >= i) field[4][0].mixedType.push({"number": tval105[imdsn3++],"description": tval106[imds3++],"fieldType": "SINGLE_SELECTION_ENUM"});
                            if (tval107.length >= i) field[4][0].mixedType.push({"number": tval107[imdsn4++],"description": tval108[imds4++],"fieldType": "MULTIPLE_SELECTION_ENUM"});
                        }
                    }
                    if (field.length == 6) {
                        for (var i = 1; i <= 100; i++) {
                            if (tval10.length >= i) field[5][0].mixedType.push({"number": tval10[imdsn++],"description": tval101[imds++],"fieldType": "INT"});
                            if (tval11.length >= i) field[5][0].mixedType.push({"number": tval11[imdsn1++],"description": tval102[imds1++],"fieldType": "STRING"});
                            if (tval103.length >= i) field[5][0].mixedType.push({"number": tval103[imdsn2++],"description": tval104[imds2++],"fieldType": "DATE"});
                            if (tval105.length >= i) field[5][0].mixedType.push({"number": tval105[imdsn3++],"description": tval106[imds3++],"fieldType": "SINGLE_SELECTION_ENUM"});
                            if (tval107.length >= i) field[5][0].mixedType.push({"number": tval107[imdsn4++],"description": tval108[imds4++],"fieldType": "MULTIPLE_SELECTION_ENUM"});
                        }
                    }
                }
            }
        }
        if (checkval7 == true) {
            for (var i = 0; i <= 100; i++) {
                if ($('input[name="tsysnumber'+ i +'"').val () > '') {
                    field[fap++] = [{
                        "number": tval110sys[intvar1++],
                        "name": tval111sys[intvar2++],
                        "description": tval112sys[intvar3++],
                        "fieldType": "SYSTEM",
                        "required": tval8[intvar4++],
                        "notShow": tval9[intvar5++],
                        "noAccessUserRoles": [tval15one[intvar6++],tval15two[intvar7++],tval15three[intvar8++],tval15four[intvar9++],tval15five[intvar10++],tval15six[intvar11++]],
                        "fieldEnumId": tval17
                    }];
                }
            }
        }
        var carts = {
            "name": tval1,
            "description": tval2,
            "confirmChanges": tval3,
            "onlyOwner": tval4,
            "userRoles": tval5,
            "stateIdBefore": tval12,
            "stateIdAfter": tval13,
            "fields": field
        };
        var tval5l = tval5.length - 1;
        for (var i = 0; i <= 100; i++) {
            if (tval5l == i) {
                carts.userRoles.push(tval5[i]);
            }
        }
        if (field.length == 1) carts.fields.push(field[0]);
        alert (JSON.stringify (carts));
        if (tval1 < 1 || tval2 < 1 || tval5.length < 1 || tval12 < 1 || tval13 < 1 || field < 1) {
            alert('Заполните все!');
            location.reload();
        }
        else {
            var url7 = "http://admin.merkurij.pl/site-admin-ws/rest/transitions/add";
            mTransitionsAdd();
            function mTransitionsAdd() {
                $http({
                    url: url7,
                    method: "POST",
                    headers: {
                        Authorization: avt,
                        'Content-Type': 'application/json'
                    },
                    data: carts
                })
                    .then(
                        function successCallback(response) {
                            alert('Все успешно добавлено!');
                            localStorage.removeItem (1);
                            location.reload();
                            return true;
                        },
                        function errorCallback(response) {
                            if (response.status == 400) {
                                alert(response.data.description);
                                location.reload();
                            } else if (response.status == 401) {
                                alert("Invalid username or password!");
                                location.reload();
                            }
                            return false;
                        });
            }
        }
    }
});