siteAdminApp.controller('usersController', ['$scope', '$http', 'ModalService', function($scope, $http, ModalService) {
    checkToken($http);
    switchTab("#users_tab");

    var url7 = "http://admin.merkurij.pl/site-admin-ws/rest/states/get_all";
    var avt = 'Bearer ' + localStorage.getItem("id_token");

    mUsersGetAll();
    function mUsersGetAll() {
        $http({
            url : wsBaseUri + "users/get_all",
            method : "GET",
            headers : {
                Authorization : avt,
                'Content-Type' : 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.users = response.data;
                    return true;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert (response.data.description);
                    } else if (response.status == 401) {
                        alert ("Invalid username or password!");
                    }
                    return false;
                });
    }


    $scope.changeUserRole = function (userT) {
        ModalService.showModal({
            templateUrl: "view/modal/changeUserRole.html",
            controller: "changeUserRoleController",
            inputs: {
                user: userT
            }
        }).then(function (modal) {
            modal.element.modal();
            modal.close.then(function (result) {

            });
        });
    };

    $scope.changeUserPassword = function (userT) {
        ModalService.showModal({
            templateUrl: "view/modal/changeUserPassword.html",
            controller: "changeUserPasswordController",
            inputs: {
                user: userT
            }
        }).then(function (modal) {
            modal.element.modal();
            modal.close.then(function (result) {

            });
        });
    };

    $scope.deleteUser = function (user) {
        if (confirm("You about delete user " + user.name + ". Are you sure?")) {
            $http({
                url: wsBaseUri + "users/remove",
                method: "POST",
                headers: {
                    Authorization: avt,
                    'Content-Type': 'application/json'
                },
                data: user
            })
                .then(
                    function successCallback(response) {
                        alert('Пользователь удален!');
                        window.location.reload();
                    },
                    function errorCallback(response) {
                        if (response.status == 400) {
                            alert(response.data.description);
                        } else if (response.status == 401) {
                            alert("Invalid username or password!");
                        }
                    });


        }
    }
}]);