siteAdminApp.controller('enumsController', function($scope, $http) {
    checkToken($http);
    switchTab("#enums_tab");

    var url7 = "http://admin.merkurij.pl/site-admin-ws/rest/enums/get_all";
    var avt = 'Bearer ' + localStorage.getItem("id_token");

    mEnumsGelAll();
    function mEnumsGelAll() {
        $http({
            url : url7,
            method : "GET",
            headers : {
                Authorization : avt,
                'Content-Type' : 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.devs = response.data;
                    return true;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert (response.data.description);
                    } else if (response.status == 401) {
                        alert ("Invalid username or password!");
                    }
                    return false;
                });
    }

});