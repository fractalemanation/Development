siteAdminApp.controller('transitionController', ['$scope', '$http', '$stateParams', '$state', 'ModalService', function ($scope, $http, $stateParams, $state, ModalService) {
    checkToken($http);
    switchTab("#transitions_tab");
    $scope.transitionId = $stateParams.transitionId;
    $scope.transition = {};

    setTimeout(installSwitcher, 500);
    function installSwitcher(){
        $("[name='custom-checkbox']").bootstrapSwitch();
    }

    $scope.showMixedField = function (mixedTypeValuesT) {
        ModalService.showModal({
            templateUrl: "view/modal/mixedFields.html",
            controller: "mixedFieldsController",
            inputs: {
                mixedTypeValues: mixedTypeValuesT
            }
        }).then(function (modal) {
            modal.element.modal();
            modal.close.then(function (result) {

            });
        });
    };

    init();

    function init() {

        var avt = 'Bearer ' + localStorage.getItem("id_token");
        $http({
            url: wsBaseUri + "transitions/get/" + $scope.transitionId,
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.transition = response.data;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert(response.data.description);
                    } else if (response.status == 401) {
                        alert("Invalid username or password!");
                    }
                });
    }
}]);
