//var wsBaseUri = "rest/ws-proxy";
var wsBaseUri = "/showings-ws/rest";

function checkToken($http) {
	var token = getToken();
	if (token) {
		if (token.includes(".")) {
			token = token.substr(0, token.indexOf('.'));
			if (IsJsonString(Base64.decode(token))) {
				var tokenObject = strJsonToObject(Base64.decode(token));
				var dateExp = new Date(tokenObject.exp);
				if (dateExp < new Date()) {
					logoutToken($http);
					removeTokenAndRedirect();
				}
			} else {
				removeTokenAndRedirect();
			}
		} else {
			removeTokenAndRedirect();
		}
	} else {
		removeTokenAndRedirect();
	}
}

function strJsonToObject(str) {
	return JSON && JSON.parse(str) || $.parseJSON(str);
}

function IsJsonString(str) {
	try {
		JSON.parse(str);
	} catch (e) {
		return false;
	}
	return true;
}

function logoutToken($http) {
	$http({
		url : wsBaseUri + '/authorization/logout',
		method : "GET",
		headers : {
			'Content-Type' : 'application/json',
			Authorization : getToken()
		}
	}).then(function successCallback(response) {
		return true;
	}, function errorCallback(response) {
		return false;
	});
}

function getToken() {
	return localStorage.getItem("id_token");
}

function removeToken() {
	localStorage.removeItem("id_token");
}

function removeTokenAndRedirect() {
	localStorage.removeItem("id_token");
	window.location.href = 'login.html';
}

function saveGuestToken(token, $http) {
	var existingToken = getToken();
	if (existingToken) {
		if (existingToken.includes(".")) {
			existingToken = existingToken.substr(0, existingToken.indexOf('.'));
			if (IsJsonString(Base64.decode(existingToken))) {
				var tokenObject = strJsonToObject(Base64.decode(existingToken));
				var dateExp = new Date(tokenObject.exp);
				if (dateExp < new Date()) {
					localStorage.setItem("id_token", token);
				} else {
					if (tokenObject.sub != "admin")
						localStorage.setItem("id_token", token);
				}
			} else {
				localStorage.setItem("id_token", token);
			}
		} else {
			localStorage.setItem("id_token", token);
		}
	} else {
		localStorage.setItem("id_token", token);
	}
}
