siteAdminApp.controller('transitionsController', function($scope, $http) {
    checkToken($http);
    switchTab("#transitions_tab");

    init();
    function init() {
        var avt = 'Bearer ' + localStorage.getItem("id_token");

        $http({
            url : wsBaseUri + 'transitions/get_list',
            method : "GET",
            headers : {
                Authorization : avt,
                'Content-Type' : 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.transitions = response.data;
                    return true;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert (response.data.description);
                    } else if (response.status == 401) {
                        alert ("Invalid username or password!");
                    }
                    return false;
                });
    }
});
