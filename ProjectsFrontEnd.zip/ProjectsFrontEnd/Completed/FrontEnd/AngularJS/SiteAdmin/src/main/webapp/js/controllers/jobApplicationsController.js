siteAdminApp.controller('jobApplicationsController', function($scope, $http) {
    checkToken($http);
    switchTab("#job_applications_tab");
});
