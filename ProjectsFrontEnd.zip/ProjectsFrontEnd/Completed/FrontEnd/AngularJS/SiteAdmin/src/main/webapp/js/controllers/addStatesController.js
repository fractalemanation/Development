siteAdminApp.controller('addStatesController', function($scope, $http) {
    checkToken($http);
    switchTab("#states_tab");

    $scope.StatesAdd = function() {
        var snameval1 = $scope.sname;
        var snameval2 = $scope.sdesc;
        if (snameval1 < 1 || snameval2 < 1)
            alert ('Заполните все!');
        else {
            var url7 = "http://admin.merkurij.pl/site-admin-ws/rest/states/add";
            var avt = 'Bearer ' + localStorage.getItem("id_token");

            mStatesAdd();
            function mStatesAdd() {
                $http({
                    url : url7,
                    method : "POST",
                    headers : {
                        Authorization : avt,
                        'Content-Type' : 'application/json'
                    },
                    data: {
                        "name": snameval1,
                        "description": snameval2
                    }
                })
                    .then(
                        function successCallback(response) {
                            alert ('Все успешно добавлено!');
                            return true;
                        },
                        function errorCallback(response) {
                            if (response.status == 400) {
                                alert (response.data.description);
                            } else if (response.status == 401) {
                                alert ("Invalid username or password!");
                            }
                            return false;
                        });
            }
        }
    }
});