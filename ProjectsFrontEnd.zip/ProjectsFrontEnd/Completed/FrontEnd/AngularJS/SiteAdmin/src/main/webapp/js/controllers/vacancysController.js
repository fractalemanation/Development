siteAdminApp.controller('vacancysController', [
    '$scope',
    '$http',
    'getVacancys',
    '$window',
    function ($scope, $http, getVacancys, $window) {
        checkToken($http);
        switchTab("#vacancys");
        // $scope.vacancys;
        //
        // init();
        //
        // function init() {
        //
        //     $http.get(wsBaseUri + '/vacancys/get_all').then(
        //         function (response) {
        //             $scope.vacancys = response.data;
        //         }, function (error) {
        //             console.log('error ' + error);
        //         });
        //
        // }

    }]);