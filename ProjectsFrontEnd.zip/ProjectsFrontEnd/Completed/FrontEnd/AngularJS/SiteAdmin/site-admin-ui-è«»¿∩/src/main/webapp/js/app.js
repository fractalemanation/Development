var wsBaseUri = "/site-admin-ws/rest";

var siteAdminApp = angular.module('siteAdminApp',
		[ 'ui.router'/* , 'checklist-model', 'ui.bootstrap' */]);
siteAdminApp.directive('onlyDigits', function() {
	return {
		require : 'ngModel',
		restrict : 'A',
		link : function(scope, element, attr, ctrl) {
			function inputValue(val) {
				if (val) {
					var digits = val.replace(/[^0-9.-]/g, '');

					if (digits !== val) {
						ctrl.$setViewValue(digits);
						ctrl.$render();
					}
					return parseFloat(digits);
				}
				return undefined;
			}

			ctrl.$parsers.push(inputValue);
		}
	};
});

siteAdminApp.config(function($stateProvider, $urlRouterProvider) {

	$urlRouterProvider.otherwise('/vacancys');

	$stateProvider.state('vacancys', {
		url : '/vacancys',
		templateUrl : './view/vacancys.html'
	}).state('job_applications', {
		url : '/job_applications',
		templateUrl : './view/job_applications.html',
		controller : 'jobApplicationsController'
	});

});

siteAdminApp.service('getVacancys', [ '$http', '$q', function($http, $q) {
	var deferred = $q.defer();
	$http.get(wsBaseUri + '/vacancys/get_all').then(function(data) {
		deferred.resolve(data);
	}, function(error) {
		console.log('error ' + error);
	});
	return deferred.promise;

} ]);

siteAdminApp.controller('jobApplicationsController', function($scope, $http) {
	switchTab("#job_applications");

});

siteAdminApp.controller('vacancysController', [
		'$scope',
		'$http',
		'getVacancys',
		'$window',
		function($scope, $http, getVacancys, $window) {
			switchTab("#vacancys");
			$scope.vacancys;

			init();

			function init() {

				$http.get(wsBaseUri + '/vacancys/get_all').then(
						function(response) {
							$scope.vacancys = response.data;
						}, function(error) {
							console.log('error ' + error);
						});

			}

		} ]);

function switchTab(tab) {
	$("#vacancys").removeAttr("class");
	$("#job_applications").removeAttr("class");
	$(tab).attr("class", "active");
}