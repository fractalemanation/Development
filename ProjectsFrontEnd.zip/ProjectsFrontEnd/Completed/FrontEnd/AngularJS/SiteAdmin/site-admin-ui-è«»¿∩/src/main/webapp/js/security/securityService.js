var tokenWithRole = null;

function codeData(value){
		var arr = [];
  		for (var i = 0, l = value.length; i < l; i ++) {
    			var hex = Number(value.charCodeAt(i)).toString(16);
    			arr.push(hex);
  		}
  	return arr.join('');
}

function decodeData(value){
 		var hex = value.toString();//force conversion
    		var str = '';
    		for (var i = 0; i < hex.length; i += 2)
        		str += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
    	return str;
}

function saveToLocalStorage(cName, data) {
	localStorage.setItem(cName, JSON.stringify(data));
}


function deleteFromLocalStorage(cName) {
	localStorage.setItem(cName, null);
}

function saveRememberMeInfo(data) {
	if (navigator.cookieEnabled) {
		saveToLocalStorage("rememberMeInfo", data)
	}
}

function readRememberMeInfo() {
	if (navigator.cookieEnabled ) {
		return readFromLocalStorage ("rememberMeInfo");
	} else return tokenWithRole;
}

function deleteRememberMeInfo() {
	return deleteFromLocalStorage ("rememberMeInfo");
}

function saveTokenWithRole(data) {
	if (navigator.cookieEnabled) {
		saveToLocalStorage("tokenWithRole", data)
	} else tokenWithRole = data;
};


function readToken() {
	var tokenWithRole = readTokenWithRole();
	
	if (currentUserToken != undefined || currentUserToken != null){
		if (tokenWithRole) {
			if (currentUserToken != tokenWithRole.token) redirectToLogin();
		}
	} else {
        if (tokenWithRole) {
            currentUserToken = tokenWithRole.token;
        }
	}
	if (tokenWithRole) return tokenWithRole.token;
}

function readRole() {
	var tokenWithRole = readTokenWithRole();
	if (tokenWithRole) return tokenWithRole.role;
}

function deleteTokenWithRole() {
	tokenWithRole = null;
	deleteFromLocalStorage("tokenWithRole");
}

function readServerIdleTimeOut() {
	var tokenWithRole = readTokenWithRole();
	if (tokenWithRole) return tokenWithRole.expirationTime || 300; //default value 5 min
	return 300;
}
function isAdmin() {
	var role = readRole();
	if (role == "ADMIN") return true;
	return false;
}

function isSupport() {
	var role = readRole();
	if (role == "SUPPORT") return true;
	return false;
}

function isReadOnly() {
	var role = readRole();
	if (role == "READ") return true;
	return false;
}

function applySecurity($scope, allowedRoles) {
	$scope.role = readRole();
    var isAllow = false;
	$.each(allowedRoles, function(key, value) {
		if ($scope.role === value) {
            isAllow = true;
            return;
        }
	});
    if (!isAllow)
	    redirectToLogin();
}

function strJsonToObject(str) {
	return JSON && JSON.parse(str) || $.parseJSON(str);
}


function escapeBrackets(val) {
	if (val != null || val != undefined) {
		if (typeof val == 'string') {
			return val.replace(/</g, '&lt;').replace(/>/g, '&gt;');
		}
	}
	return val;
}

function arrayEscapeBrackets(arrayObject) {
	for (var line in arrayObject) {
		for (var dataLine in arrayObject[line]) {
			arrayObject[line][dataLine] = escapeBrackets(arrayObject[line][dataLine]);
		}
	}
}