$('.btn-logout').click (function () {
	localStorage.clear();
	window.location.href = 'login.html';
});

if (localStorage.length < 1) {
	window.location.href = 'login.html';
}

var Base64 = {
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    encode: function (e) {
        var t = "";
        var n, r, i, s, o, u, a;
        var f = 0;
        e = Base64._utf8_encode(e);
        while (f < e.length) {
            n = e.charCodeAt(f++);
            r = e.charCodeAt(f++);
            i = e.charCodeAt(f++);
            s = n >> 2;
            o = (n & 3) << 4 | r >> 4;
            u = (r & 15) << 2 | i >> 6;
            a = i & 63;
            if (isNaN(r)) {
                u = a = 64
            }
            else if (isNaN(i)) {
                a = 64
            }
            t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a)
        } return t
    },
    decode: function (e) {
        var t = "";
        var n, r, i;
        var s, o, u, a;
        var f = 0;
        e = e.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (f < e.length) {
            s = this._keyStr.indexOf(e.charAt(f++));
            o = this._keyStr.indexOf(e.charAt(f++));
            u = this._keyStr.indexOf(e.charAt(f++));
            a = this._keyStr.indexOf(e.charAt(f++));
            n = s << 2 | o >> 4;
            r = (o & 15) << 4 | u >> 2;
            i = (u & 3) << 6 | a; t = t + String.fromCharCode(n);
            if (u != 64) {
                t = t + String.fromCharCode(r)
            }
            if (a != 64) {
                t = t + String.fromCharCode(i)
            }
        }
        t = Base64._utf8_decode(t); return t
    },
    _utf8_encode: function (e) {
        e = e.replace(/\r\n/g, "\n");
        var t = "";
        for (var n = 0; n < e.length; n++) {
            var r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r)
            }
            else if (r > 127 && r < 2048) {
                t += String.fromCharCode(r >> 6 | 192);
                t += String.fromCharCode(r & 63 | 128)
            }
            else {
                t += String.fromCharCode(r >> 12 | 224);
                t += String.fromCharCode(r >> 6 & 63 | 128);
                t += String.fromCharCode(r & 63 | 128)
            }
        } return t
    },
    _utf8_decode: function (e) {
        var t = "";
        var n = 0;
        var r = c1 = c2 = 0;
        while (n < e.length) {
            r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r);
                n++
            }
            else if (r > 191 && r < 224) {
                c2 = e.charCodeAt(n + 1);
                t += String.fromCharCode((r & 31) << 6 | c2 & 63);
                n += 2
            }
            else {
                c2 = e.charCodeAt(n + 1);
                c3 = e.charCodeAt(n + 2);
                t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
                n += 3
            }
        } return t
    }
}

var tok = Base64.decode(localStorage.getItem("id_token").split('.')[1]);
var data = JSON.parse(tok);
var date = new Date(data.exp * 1000);
var daten = new Date();

if (daten > date) {
    localStorage.clear();
    window.location.href = 'login.html';
}

if (data.role == 'mpl')
    $('#vacancys').show ();

$('#vacancys').click(function() {
	$('#wrap').slideToggle();
});
/*
$('#adds').click(function() {
	$('#addenum').slideToggle ();
});

$('#enums').click(function() {
    $('#enum').slideToggle ();
});
*/
var field;
var x;
var i = 3;
var j = 1;
var iz = 0;
var ix = 0;
var izi = 0;

function add1 () {
  $('#addd').append ('<br/><input class="input" type="text" placeholder="Номер" name="tnumber" /><br/><input class="input" type="text" placeholder="Название" name="fname" /><input class="input" type="text" placeholder="Описание" name="fdesc" /><br /><input type="checkbox" id="req" name="req" /><label for="req">requared</label> <input type="checkbox" id="ns" name="ns" /><label for="ns">notShow</label><br/><input type="checkbox" id="mpl1" name="mpl" /><label for="mpl1">mpl</label> <input type="checkbox" id="pl_manager2" name="pl_manager" /><label for="pl_manager2">pl_manager</label> <input type="checkbox" id="ua_manager3" name="ua_manager" /><label for="ua_manager3">ua_manager</label> <input type="checkbox" id="agent4" name="agent" /><label for="agent4">agent</label> <input type="checkbox" id="pl_manager_agent5" name="pl_manager_agent" /><label for="pl_manager_agent5">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent6" name="ua_manager_agent" /><label for="ua_manager_agent6">ua_manager_agent</label>');
}
function add () {
    $('.addsenum').append ('<div class="line"></div><input class="input" type="text" placeholder="Название" ng-model="val' + i++ + '" /><input style="margin-left:4px" class="input" type="text" placeholder="Описание" ng-model="val' + i++ + '" />');
}

var App = angular.module('App', ['ngRoute']);

App.config(['$routeProvider', function($routeProvide) {
    $routeProvide
    .when('/',{
        templateUrl:'view/main.html',
        controller:'Ctrl'
    })
    .when('/states',{
        templateUrl:'view/state.html',
        controller:'Ctrl'
    })
    .when('/addstates',{
        templateUrl:'view/addstate.html',
        controller:'Ctrl'
    })
    .when('/enums',{
        templateUrl:'view/enum.html',
        controller:'Ctrl'
    })
    .when('/addenums',{
        templateUrl:'view/addenum.html',
        controller:'Ctrl'
    })
    .when('/transitions',{
        templateUrl:'view/transition.html',
        controller:'Ctrl'
    })
    .when('/addtransitions',{
        templateUrl:'view/addtransition.html',
        controller:'Ctrl'
    })
    .otherwise({
        redirectTo: '/'
    });
}]);

App.controller('Ctrl', function($scope, $http, $compile) {

    $scope.f1 = function() {
        var val1 = $("input[name='name']").val ();
        var val2 = $("input[name='desc']").val ();
        var val3 = $("input[name='val1']").val ();
        var val4 = $("input[name='val2']").val ();
        var vals = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($("input[name='val"+ i +"']").val () > '')
                vals[i] = $("input[name='val"+ i +"']").val();
        }
        var cart = {
            "name" : val1,
            "description" : val2,
            "values": []
        };
        for (var i = 3; i <= 101; i+=2) {
            if (vals.length >= i)
                cart.values.push ({"name": vals[j++], "description": vals[j++]});
        }
        if (val1 < 1 || val2 < 1 || val3 < 1 || val4 < 1)
            alert ('Заполните все поля!');
        else {
            var url7 = "http://admin.merkurij.pl/site-admin-ws/rest/enums/add";
            var avt = 'Bearer ' + localStorage.getItem("id_token");
            f2();
            function f2() {
                $http({
                    url : url7,
                    method : "POST",
                    headers : {
                        Authorization : avt,
                        'Content-Type' : 'application/json'
                    },
                    data : cart
                })
                .then(
                    function successCallback(response) {
                        alert ('Все успешно добавлено!');
                        return true;
                    },
                    function errorCallback(response) {
                        if (response.status == 400) {
                            alert (response.data.description);
                        } else if (response.status == 401) {
                            alert ("Invalid username or password!");
                        }
                        return false;
                    });
            }
        }
    }

    var url7 = "http://admin.merkurij.pl/site-admin-ws/rest/enums/get_all";
    var avt = 'Bearer ' + localStorage.getItem("id_token");

    f3();
    function f3() {
        $http({
            url : url7,
            method : "GET",
            headers : {
                Authorization : avt,
                'Content-Type' : 'application/json'
            }
        })
        .then(
            function successCallback(response) {
                $scope.devs = response.data;
                return true;
            },
            function errorCallback(response) {
                if (response.status == 400) {
                    alert (response.data.description);
                } else if (response.status == 401) {
                    alert ("Invalid username or password!");
                }
                return false;
            });
    }

    var url7 = "http://admin.merkurij.pl/site-admin-ws/rest/states/get_all";
    var avt = 'Bearer ' + localStorage.getItem("id_token");

    f4();
    function f4() {
        $http({
            url : url7,
            method : "GET",
            headers : {
                Authorization : avt,
                'Content-Type' : 'application/json'
            }
        })
        .then(
            function successCallback(response) {
                $scope.states = response.data;
                return true;
            },
            function errorCallback(response) {
                if (response.status == 400) {
                    alert (response.data.description);
                } else if (response.status == 401) {
                    alert ("Invalid username or password!");
                }
                return false;
            });
    }

    $scope.f5 = function() {
        var sval1 = $("input[name='sname']").val ();
        var sval2 = $("input[name='sdesc']").val ();
        if (sval1 < 1 || sval2 < 1) alert ('Заполните все поля!');
        else {
            var url7 = "http://admin.merkurij.pl/site-admin-ws/rest/states/add";
            var avt = 'Bearer ' + localStorage.getItem("id_token");

            f6();
            function f6() {
                $http({
                    url : url7,
                    method : "POST",
                    headers : {
                        Authorization : avt,
                        'Content-Type' : 'application/json'
                    },
                    data: {
                        "name": sval1,
                        "description": sval2
                    }
                })
                .then(
                    function successCallback(response) {
                        alert ('Все успешно добавлено!');
                        return true;
                    },
                    function errorCallback(response) {
                        if (response.status == 400) {
                            alert (response.data.description);
                        } else if (response.status == 401) {
                            alert ("Invalid username or password!");
                        }
                        return false;
                    });
            }
        }
    }

$scope.f7 = function() {
var avt = 'Bearer ' + localStorage.getItem("id_token");
statesGetList();
function statesGetList() {
    $http({
            url : "http://admin.merkurij.pl/site-admin-ws/rest/states/get_list",
            method : "GET",
            headers : {
                Authorization : avt,
                'Content-Type' : 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.gls = response.data;
                    return true;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert (response.data.description);
                    } else if (response.status == 401) {
                        alert ("Invalid username or password!");
                    }
                    return false;
                });
}
var as = 0;
    var ai = 0;
    var ims = 0;
    var imss = 0;
    var imds = 0;
    var imdss = 0;
    $scope.addstring = function () {
        $('#idsdobs').append ('<p><input class="input" type="text" name="fmdesc'+ as++ +'" placeholder="Описание STRING" /></p>');
    }
    $scope.addint = function () {
        $('#idsdobs').append ('<p><input class="input" type="text" name="fmdescc'+ ai++ +'" placeholder="Описание INT" /></p>');
    }

    var field;
    var iz = 0;
    var izi = 0;

    var avt = 'Bearer ' + localStorage.getItem("id_token");
    statesGetList();
    function statesGetList() {
        $http({
            url: "http://admin.merkurij.pl/site-admin-ws/rest/states/get_list",
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.gls = response.data;
                    return true;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert(response.data.description);
                    } else if (response.status == 401) {
                        alert("Invalid username or password!");
                    }
                    return false;
                });
    }

    enumsGetList();
    function enumsGetList() {
        $http({
            url: "http://admin.merkurij.pl/site-admin-ws/rest/enums/get_types",
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
        .then(
            function successCallback(response) {
                $scope.gle = response.data;
                return true;
            },
            function errorCallback(response) {
                if (response.status == 400) {
                    alert(response.data.description);
                } else if (response.status == 401) {
                    alert("Invalid username or password!");
                }
                return false;
            });
    }

    systemGetList();
    function systemGetList() {
        $http({
            url: "http://admin.merkurij.pl/site-admin-ws/rest/system_fields/get_values",
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
        .then(
            function successCallback(response) {
                $scope.gles = response.data;
                return true;
            },
            function errorCallback(response) {
                if (response.status == 400) {
                    alert(response.data.description);
                } else if (response.status == 401) {
                    alert("Invalid username or password!");
                }
                return false;
            });
    }

    var as = 0;
    var ai = 0;
    var ims = 0;
    var imss = 0;
    var imds = 0;
    var imdss = 0;
    $scope.addstring = function () {
        $('#idsdobs').append ('<p><input class="input" type="text" name="fmdesc'+ as++ +'" placeholder="Описание STRING" /></p>');
    }
    $scope.addint = function () {
        $('#idsdobs').append ('<p><input class="input" type="text" name="fmdescc'+ ai++ +'" placeholder="Описание INT" /></p>');
    }

    var field;
    var iz = 0;
    var izi = 0;

    var avt = 'Bearer ' + localStorage.getItem("id_token");
    statesGetList();
    function statesGetList() {
        $http({
            url: "http://admin.merkurij.pl/site-admin-ws/rest/states/get_list",
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
        .then(
            function successCallback(response) {
                $scope.gls = response.data;
                return true;
            },
            function errorCallback(response) {
                if (response.status == 400) {
                    alert(response.data.description);
                } else if (response.status == 401) {
                    alert("Invalid username or password!");
                }
                return false;
            });
    }

    enumsGetList();
    function enumsGetList() {
        $http({
            url: "http://admin.merkurij.pl/site-admin-ws/rest/enums/get_types",
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
        .then(
            function successCallback(response) {
                $scope.gle = response.data;
                return true;
            },
            function errorCallback(response) {
                if (response.status == 400) {
                    alert(response.data.description);
                } else if (response.status == 401) {
                    alert("Invalid username or password!");
                }
                return false;
            });
    }

    systemGetList();
    function systemGetList() {
        $http({
            url: "http://admin.merkurij.pl/site-admin-ws/rest/system_fields/get_values",
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
        .then(
            function successCallback(response) {
                $scope.gles = response.data;
                return true;
            },
            function errorCallback(response) {
                if (response.status == 400) {
                    alert(response.data.description);
                } else if (response.status == 401) {
                    alert("Invalid username or password!");
                }
                return false;
            });
    }

var field = new Array ();
var fap = 0;intval1 = 0;intval2 = 0;intval3 = 0;intval4 = 0;intval5 = 0;intval6 = 0;intval7 = 0;intval8 = 0;intval9 = 0;intval10 = 0;intval11 = 0;
var intvar1 = 0;intvar2 = 0;intvar3 = 0;intvar4 = 0;intvar5 = 0;intvar6 = 0;intvar7 = 0;intvar8 = 0;intvar9 = 0;intvar10 = 0;intvar11 = 0;
var intvalarr1 = 0;intvalarr2 = 0;intvalarr3 = 0;intvalarr4 = 0;intvalarr5 = 0;intvalarr6 = 0;intvalarr7 = 0;intvalarr8 = 0;intvalarr9 = 0;intvalarr10 = 0;intvalarr11 = 0;
var forcheck1 = 0;forcheck2 = 0;forcheck3 = 0;forcheck4 = 0;forcheck5 = 0;forcheck6 = 0;forcheck7 = 0;forcheck8 = 0;
var checkval1 = false;checkval2 = false;checkval3 = false;checkval4 = false;checkval5 = false;checkval6 = false;checkval7 = false;
var remove1 = 0;remove2 = 0;remove3 = 0;remove4 = 0;remove5 = 0;
var asn = 0;asd = 0;asn1 = 0;asd1 = 0;asn2 = 0;asd2 = 0;asn3 = 0;asd3 = 0;asn4 = 0;asd4 = 0;
var imsn = 0;ims = 0;imsn1 = 0;ims1 = 0;imsn2 = 0;ims2 = 0;imsn3 = 0;ims3 = 0;imsn4 = 0;ims4 = 0;
var imds = 0;imdsn = 0;imds1 = 0;imdsn1 = 0;imds2 = 0;imdsn2 = 0;imds3 = 0;imdsn3 = 0;imds4 = 0;imdsn4 = 0;
var iz = 0;
var gle = new Array ();

function addint () {
    $('#idsdobs').append ('<p><input type="checkbox" id="remove1'+ remove1++ +'" /> <input class="input" type="text" name="fmm1number'+ asn++ +'" placeholder="Номер INT" /> <input class="input" type="text" name="fmm1desc'+ asd++ +'" placeholder="Описание INT" /></p>');
}
function addstring () {
    $('#idsdobs').append ('<p><input type="checkbox" id="remove2'+ remove2++ +'" /> <input class="input" type="text" name="fmm2number'+ asn1++ +'" placeholder="Номер STRING" /> <input class="input" type="text" name="fmm2desc'+ asd1++ +'" placeholder="Описание STRING" /></p>');
}
function adddate () {
    $('#idsdobs').append ('<p><input type="checkbox" id="remove3'+ remove3++ +'" /> <input class="input" type="text" name="fmm3number'+ asn2++ +'" placeholder="Номер DATE" /> <input class="input" type="text" name="fmm3desc'+ asd2++ +'" placeholder="Описание DATE" /></p>');
}
function addsse () {
    $('#idsdobs').append ('<p><input type="checkbox" id="remove4'+ remove4++ +'" /> <input class="input" type="text" name="fmm4number'+ asn3++ +'" placeholder="Номер SINGLE_SELECTION_ENUM" /> <input class="input" type="text" name="fmm4desc'+ asd3++ +'" placeholder="Описание SINGLE_SELECTION_ENUM" /></p>');
}
function addmse () {
    $('#idsdobs').append ('<p><input type="checkbox" id="remove5'+ remove5++ +'" /> <input class="input" type="text" name="fmm5number'+ asn4++ +'" placeholder="Номер MULTIPLE_SELECTION_ENUM" /> <input class="input" type="text" name="fmm5desc'+ asd4++ +'" placeholder="Описание MULTIPLE_SELECTION_ENUM" /></p>');
}

siteAdminApp.controller('addTransitionsController', function ($scope, $http, $compile) {
    checkToken($http);
    switchTab("#transitions_tab");

    $scope.svu = 'Выбрать StateIdBefore';
    $scope.svuv = '';
    if (localStorage.length > 1) {
        $scope.svu = localStorage.getItem(1);
        $scope.svuv = localStorage.getItem(1);
    }

    var avt = 'Bearer ' + localStorage.getItem("id_token");
    statesGetList();
    function statesGetList() {
        $http({
            url: "http://admin.merkurij.pl/site-admin-ws/rest/states/get_list",
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.gls = response.data;
                    return true;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert(response.data.description);
                    } else if (response.status == 401) {
                        alert("Invalid username or password!");
                    }
                    return false;
                });
    }
    enumsGetList();
    function enumsGetList() {
        $http({
            url: "http://admin.merkurij.pl/site-admin-ws/rest/enums/get_types",
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.gle = response.data;
                    return true;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert(response.data.description);
                    } else if (response.status == 401) {
                        alert("Invalid username or password!");
                    }
                    return false;
                });
    }
    systemGetList();
    function systemGetList() {
        $http({
            url: "http://admin.merkurij.pl/site-admin-ws/rest/system_fields/get_values",
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.gles = response.data;
                    return true;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert(response.data.description);
                    } else if (response.status == 401) {
                        alert("Invalid username or password!");
                    }
                    return false;
                });
    }

    $scope.INT = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tnumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fname'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fdesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label></p>');
        checkval1 = true;
    }
    $scope.STRING = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tsnumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fsname'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fsdesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label></p>');
        checkval2 = true;
    }
    $scope.DATE = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tdnumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fdname'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fddesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label></p>');
        checkval3 = true;
    }
    $scope.SINGLE_SELECTION_ENUM = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tssenumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fssename'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fssedesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label><br/><select id="smt" name="sie"><option value="">Выбрать FieldEnumId</option></select></p>');
        var articleHTML= angular.element('<option ng-repeat="article in gles">{{article.name}}</option>');
        var compileAppendedArticleHTML= $compile(articleHTML);
        var element = compileAppendedArticleHTML($scope);
        $("select[name='sie']").append(element);
        checkval4 = true;
    }
    $scope.MULTIPLE_SELECTION_ENUM = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tmsenumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fmsename'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fmsedesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label><br/><select id="smt" name="se"><option value="">Выбрать FieldEnumId</option></select></p>');
        var articleHTML= angular.element('<option ng-repeat="article in gle">{{article.name}}</option>');
        var compileAppendedArticleHTML= $compile(articleHTML);
        var element = compileAppendedArticleHTML($scope);
        $("select[name='se']").append(element);
        checkval5 = true;
    }
    $scope.MIXED = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tmnumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fmname'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fmdesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label><br/><button class="btn btn-primary addnew" onclick="addint()">INT</button> <button class="btn btn-primary addnew" onclick="addstring()">STRING</button> <button class="btn btn-primary addnew" onclick="adddate()">DATE</button> <button class="btn btn-primary addnew" onclick="addsse()">SINGLE_SELECTION_ENUM</button> <button class="btn btn-primary addnew" onclick="addmse()">MULTIPLE_SELECTION_ENUM</button><br/><br/><font id="idsdobs"></font></p>');
        checkval6 = true;
        $('.remove').show();
    }
    $scope.SYSTEM = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tsysnumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fsysname'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fsysdesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label><br/><select id="smt" name="sis"><option value="">Выбрать FieldSystemId</option></select></p>');
        var articleHTML= angular.element('<option ng-repeat="article in gls">{{article.name}}</option>');
        var compileAppendedArticleHTML= $compile(articleHTML);
        var element = compileAppendedArticleHTML($scope);
        $("select[name='sis']").append(element);
        checkval7 = true;
    }

    $scope.Remove = function () {
        for (var i = 0; i <= 100; i++) {
            if ($('#remove1'+i).prop('checked')) {
                $("input[name='fmm1number"+ i +"']").remove ();
                $("input[name='fmm1desc"+ i +"']").remove ();
                $("#remove1"+i).remove ();
            }
        }
        for (var i = 0; i <= 100; i++) {
            if ($('#remove2'+i).prop('checked')) {
                $("input[name='fmm2number"+ i +"']").remove ();
                $("input[name='fmm2desc"+ i +"']").remove ();
                $("#remove2"+i).remove ();
            }
        }
        for (var i = 0; i <= 100; i++) {
            if ($('#remove3'+i).prop('checked')) {
                $("input[name='fmm3number"+ i +"']").remove ();
                $("input[name='fmm3desc"+ i +"']").remove ();
                $("#remove3"+i).remove ();
            }
        }
        for (var i = 0; i <= 100; i++) {
            if ($('#remove4'+i).prop('checked')) {
                $("input[name='fmm4number"+ i +"']").remove ();
                $("input[name='fmm4desc"+ i +"']").remove ();
                $("#remove4"+i).remove ();
            }
        }
        for (var i = 0; i <= 100; i++) {
            if ($('#remove5'+i).prop('checked')) {
                $("input[name='fmm5number"+ i +"']").remove ();
                $("input[name='fmm5desc"+ i +"']").remove ();
                $("#remove5"+i).remove ();
            }
        }
    }

    var field = new Array ();
    var fap = 0;intval1 = 0;intval2 = 0;intval3 = 0;intval4 = 0;intval5 = 0;intval6 = 0;intval7 = 0;intval8 = 0;intval9 = 0;intval10 = 0;intval11 = 0;
    var intvar1 = 0;intvar2 = 0;intvar3 = 0;intvar4 = 0;intvar5 = 0;intvar6 = 0;intvar7 = 0;intvar8 = 0;intvar9 = 0;intvar10 = 0;intvar11 = 0;
    var intvalarr1 = 0;intvalarr2 = 0;intvalarr3 = 0;intvalarr4 = 0;intvalarr5 = 0;intvalarr6 = 0;intvalarr7 = 0;intvalarr8 = 0;intvalarr9 = 0;intvalarr10 = 0;intvalarr11 = 0;
    var forcheck1 = 0;forcheck2 = 0;forcheck3 = 0;forcheck4 = 0;forcheck5 = 0;forcheck6 = 0;forcheck7 = 0;forcheck8 = 0;
    var checkval1 = false;checkval2 = false;checkval3 = false;checkval4 = false;checkval5 = false;checkval6 = false;checkval7 = false;
    var remove1 = 0;remove2 = 0;remove3 = 0;remove4 = 0;remove5 = 0;
    var asn = 0;asd = 0;asn1 = 0;asd1 = 0;asn2 = 0;asd2 = 0;asn3 = 0;asd3 = 0;asn4 = 0;asd4 = 0;
    var imsn = 0;ims = 0;imsn1 = 0;ims1 = 0;imsn2 = 0;ims2 = 0;imsn3 = 0;ims3 = 0;imsn4 = 0;ims4 = 0;
    var imds = 0;imdsn = 0;imds1 = 0;imdsn1 = 0;imds2 = 0;imdsn2 = 0;imds3 = 0;imdsn3 = 0;imds4 = 0;imdsn4 = 0;
    var iz = 0;
    var gle = new Array ();
    function addint () {
        $('#idsdobs').append ('<p><input type="checkbox" id="remove1'+ remove1++ +'" /> <input class="input" type="text" name="fmm1number'+ asn++ +'" placeholder="Номер INT" /> <input class="input" type="text" name="fmm1desc'+ asd++ +'" placeholder="Описание INT" /></p>');
    }
    function addstring () {
        $('#idsdobs').append ('<p><input type="checkbox" id="remove2'+ remove2++ +'" /> <input class="input" type="text" name="fmm2number'+ asn1++ +'" placeholder="Номер STRING" /> <input class="input" type="text" name="fmm2desc'+ asd1++ +'" placeholder="Описание STRING" /></p>');
    }
    function adddate () {
        $('#idsdobs').append ('<p><input type="checkbox" id="remove3'+ remove3++ +'" /> <input class="input" type="text" name="fmm3number'+ asn2++ +'" placeholder="Номер DATE" /> <input class="input" type="text" name="fmm3desc'+ asd2++ +'" placeholder="Описание DATE" /></p>');
    }
    function addsse () {
        $('#idsdobs').append ('<p><input type="checkbox" id="remove4'+ remove4++ +'" /> <input class="input" type="text" name="fmm4number'+ asn3++ +'" placeholder="Номер SINGLE_SELECTION_ENUM" /> <input class="input" type="text" name="fmm4desc'+ asd3++ +'" placeholder="Описание SINGLE_SELECTION_ENUM" /></p>');
    }
    function addmse () {
        $('#idsdobs').append ('<p><input type="checkbox" id="remove5'+ remove5++ +'" /> <input class="input" type="text" name="fmm5number'+ asn4++ +'" placeholder="Номер MULTIPLE_SELECTION_ENUM" /> <input class="input" type="text" name="fmm5desc'+ asd4++ +'" placeholder="Описание MULTIPLE_SELECTION_ENUM" /></p>');
    }

    checkToken($http);
    switchTab("#transitions_tab");

    $scope.svu = 'Выбрать StateIdBefore';
    $scope.svuv = '';
    if (localStorage.length > 1) {
        $scope.svu = localStorage.getItem(1);
        $scope.svuv = localStorage.getItem(1);
    }

    var avt = 'Bearer ' + localStorage.getItem("id_token");
    statesGetList();
    function statesGetList() {
        $http({
            url: "http://admin.merkurij.pl/site-admin-ws/rest/states/get_list",
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.gls = response.data;
                    return true;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert(response.data.description);
                    } else if (response.status == 401) {
                        alert("Invalid username or password!");
                    }
                    return false;
                });
    }
    enumsGetList();
    function enumsGetList() {
        $http({
            url: "http://admin.merkurij.pl/site-admin-ws/rest/enums/get_types",
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.gle = response.data;
                    return true;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert(response.data.description);
                    } else if (response.status == 401) {
                        alert("Invalid username or password!");
                    }
                    return false;
                });
    }
    systemGetList();
    function systemGetList() {
        $http({
            url: "http://admin.merkurij.pl/site-admin-ws/rest/system_fields/get_values",
            method: "GET",
            headers: {
                Authorization: avt,
                'Content-Type': 'application/json'
            }
        })
            .then(
                function successCallback(response) {
                    $scope.gles = response.data;
                    return true;
                },
                function errorCallback(response) {
                    if (response.status == 400) {
                        alert(response.data.description);
                    } else if (response.status == 401) {
                        alert("Invalid username or password!");
                    }
                    return false;
                });
    }

    $scope.INT = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tnumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fname'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fdesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label></p>');
        checkval1 = true;
    }
    $scope.STRING = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tsnumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fsname'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fsdesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label></p>');
        checkval2 = true;
    }
    $scope.DATE = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tdnumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fdname'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fddesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label></p>');
        checkval3 = true;
    }
    $scope.SINGLE_SELECTION_ENUM = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tssenumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fssename'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fssedesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label><br/><select id="smt" name="sie"><option value="">Выбрать FieldEnumId</option></select></p>');
        var articleHTML= angular.element('<option ng-repeat="article in gles">{{article.name}}</option>');
        var compileAppendedArticleHTML= $compile(articleHTML);
        var element = compileAppendedArticleHTML($scope);
        $("select[name='sie']").append(element);
        checkval4 = true;
    }
    $scope.MULTIPLE_SELECTION_ENUM = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tmsenumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fmsename'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fmsedesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label><br/><select id="smt" name="se"><option value="">Выбрать FieldEnumId</option></select></p>');
        var articleHTML= angular.element('<option ng-repeat="article in gle">{{article.name}}</option>');
        var compileAppendedArticleHTML= $compile(articleHTML);
        var element = compileAppendedArticleHTML($scope);
        $("select[name='se']").append(element);
        checkval5 = true;
    }
    $scope.MIXED = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tmnumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fmname'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fmdesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label><br/><button class="btn btn-primary addnew" onclick="addint()">INT</button> <button class="btn btn-primary addnew" onclick="addstring()">STRING</button> <button class="btn btn-primary addnew" onclick="adddate()">DATE</button> <button class="btn btn-primary addnew" onclick="addsse()">SINGLE_SELECTION_ENUM</button> <button class="btn btn-primary addnew" onclick="addmse()">MULTIPLE_SELECTION_ENUM</button><br/><br/><font id="idsdobs"></font></p>');
        checkval6 = true;
        $('.remove').show();
    }
    $scope.SYSTEM = function () {
        $('#fielddob').append ('<br/><p><input class="input" type="text" placeholder="Номер" name="tsysnumber'+ intval1++ +'" /><br/><input class="input" type="text" placeholder="Название" name="fsysname'+ intval2++ +'" /> <input class="input" type="text" placeholder="Описание" name="fsysdesc'+ intval3++ +'" /><br /><input type="checkbox" id="req'+ intval4++ +'" name="req" /><label for="req'+ forcheck1++ +'">requared</label> <input type="checkbox" id="ns'+ intval5++ +'" name="ns" /><label for="ns'+ forcheck2++ +'">notShow</label><br/><input type="checkbox" id="mpl'+ intval6++ +'" ng-model="mpl" /><label for="mpl'+ forcheck3++ +'">mpl</label> <input type="checkbox" id="pl_manager'+ intval7++ +'" ng-model="pl_manager" /><label for="pl_manager'+ forcheck4++ +'">pl_manager</label> <input type="checkbox" id="ua_manager'+ intval8++ +'" ng-model="ua_manager" /><label for="ua_manager'+ forcheck5++ +'">ua_manager</label> <input type="checkbox" id="agent'+ intval9++ +'" ng-model="agent" /><label for="agent'+ forcheck6++ +'">agent</label> <input type="checkbox" id="pl_manager_agent'+ intval10++ +'" ng-model="pl_manager_agent" /><label for="pl_manager_agent'+ forcheck7++ +'">pl_manager_agent</label> <input type="checkbox" id="ua_manager_agent'+ intval11++ +'" ng-model="ua_manager_agent" /><label for="ua_manager_agent'+ forcheck8++ +'">ua_manager_agent</label><br/><select id="smt" name="sis"><option value="">Выбрать FieldSystemId</option></select></p>');
        var articleHTML= angular.element('<option ng-repeat="article in gls">{{article.name}}</option>');
        var compileAppendedArticleHTML= $compile(articleHTML);
        var element = compileAppendedArticleHTML($scope);
        $("select[name='sis']").append(element);
        checkval7 = true;
    }

    $scope.Remove = function () {
        for (var i = 0; i <= 100; i++) {
            if ($('#remove1'+i).prop('checked')) {
                $("input[name='fmm1number"+ i +"']").remove ();
                $("input[name='fmm1desc"+ i +"']").remove ();
                $("#remove1"+i).remove ();
            }
        }
        for (var i = 0; i <= 100; i++) {
            if ($('#remove2'+i).prop('checked')) {
                $("input[name='fmm2number"+ i +"']").remove ();
                $("input[name='fmm2desc"+ i +"']").remove ();
                $("#remove2"+i).remove ();
            }
        }
        for (var i = 0; i <= 100; i++) {
            if ($('#remove3'+i).prop('checked')) {
                $("input[name='fmm3number"+ i +"']").remove ();
                $("input[name='fmm3desc"+ i +"']").remove ();
                $("#remove3"+i).remove ();
            }
        }
        for (var i = 0; i <= 100; i++) {
            if ($('#remove4'+i).prop('checked')) {
                $("input[name='fmm4number"+ i +"']").remove ();
                $("input[name='fmm4desc"+ i +"']").remove ();
                $("#remove4"+i).remove ();
            }
        }
        for (var i = 0; i <= 100; i++) {
            if ($('#remove5'+i).prop('checked')) {
                $("input[name='fmm5number"+ i +"']").remove ();
                $("input[name='fmm5desc"+ i +"']").remove ();
                $("#remove5"+i).remove ();
            }
        }
    }

    $scope.TransitionsAdd = function () {
        var tval1 = $("input[name='tname']").val();
        var tval2 = $("input[name='tdesc']").val();
        var tval3;
        if ($('#cc').prop('checked')) {
            tval3 = true;
        } else {
            tval3 = false;
        }
        var tval4;
        if ($('#oo').prop('checked')) {
            tval4 = true;
        } else {
            tval4 = false;
        }
        var tval5 = new Array();
        if ($("#mpl").prop("checked")) {
            tval5[iz++] = "mpl";
        }
        if ($("#pl_manager").prop("checked")) {
            tval5[iz++] = "pl_manager";
        }
        if ($("#ua_manager").prop("checked")) {
            tval5[iz++] = "ua_manager";
        }
        if ($("#agent").prop("checked")) {
            tval5[iz++] = "agent";
        }
        if ($("#pl_manager_agent").prop("checked")) {
            tval5[iz++] = "pl_manager_agent";
        }
        if ($("#ua_manager_agent").prop("checked")) {
            tval5[iz++] = "ua_manager_agent";
        }
        var tval8 = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('#req'+i).prop('checked')) {
                tval8[intvalarr4++] = true;
            } else {
                tval8[intvalarr4++] = false;
            }
        }
        var tval9 = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('#ns'+i).prop('checked')) {
                tval9[intvalarr5++] = true;
            } else {
                tval9[intvalarr5++] = false;
            }
        }
        var tval10 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm1number'+ i +'"').val() > '') {
                tval10[imsn++] = $('input[name="fmm1number'+ i +'"').val();
            }
        }
        var tval101 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm1desc'+ i +'"').val() > '') {
                tval101[ims++] = $('input[name="fmm1desc'+ i +'"').val();
            }
        }
        var tval11 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm2number'+ i +'"').val() > '') {
                tval11[imsn1++] = $('input[name="fmm2number'+ i +'"').val();
            }
        }
        var tval102 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm2desc'+ i +'"').val() > '') {
                tval102[ims1++] = $('input[name="fmm2desc'+ i +'"').val();
            }
        }
        var tval103 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm3number'+ i +'"').val() > '') {
                tval103[imsn2++] = $('input[name="fmm3number'+ i +'"').val();
            }
        }
        var tval104 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm3desc'+ i +'"').val() > '') {
                tval104[ims2++] = $('input[name="fmm3desc'+ i +'"').val();
            }
        }
        var tval105 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm4number'+ i +'"').val() > '') {
                tval105[imsn3++] = $('input[name="fmm4number'+ i +'"').val();
            }
        }
        var tval106 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm4desc'+ i +'"').val() > '') {
                tval106[ims3++] = $('input[name="fmm4desc'+ i +'"').val();
            }
        }
        var tval107 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm5number'+ i +'"').val() > '') {
                tval107[imsn4++] = $('input[name="fmm5number'+ i +'"').val();
            }
        }
        var tval108 = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmm5desc'+ i +'"').val() > '') {
                tval108[ims4++] = $('input[name="fmm5desc'+ i +'"').val();
            }
        }
        var tval12 = $("select[name='sib']").val();
        var tval13 = $("select[name='sia']").val();
        var tval15one = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($("#mpl"+ i +"").prop("checked")) {
                tval15one[intvalarr6++] = "mpl";
            } else {
                tval15one[intvalarr6++] = "not chosen";
            }
        }
        var tval15two = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($("#pl_manager"+ i +"").prop("checked")) {
                tval15two[intvalarr7++] = "pl_manager";
            } else {
                tval15two[intvalarr7++] = "not chosen";
            }
        }
        var tval15three = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($("#ua_manager"+ i +"").prop("checked")) {
                tval15three[intvalarr8++] = "ua_manager";
            } else {
                tval15three[intvalarr8++] = "not chosen";
            }
        }
        var tval15four = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($("#agent"+ i +"").prop("checked")) {
                tval15four[intvalarr9++] = "agent";
            } else {
                tval15four[intvalarr9++] = "not chosen";
            }
        }
        var tval15five = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($("#pl_manager_agent"+ i +"").prop("checked")) {
                tval15five[intvalarr10++] = "pl_manager_agent";
            } else {
                tval15five[intvalarr10++] = "not chosen";
            }
        }
        var tval15six = new Array();
        for (var i = 0; i <= 100; i++) {
            if ($("#ua_manager_agent"+ i +"").prop("checked")) {
                tval15six[intvalarr11++] = "ua_manager_agent";
            } else {
                tval15six[intvalarr11++] = "not chosen";
            }
        }
        var tval16 = $("select[name='sie']").val();
        var tval16e = $("select[name='se']").val();
        var tval17 = $("select[name='sis']").val();
        tval110 = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="tnumber'+ i +'"').val() > '') {
                tval110[intvalarr1++] = $('input[name="tnumber'+ i +'"]').val ();
            }
        }
        tval110s = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="tsnumber'+ i +'"').val() > '') {
                tval110s[intvalarr1++] = $('input[name="tsnumber'+ i +'"]').val ();
            }
        }
        tval110d = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="tdnumber'+ i +'"').val() > '') {
                tval110d[intvalarr1++] = $('input[name="tdnumber'+ i +'"]').val ();
            }
        }
        tval110sse = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="tssenumber'+ i +'"').val() > '') {
                tval110sse[intvalarr1++] = $('input[name="tssenumber'+ i +'"]').val ();
            }
        }
        tval110mse = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="tmsenumber'+ i +'"').val() > '') {
                tval110mse[intvalarr1++] = $('input[name="tmsenumber'+ i +'"]').val ();
            }
        }
        tval110m = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="tmnumber'+ i +'"').val() > '') {
                tval110m[intvalarr1++] = $('input[name="tmnumber'+ i +'"]').val ();
            }
        }
        tval110sys = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="tsysnumber'+ i +'"').val() > '') {
                tval110sys[intvalarr1++] = $('input[name="tsysnumber'+ i +'"]').val ();
            }
        }
        tval111 = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fname'+ i +'"').val() > '') {
                tval111[intvalarr2++] = $('input[name="fname'+ i +'"]').val ();
            }
        }
        tval111s = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fsname'+ i +'"').val() > '') {
                tval111s[intvalarr2++] = $('input[name="fsname'+ i +'"]').val ();
            }
        }
        tval111d = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fdname'+ i +'"').val() > '') {
                tval111d[intvalarr2++] = $('input[name="fdname'+ i +'"]').val ();
            }
        }
        tval111sse = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fssename'+ i +'"').val() > '') {
                tval111sse[intvalarr2++] = $('input[name="fssename'+ i +'"]').val ();
            }
        }
        tval111mse = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmsename'+ i +'"').val() > '') {
                tval111mse[intvalarr2++] = $('input[name="fmsename'+ i +'"]').val ();
            }
        }
        tval111m = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmname'+ i +'"').val() > '') {
                tval111m[intvalarr2++] = $('input[name="fmname'+ i +'"]').val ();
            }
        }
        tval111sys = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fsysname'+ i +'"').val() > '') {
                tval111sys[intvalarr2++] = $('input[name="fsysname'+ i +'"]').val ();
            }
        }
        tval112 = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fdesc'+ i +'"').val() > '') {
                tval112[intvalarr3++] = $('input[name="fdesc'+ i +'"]').val ();
            }
        }
        tval112s = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fsdesc'+ i +'"').val() > '') {
                tval112s[intvalarr3++] = $('input[name="fsdesc'+ i +'"]').val ();
            }
        }
        tval112d = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fddesc'+ i +'"').val() > '') {
                tval112d[intvalarr3++] = $('input[name="fddesc'+ i +'"]').val ();
            }
        }
        tval112sse = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fssedesc'+ i +'"').val() > '') {
                tval112sse[intvalarr3++] = $('input[name="fssedesc'+ i +'"]').val ();
            }
        }
        tval112mse = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmsedesc'+ i +'"').val() > '') {
                tval112mse[intvalarr3++] = $('input[name="fmsedesc'+ i +'"]').val ();
            }
        }
        tval112m = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fmdesc'+ i +'"').val() > '') {
                tval112m[intvalarr3++] = $('input[name="fmdesc'+ i +'"]').val ();
            }
        }
        tval112sys = new Array ();
        for (var i = 0; i <= 100; i++) {
            if ($('input[name="fsysdesc'+ i +'"').val() > '') {
                tval112sys[intvalarr3++] = $('input[name="fsysdesc'+ i +'"]').val ();
            }
        }
        if (checkval1 == true) {
            for (var i = 0; i <= 100; i++) {
                if ($('input[name="tnumber'+ i +'"').val () > '') {
                    field[fap++] = [{
                        "number": tval110[intvar1++],
                        "name": tval111[intvar2++],
                        "description": tval112[intvar3++],
                        "fieldType": "INT",
                        "required": tval8[intvar4++],
                        "notShow": tval9[intvar5++],
                        "noAccessUserRoles": [tval15one[intvar6++],tval15two[intvar7++],tval15three[intvar8++],tval15four[intvar9++],tval15five[intvar10++],tval15six[intvar11++]]
                    }];
                }
            }
        }
        if (checkval2 == true) {
            for (var i = 0; i <= 100; i++) {
                if ($('input[name="tsnumber'+ i +'"').val () > '') {
                    field[fap++] = [{
                        "number": tval110s[intvar1++],
                        "name": tval111s[intvar2++],
                        "description": tval112s[intvar3++],
                        "fieldType": "STRING",
                        "required": tval8[intvar4++],
                        "notShow": tval9[intvar5++],
                        "noAccessUserRoles": [tval15one[intvar6++],tval15two[intvar7++],tval15three[intvar8++],tval15four[intvar9++],tval15five[intvar10++],tval15six[intvar11++]]
                    }];
                }
            }
        }
        if (checkval3 == true) {
            for (var i = 0; i <= 100; i++) {
                if ($('input[name="tdnumber'+ i +'"').val () > '') {
                    field[fap++] = [{
                        "number": tval110d[intvar1++],
                        "name": tval111d[intvar2++],
                        "description": tval112d[intvar3++],
                        "fieldType": "DATE",
                        "required": tval8[intvar4++],
                        "notShow": tval9[intvar5++],
                        "noAccessUserRoles": [tval15one[intvar6++],tval15two[intvar7++],tval15three[intvar8++],tval15four[intvar9++],tval15five[intvar10++],tval15six[intvar11++]]
                    }];
                }
            }
        }
        if (checkval4 == true) {
            for (var i = 0; i <= 100; i++) {
                if ($('input[name="tssenumber'+ i +'"').val () > '') {
                    field[fap++] = [{
                        "number": tval110sse[intvar1++],
                        "name": tval111sse[intvar2++],
                        "description": tval112sse[intvar3++],
                        "fieldType": "SINGLE_SELECTION_ENUM",
                        "required": tval8[intvar4++],
                        "notShow": tval9[intvar5++],
                        "noAccessUserRoles": [tval15one[intvar6++],tval15two[intvar7++],tval15three[intvar8++],tval15four[intvar9++],tval15five[intvar10++],tval15six[intvar11++]],
                        "fieldEnumId": tval16
                    }];
                }
            }
        }
        if (checkval5 == true) {
            for (var i = 0; i <= 100; i++) {
                if ($('input[name="tmsenumber'+ i +'"').val () > '') {
                    field[fap++] = [{
                        "number": tval110mse[intvar1++],
                        "name": tval111mse[intvar2++],
                        "description": tval112mse[intvar3++],
                        "fieldType": "MULTIPLE_SELECTION_ENUM",
                        "required": tval8[intvar4++],
                        "notShow": tval9[intvar5++],
                        "noAccessUserRoles": [tval15one[intvar6++],tval15two[intvar7++],tval15three[intvar8++],tval15four[intvar9++],tval15five[intvar10++],tval15six[intvar11++]],
                        "fieldEnumId": tval16e
                    }];
                }
            }
        }
        if (checkval6 == true) {
            for (var i = 0; i <= 100; i++) {
                if ($('input[name="tmnumber'+ i +'"').val () > '') {
                    field[fap++] = [{
                        "number": tval110m[intvar1++],
                        "name": tval111m[intvar2++],
                        "description": tval112m[intvar3++],
                        "fieldType": "MIXED",
                        "required": tval8[intvar4++],
                        "notShow": tval9[intvar5++],
                        "noAccessUserRoles": [tval15one[intvar6++],tval15two[intvar7++],tval15three[intvar8++],tval15four[intvar9++],tval15five[intvar10++],tval15six[intvar11++]],
                        "mixedType": []
                    }];
                    if (field.length == 1) {
                        for (var i = 1; i <= 100; i++) {
                            if (tval10.length >= i) field[0][0].mixedType.push({"number": tval10[imdsn++],"description": tval101[imds++],"fieldType": "INT"});
                            if (tval11.length >= i) field[0][0].mixedType.push({"number": tval11[imdsn1++],"description": tval102[imds1++],"fieldType": "STRING"});
                            if (tval103.length >= i) field[0][0].mixedType.push({"number": tval103[imdsn2++],"description": tval104[imds2++],"fieldType": "DATE"});
                            if (tval105.length >= i) field[0][0].mixedType.push({"number": tval105[imdsn3++],"description": tval106[imds3++],"fieldType": "SINGLE_SELECTION_ENUM"});
                            if (tval107.length >= i) field[0][0].mixedType.push({"number": tval107[imdsn4++],"description": tval108[imds4++],"fieldType": "MULTIPLE_SELECTION_ENUM"});
                        }
                    }
                    if (field.length == 2) {
                        for (var i = 1; i <= 100; i++) {
                            if (tval10.length >= i) field[1][0].mixedType.push({"number": tval10[imdsn++],"description": tval101[imds++],"fieldType": "INT"});
                            if (tval11.length >= i) field[1][0].mixedType.push({"number": tval11[imdsn1++],"description": tval102[imds1++],"fieldType": "STRING"});
                            if (tval103.length >= i) field[1][0].mixedType.push({"number": tval103[imdsn2++],"description": tval104[imds2++],"fieldType": "DATE"});
                            if (tval105.length >= i) field[1][0].mixedType.push({"number": tval105[imdsn3++],"description": tval106[imds3++],"fieldType": "SINGLE_SELECTION_ENUM"});
                            if (tval107.length >= i) field[1][0].mixedType.push({"number": tval107[imdsn4++],"description": tval108[imds4++],"fieldType": "MULTIPLE_SELECTION_ENUM"});
                        }
                    }
                    if (field.length == 3) {
                        for (var i = 1; i <= 100; i++) {
                            if (tval10.length >= i) field[2][0].mixedType.push({"number": tval10[imdsn++],"description": tval101[imds++],"fieldType": "INT"});
                            if (tval11.length >= i) field[2][0].mixedType.push({"number": tval11[imdsn1++],"description": tval102[imds1++],"fieldType": "STRING"});
                            if (tval103.length >= i) field[2][0].mixedType.push({"number": tval103[imdsn2++],"description": tval104[imds2++],"fieldType": "DATE"});
                            if (tval105.length >= i) field[2][0].mixedType.push({"number": tval105[imdsn3++],"description": tval106[imds3++],"fieldType": "SINGLE_SELECTION_ENUM"});
                            if (tval107.length >= i) field[2][0].mixedType.push({"number": tval107[imdsn4++],"description": tval108[imds4++],"fieldType": "MULTIPLE_SELECTION_ENUM"});
                        }
                    }
                    if (field.length == 4) {
                        for (var i = 1; i <= 100; i++) {
                            if (tval10.length >= i) field[3][0].mixedType.push({"number": tval10[imdsn++],"description": tval101[imds++],"fieldType": "INT"});
                            if (tval11.length >= i) field[3][0].mixedType.push({"number": tval11[imdsn1++],"description": tval102[imds1++],"fieldType": "STRING"});
                            if (tval103.length >= i) field[3][0].mixedType.push({"number": tval103[imdsn2++],"description": tval104[imds2++],"fieldType": "DATE"});
                            if (tval105.length >= i) field[3][0].mixedType.push({"number": tval105[imdsn3++],"description": tval106[imds3++],"fieldType": "SINGLE_SELECTION_ENUM"});
                            if (tval107.length >= i) field[3][0].mixedType.push({"number": tval107[imdsn4++],"description": tval108[imds4++],"fieldType": "MULTIPLE_SELECTION_ENUM"});
                        }
                    }
                    if (field.length == 5) {
                        for (var i = 1; i <= 100; i++) {
                            if (tval10.length >= i) field[4][0].mixedType.push({"number": tval10[imdsn++],"description": tval101[imds++],"fieldType": "INT"});
                            if (tval11.length >= i) field[4][0].mixedType.push({"number": tval11[imdsn1++],"description": tval102[imds1++],"fieldType": "STRING"});
                            if (tval103.length >= i) field[4][0].mixedType.push({"number": tval103[imdsn2++],"description": tval104[imds2++],"fieldType": "DATE"});
                            if (tval105.length >= i) field[4][0].mixedType.push({"number": tval105[imdsn3++],"description": tval106[imds3++],"fieldType": "SINGLE_SELECTION_ENUM"});
                            if (tval107.length >= i) field[4][0].mixedType.push({"number": tval107[imdsn4++],"description": tval108[imds4++],"fieldType": "MULTIPLE_SELECTION_ENUM"});
                        }
                    }
                    if (field.length == 6) {
                        for (var i = 1; i <= 100; i++) {
                            if (tval10.length >= i) field[5][0].mixedType.push({"number": tval10[imdsn++],"description": tval101[imds++],"fieldType": "INT"});
                            if (tval11.length >= i) field[5][0].mixedType.push({"number": tval11[imdsn1++],"description": tval102[imds1++],"fieldType": "STRING"});
                            if (tval103.length >= i) field[5][0].mixedType.push({"number": tval103[imdsn2++],"description": tval104[imds2++],"fieldType": "DATE"});
                            if (tval105.length >= i) field[5][0].mixedType.push({"number": tval105[imdsn3++],"description": tval106[imds3++],"fieldType": "SINGLE_SELECTION_ENUM"});
                            if (tval107.length >= i) field[5][0].mixedType.push({"number": tval107[imdsn4++],"description": tval108[imds4++],"fieldType": "MULTIPLE_SELECTION_ENUM"});
                        }
                    }
                }
            }
        }
        if (checkval7 == true) {
            for (var i = 0; i <= 100; i++) {
                if ($('input[name="tsysnumber'+ i +'"').val () > '') {
                    field[fap++] = [{
                        "number": tval110sys[intvar1++],
                        "name": tval111sys[intvar2++],
                        "description": tval112sys[intvar3++],
                        "fieldType": "SYSTEM",
                        "required": tval8[intvar4++],
                        "notShow": tval9[intvar5++],
                        "noAccessUserRoles": [tval15one[intvar6++],tval15two[intvar7++],tval15three[intvar8++],tval15four[intvar9++],tval15five[intvar10++],tval15six[intvar11++]],
                        "fieldEnumId": tval17
                    }];
                }
            }
        }
        var carts = {
            "name": tval1,
            "description": tval2,
            "confirmChanges": tval3,
            "onlyOwner": tval4,
            "userRoles": tval5,
            "stateIdBefore": tval12,
            "stateIdAfter": tval13,
            "fields": field
        };
        var tval5l = tval5.length - 1;
        for (var i = 0; i <= 100; i++) {
            if (tval5l == i) {
                carts.userRoles.push(tval5[i]);
            }
        }
        if (field.length == 1) carts.fields.push(field[0]);
        alert (JSON.stringify (carts));
        if (tval1 < 1 || tval2 < 1 || tval5.length < 1 || tval12 < 1 || tval13 < 1 || field < 1) {
            alert('Заполните все!');
            location.reload();
        }
        else {
            var url7 = "http://admin.merkurij.pl/site-admin-ws/rest/transitions/add";
            mTransitionsAdd();
            function mTransitionsAdd() {
                $http({
                    url: url7,
                    method: "POST",
                    headers: {
                        Authorization: avt,
                        'Content-Type': 'application/json'
                    },
                    data: carts
                })
                    .then(
                        function successCallback(response) {
                            alert('Все успешно добавлено!');
                            localStorage.removeItem (1);
                            location.reload();
                            return true;
                        },
                        function errorCallback(response) {
                            if (response.status == 400) {
                                alert(response.data.description);
                                location.reload();
                            } else if (response.status == 401) {
                                alert("Invalid username or password!");
                                location.reload();
                            }
                            return false;
                        });
            }
        }
    }
});

/*var valall1 = val3 + '+' + val5 + '+' + val7 + '+' + val9 + '+' + val11 + '+' + val13 + '+' + val15 + '+' + val17 + '+' + val19 + '+' + val21;
    var vals1 = valall1.split('+');
    var valall2 = val4 + '+' + val6 + '+' + val8 + '+' + val10 + '+' + val12 + '+' + val14 + '+' + val16 + '+' + val18 + '+' + val20 + '+' + val22;
    var vals2 = valall2.split('+');*/

/*$("input[name='val1']").val (), $("input[name='val2']").val (), $("input[name='val3']").val (), $("input[name='val4']").val (), $("input[name='val5']").val (), $("input[name='val6']").val (), $("input[name='val7']").val (), $("input[name='val8']").val (), $("input[name='val9']").val (), $("input[name='val10']").val (), $("input[name='val11']").val (), $("input[name='val12']").val (), $("input[name='val13']").val (), $("input[name='val14']").val (), $("input[name='val15']").val (), $("input[name='val16']").val (), $("input[name='val17']").val (), $("input[name='val18']").val (), $("input[name='val19']").val (), $("input[name='val20']").val ()*/

/*for (var i = 0; i <= 20; i++)
        vals[i] = $("input[name='val"+ i +"']").val ();*/
/*
 [{"name": vals[1],"description": vals[2]}, {"name": " "+vals[3],"description": vals[4]}, {"name": "  "+vals[5],"description": vals[6]}, {"name": vals[7]+" ","description": vals[8]}, {"name": vals[9]+"  ","description": vals[10]}, {"name": vals[11]+"   ","description": vals[12]}, {"name": vals[13]+"    ","description": vals[14]}, {"name": vals[15]+"     ","description": vals[16]}, {"name": vals[17]+"      ","description": vals[18]}, {"name": vals[19]+"       ","description": vals[20]}]*/

 /*[{"name": vals[1],"description": vals[2]}, {"name": " "+vals[3],"description": vals[4]}, {"name": "  "+vals[5],"description": vals[6]}, {"name": vals[7]+" ","description": vals[8]}, {"name": vals[9]+"  ","description": vals[10]}, {"name": vals[11]+"   ","description": vals[12]}, {"name": vals[13]+"    ","description": vals[14]}, {"name": vals[15]+"     ","description": vals[16]}, {"name": vals[17]+"      ","description": vals[18]}, {"name": vals[19]+"       ","description": vals[20]}]*/

 /*for (var i = 0; i <= response.data.length; i++) {
                var rdvl = response.data[i].values.length;
                $('body').append ('<div class="line"></div><ul class="dob"><label>Перечесление:</label><li><input class="input" type="text" value="'+ response.data[i].name +'" /><input class="input" type="text" value="'+ response.data[i].description +'" /></li><label>Значения:</label>');
                for (var j = 0; j < rdvl; j++) {
                    $('.dob').append ('<li><input class="input" type="text" value="'+ response.data[i].values[j].name +'" /><input class="input" type="text" value="'+ response.data[i].values[j].description +'" /></li></ul>');
                }
        }*/

/*var tval5t = $("input[name='tuser']").val ();
var tval5 = new Array (tval5t.split(",")[0], tval5t.split(",")[1], tval5t.split(",")[2]);*/

/*var field;
if ($('#fid1').prop('checked')) {
  field = [{
      "number": 1,
      "name": tval6,
      "description": tval7,
      "fieldType": "STRING",
      "required": tval8,
      "notShow": tval9,
      "noAccessUserRoles": [
        tval5[0]
      ]
    }];
} 
if ($('#fid2').prop('checked')) {
  field = [{
      "number": 2,
      "name": tval6,
      "description": tval7,
      "fieldType": "MIXED",
      "required": tval8,
      "notShow": tval9,
      "noAccessUserRoles": [
        tval5[0]
      ],
      "mixedType": [
        {
          "number": 1,
          "description": tval10,
          "fieldType": "STRING"
        },
        {
          "number": 2,
          "description": tval11,
          "fieldType": "INT"
        }
      ]
    }];
}
if ($('#fid3').prop('checked')) {
  field = [{
      "number": 3,
      "name": tval6,
      "description": tval7,
      "fieldType": "SINGLE_SELECTION_ENUM",
      "required": tval8,
      "notShow": tval9,
      "noAccessUserRoles": [
        tval5[0]
      ],
      "fieldEnumId": 67
    }];
}*/