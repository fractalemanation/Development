siteAdminLogin.controller('LogoutController', function($scope,$http) {
	postJSON($scope,$http,"/authorization/logout", null,
		function(data){
			deleteTokenWithRole();
			deleteRememberMeInfo();
            if (history && history.pushState) {
                history.pushState(null, null, location.href);
            }
			window.onpopstate = function(event) {
			    history.go(1);
			};
			redirectToLogin();
		}
	);
});
