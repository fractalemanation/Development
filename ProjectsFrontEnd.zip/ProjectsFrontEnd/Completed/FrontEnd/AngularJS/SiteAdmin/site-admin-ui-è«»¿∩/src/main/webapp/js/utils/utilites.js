siteAdminApp.service('utility', function () {
	return {
		awaitLoading: function (releaseFunction, parties) {
			var _parties = parties;
			var _ready = 0;
			var _releaseFunction = releaseFunction;
			return {
				await: function () {
					_ready++;
					if (_ready === _parties) {
						release();
					}
				}
			};
			function release() {
				_ready = 0;
				window.setTimeout(_releaseFunction, 1);
			}
		},
		isCurrentDay : function(date) {
			var momentDate = moment(date);
			var currentDate = moment();
			if (currentDate.isSame(momentDate,'year') && currentDate.isSame(momentDate, 'month') && currentDate.isSame(momentDate,'day')) {
				return true;
			}
			return false;
		},
		restoreFilters: function($scope) {
			$scope.filter = angular.copy($scope.stableFilter);
			var dateRangeElement = $('#daterangePicker').data('daterangepicker');
			dateRangeElement.setStartDate(new Date($scope.stableFilter.start));
			dateRangeElement.setEndDate(new Date($scope.stableFilter.end));
			$scope.dateRangeString = dateRangeElement.chosenLabel;
			//$scope.$apply();
		}
	}
});

function escapeBrackets(val) {
	if (val != null || val != undefined) {
		if (typeof val == 'string') {
			return val.replace(/</g, '&lt;').replace(/>/g, '&gt;');
		}
	}
	return val;
}

function arrayEscapeBrackets(arrayObject) {
	for (var line in arrayObject) {
		for (var dataLine in arrayObject[line]) {
			arrayObject[line][dataLine] = escapeBrackets(arrayObject[line][dataLine]);
		}
	}
}

function postJSON($scope,$http,uri, data, successCallback, errorCallback) {
	var token = readToken();
	if (token == null) {
		redirectToLogin();
		return;
	}
	registerRestCall("POST", uri);
	var responsePromise = $http.post(wsBaseUri + uri, data, {headers: {"x-token":token, "salt": $scope.salt}});
	responsePromise.success(function(data) {
		registerSuccess("POST", uri, data);
		successCallback(data);
	});
	responsePromise.error(function(data, status) {
		registerError("POST", uri, data, status);
		if (status == 403) {
			redirectToLogin();
		} else if (status == 410) {
			successCallback(data);
		} else if (status == 500) {
			showErrorMessage(data)
		} else {
			if (errorCallback) errorCallback(data,status);
		}
	});
}

function postJSONWithCallback($scope, $http, uri, data, successCallback, errorCallback) {
	var filterData = localStorage.getItem(uri);
	if (filterData) {
		successCallback(strJsonToObject(filterData));
	} else {
		var successCallbackWithStore = function () {
			if (arguments[0] !== undefined) {
				localStorage.setItem(uri, JSON.stringify(arguments[0]));
			}
			successCallback.apply(this, arguments);
		};
		postJSON($scope,$http,uri, data, successCallbackWithStore, errorCallback);
	}
}

function getJSONWithJQuery($scope, uri, successCallback, errorCallback) {
	var token = readToken();
	if (token == null) {
		redirectToLogin();
		return;
	}
	$.ajax({
		url : wsBaseUri + uri,
		type : "GET",
		dataType : "json",
		contentType : "application/json; charset=utf-8",
		headers: {
			"x-token": token,
            "salt": $scope.salt
//			"gmtOffset": getClientGmtOffset(),
//			"zone" : jstz.determine().name()
		},
		success : successCallback,
		error: errorCallback
	});
}

function postJSONWithJQuery(uri, data, successCallback, errorCallback) {
	var token = readToken();
	if (token == null) {
		redirectToLogin();
		return;
	}
	$.ajax({
		url : wsBaseUri + uri,
		type : "POST",
		dataType : "json",
		contentType : "application/json; charset=utf-8",
		headers: {
			"x-token": token,
//			"gmtOffset": getClientGmtOffset(),
//			"zone" : jstz.determine().name()
		},
		data : JSON.stringify(data),
		success : successCallback,
		error: errorCallback
	});
}

function log(message) {
	if ( window.console && window.console.log ) {
		console.log(message);
	} else {
		alert(message);
	}
}

function getJSON($scope,$http,uri, successCallback) {
	var token = readToken();
	if (token == null) {
		redirectToLogin();
		return;
	}
	var responsePromise = $http.get(wsBaseUri + uri, {headers: {"x-token":token, "salt": $scope.salt}});
	responsePromise.success(successCallback);
	responsePromise.error(function(data, status) {
		if (status == 403) {
			redirectToLogin();
		} else if (status == 410) {
			successCallback(data)
		} else if (status == 500 || status == 503) {
			showErrorMessage(data);
//			} else {
//			log("ERROR: status " + status + ". Response: " + data);
		}
	});
}

function findInArray(array, value) {
	for(var i=0; i<array.length; i++) {
		if (array[i] == value) return i;
	}
	return -1;
}

function long2DateStr(timeInMillis) {
	//TODO: timezone support
	var a = new Date(timeInMillis);
	var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
	return "{0}/{1}/{2} {3}:{4}:{5} {6}".format(
			months[a.getMonth()],
			a.getDate().pad(2),
			a.getFullYear().pad(4),
			!a.getHours()? "12":( a.getHours()<=12? a.getHours().pad(2):(a.getHours() -12).pad(2) ),
			a.getMinutes().pad(2),
			a.getSeconds().pad(2),
			a.getHours()<12?"AM":"PM"
	);
}

function long2DateWithoutTimeStr(timeInMillis) {
	var a = new Date(timeInMillis);
	var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
	return "{0}/{1}/{2}".format(
			months[a.getMonth()],
			a.getDate().pad(2),
			a.getFullYear().pad(4)
	);
}
function long2BytesString(diskArray){
	if(!diskArray) return "";	
   var units = [" Bytes", " Kb", " Mb", " Gb", " Tb", " Pb" ];
   var result = "";
	for (k=0 ; k<diskArray.length ; k++){
		var size = 1;
		result += diskArray[k].name + ": ";
		for (i=1;i<=6;i++){
		 if (diskArray[k].value<(size*=1024) || i==6){ 
		  result += (diskArray[k].value/(size/1024)).toFixed(2) + units[i-1];
		  break;
		 }		
		}
	  result += " ;  "; 
	}
   return result;
}

//string formatting
if (!String.prototype.format) {
	String.prototype.format = function() {
		var args = arguments;
		return this.replace(/{(\d+)}/g, function(match, number) { 
			return typeof args[number] != 'undefined'
				? args[number]
			: match
			;
		});
	};
}

Number.prototype.pad = function(places) {
	var zero = places - this.toString().length + 1;
	return Array(+(zero > 0 && zero)).join("0") + this;
}


function daysAgo(days) {
	var dateAgo = moment().subtract(days, 'days').startOf('day');
	return dateAgo.valueOf();
}

function endOfDay() {
	var eod = moment().endOf('day');
	return eod.valueOf();
}

function monthAgo() {
	var oneMonthAgo = moment().subtract(1, 'months').startOf('day');
	return oneMonthAgo.valueOf();
}

function weekAgo() {
	var oneWeekAgo = moment().subtract(1, 'weeks').startOf('day');
	return oneWeekAgo.valueOf();
}

function extractStartDate(dateRangeString) {
	return dateRangeString.split(" ")[0];
}

function extractEndDate(dateRangeString) {
	return dateRangeString.split(" ")[2];
}

function dateStringToMillis(dateString) {
	var parts = dateString.split("/");
	var day = parseInt(parts[1]);
	var month = parseInt(parts[0]);
	var year = parseInt(parts[2]);
	return new Date(year, month - 1, day).getTime();
}

function applyBreadCrumbs($scope, controllerName) {
	programEntities.forEach(function(element, index) {
		if (element.controller == controllerName) {
			$scope.crumbs = element.crumbs;
			$scope.lastCrumb = element.lastCrumb;
			return true;
		}
	});
}

function showSuccessConfirmation() {
	$('#success-confirmation').modal('show');
}

function showConfirmationForAction(question, action, cancelAction) {
	$('#confirmation4action #confirm-question').text(question);
	if (action) $('#confirmation4action .ok-button').click(action);
	if (cancelAction) $('#confirmation4action .cancel-button').click(cancelAction);
	$('#confirmation4action').modal('show');
}

function showSuccessMessage(message, action) {
	$('#success-message #text-message').text(message);
	if (action) $('#success-message .ok-button').click(action);
	$('#success-message').modal('show');
}

function showErrorMessage(message, action) {
	$('#error-message #text-message').text(message);
	if (action) $('#error-message .ok-button').click(action);
	$('#error-message').modal('show');
}

function scrollPageToTop() {
	$("html, body").animate({
		scrollTop: 0
	}, 600);
}

function scrollPage() {
	$("html, body").animate({
		scrollTop: 0
	}, 0);
}
function sortByName(array) {
	if (!array || array.length<2) return;
	array.sort(function(a, b){
		var aStr = a.name.toLowerCase();
		var bStr = b.name.toLowerCase();
		if (aStr < bStr) return -1;
		if (aStr > bStr) return 1;
		return 0;
	});
}
function isEmpty(variable) {
	return typeof(variable) === 'undefined' || variable == null;
}

function removeDataRangePicker() {
	for (var i=0; i < $(".daterangepicker").length; i++) {
		$(".daterangepicker").remove();
	}
}
function redirectToLogin() {
	location.href = location.protocol + "//" +location.hostname + (location.port ? ':' + location.port: '') + loginPage;
}

function redirectToHome() {
	var role = readRole();
	if (role == "ADMIN") window.location = "#/command-center.html";
	if (role == "SUPPORT") window.location = "#/command-center.html";
	if (role == "READ") window.location = "#/control-panel.html";
}

function getDefaultRoute() {
	var role = readRole();
	if (role == "ADMIN") return '/command-center/';
	if (role == "SUPPORT") return '/command-center/';
	if (role == "READ") return '/control-panel/';
}

function updateCompanyName(companyName) {
	if (companyName == undefined) {
		var tokenWithRole = readTokenWithRole();
		if (tokenWithRole != null) {
			companyName = tokenWithRole.presentableName;
		}
	} else {
		var userInfoForUpdate = readTokenWithRole();
		userInfoForUpdate.presentableName = companyName;
		saveTokenWithRole(userInfoForUpdate);
	}
	$('#user-name').text(companyName == null ? "" : companyName);
}

function printContent(adjustBeforePrintingCallback, adjustAfterPrintingCallback) {
	var header = $('#header');
	var menu = $('div.vd_navbar');
	var container = $('div.vd_container');
	header.hide();
	menu.hide();
	var margin = parseInt(container.css("margin-left"));
	container.css('marginLeft', '0px');
	if (adjustBeforePrintingCallback) adjustBeforePrintingCallback();
	window.print();
	if (adjustAfterPrintingCallback) adjustAfterPrintingCallback();
	container.css('marginLeft', '' + margin + 'px');
	header.show();
	menu.show();
}

function getDateStartOfDay(date) {
	return moment(moment(date).add(1, 'h')).startOf('day').valueOf();
}
function getDateEndOfDay(date) {
	return moment(moment(date).subtract(1, 'h')).endOf('day').valueOf();
}

function getClientGmtOffset() {
	var jan = new Date(new Date().getFullYear(), 0, 1);
	var gmtHours = -jan.getTimezoneOffset() / 60;
	//console.log("The local time zone is: GMT " + gmtHours);
	return gmtHours;
}

function recursiveEmptyToNotAvailable(data, key) {
    emptyToNotAvailable(data, key);
    if (data[key] instanceof Object) {
        var obj = data[key];
        $.each(obj, function(key) { recursiveEmptyToNotAvailable(obj, key) });
    }
}

function emptyToNotAvailable(data, key) {
    if ((typeof data[key] === "string") && !data[key]) {
        data[key] = "N/A";
    }
}

function recursiveNotAvailableToEmpty(data, key) {
    notAvailableToEmpty(data, key);
    if (data[key] instanceof Object) {
        var obj = data[key];
        $.each(obj, function(key) { recursiveNotAvailableToEmpty(obj, key) });
    }
}

function notAvailableToEmpty(data, key) {
    if (data[key] == "N/A") {
        data[key] = "";
    }
}

function updateProfile($scope, $http, url, $location, isCreate, isCurrentUserChanged) {
    var sendingData = $scope.user;
    postJSON($scope, $http, url, sendingData, function () {
        if (!isCreate) {
            showSuccessMessage("User details changed successfully");
        }
        $location.path((!isCreate && isCurrentUserChanged) ? "/logout" : "/permissions");
    }, function (data) {
		$('#saveUser').modal('hide');
        $scope.profileSubmitted = true;
        showUserMessage('userError', data);
    });
}

function isTableSorted(aoData, defaultColumn, defaultOrder) {
	var sortColumn = getParamValueByKey(aoData, "iSortCol_0");
	var sortOrder = getParamValueByKey(aoData, "sSortDir_0");

	return (sortColumn != defaultColumn) || (sortOrder != defaultOrder);
}

function getParamValueByKey(aoData, paramKey) {
	var paramValue = "";
	for(var index in aoData) {
		if (aoData[index].name == paramKey) {
			paramValue = aoData[index].value;
			break;
		}
	}
	return paramValue;
}

function copyArray(array) {
	var result = [];
	for ( var i in array) result.push(array[i]);
	return result;
}

function copyArrayOfArrays(array) {
	return copyArrayOfArraysAbs(array, false);
}

function copyArrayOfArraysAbs(array, isAbs) {
	var result = [];
	for ( var i in array) {
		var element = [];
		for ( var j in array[i]) {
			if ((isAbs == true) && (array[i][j] < 0)) {
				element.push(-array[i][j]);
			} else {
				element.push(array[i][j]);
			}
		}
		result.push(element);
	}
	return result;
}

function showDataTableColumn(dataTableId, columnIndex, isVisible) {
	$("#" + dataTableId).DataTable().column(columnIndex).visible(isVisible);
}

function getPrefixUrl() {
	return window.location.href.indexOf("uwdg-ui") > -1 ? "/uwdg-ui" : "";
}

var calls=[];
function registerRestCall(method, uri) {
	getOrCreateCall(method, uri).counter++;
}
function registerError(method, uri) {
	getOrCreateCall(method, uri).counter--;
}
function registerSuccess(method, uri) {
	getOrCreateCall(method, uri).counter--;
}
function getOrCreateCall(method, uri) {
	var s = null;
	for (var i=0; i < calls.length; i++) {
		s = calls[i];
		if (s.method == method && s.uri == uri) break;
	}
	if (s == null) {
		s = {method:method, uri:uri, counter: 0};
		calls.push(s);
	}
	return s;
}
function isThereAnyRestCallsInProgress() {
	for (var i=0; i < calls.length; i++) {
		var s = calls[i];
		if (s.counter > 0) return true;
	}
	return false;
}

function getPrettyJson(originalString){

    var stringifiedJson = JSON.stringify(JSON.parse(originalString), null, 4);

    var prerittyfied = stringifiedJson.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
        var cls = 'number';
        if (/^"/.test(match)) {
            if (/:$/.test(match)) {
                cls = 'key';
            } else {
                cls = 'string';
            }
        } else if (/true|false/.test(match)) {
            cls = 'boolean';
        } else if (/null/.test(match)) {
            cls = 'null';
        }
        return '<span class="' + cls + '">' + match + '</span>';
    });

   return prerittyfied;
}

function switchTab(tab) {
		$("#user-management-tab").removeAttr("class");
		$("#systems-tab").removeAttr("class");
		$("#command-center-tab").removeAttr("class");
		$("#system-status-tab").removeAttr("class");
		$("#notification-management-tab").removeAttr("class");
		$("#control-panel-tab").removeAttr("class");
		$(tab).attr("class", "active");
}

function prepareDataForLineChart(data) {
	var result = [];
	$.each(data, function(key, value) {
		var record = [];
		record.push(value.key);
		record.push(value.value);
		result.push(record);
	});
	return result;
}

function showEmptyChart(id) {
//	$("#" + id).empty();
	$("#" + id + "-body").hide();
	$("#" + id + "-header").hide();
	$("#" + id + "-empty").show();
}

function showPopUpMessage(element) {
	var elem = element;
	if (element[0] != '#') {
		elem = '#'+ element;
	}
	$(elem).show();
	$(elem).fadeTo(3000, 500).slideUp(500, function(){
        $(elem).hide();
    });
}

function getSalt() {
    return Date.now();
}

function ignoreRequestsForScreen(screenType, salt) {
    if (isThereAnyRestCallsInProgress()) postJSONWithJQuery("/long-query/" + screenType + "/stop/" + salt);
}

