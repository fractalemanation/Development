﻿<?php
$recepient = "danyy385@gmail.com";
$sitename = "artcreamer.com";

$name = trim($_POST["name"]);
$email = trim($_POST["email"]);
$phone = trim($_POST["phone"]);
$text = trim($_POST["text"]);
$message = "Имя: $name \nEmail: $email \nТелефон: $phone \nТекст: $text";

$pagetitle = "Новая заявка с сайта \"$sitename\"";
mail($recepient, $pagetitle, $message, "From: admin@gmail.com");
mail($email, $pagetitle, "Ваш отзыв успешно отправлен!\n".$message, "From: admin@visat-sumy.com");
?>