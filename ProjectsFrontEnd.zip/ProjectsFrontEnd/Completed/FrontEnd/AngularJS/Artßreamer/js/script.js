$(document).ready (function () {
		$('#form').validate({   
rules:{
	"reg_captcha":{
		required:true,
		remote: {
			type: "post",
			url: "/include/check_captcha.php"
		}
	},
	"email":{
		required:true,
		email:true
	}
},
messages:{
	"reg_captcha":{
		required:"Введите код!",
		remote: "Неверный код!"
	},
	"email":{
		required:"Укажите свой E-mail",
		 email:"Не корректный E-mail"
		}
	},
	submitHandler: function(form){
		$(form).ajaxSubmit({
			success: function() {
				swal("Ваше сообщение успешно отправлено!");
				$('#block-captcha > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
				$(".cvalue").val("");
			} 
		});
	}
});
$('#reloadcaptcha').click(function() {
	$('#block-captcha > img').attr("src", "/include/reg_captcha.php?r=" + Math.random());
});

	 var $inputs = $('.container').find('input');
     var intervals = setInterval(function(){
         $next = $inputs.filter(":checked").next('input');
         if ($next.length) $next.prop('checked', true);
         else $inputs.first().prop('checked', true);
     }, 5000);
});

var App = angular.module('route', ['ngRoute'])
.factory('pagination', function( $sce ) {
	var currentPage = 0;
	var itemsPerPage = 10;
	var products = [];
	return {
		setProducts: function( newProducts ) {
			products = newProducts
		},
		getPageProducts: function(num) {
			var num = angular.isUndefined(num) ? 0 : num;
			var first = itemsPerPage * num;
			var last = first + itemsPerPage;
			currentPage = num;
			last = last > products.length ? products.length : last;
			return products.slice(first, last);
		},
		getTotalPagesNum: function() {
			return Math.ceil( products.length / itemsPerPage );
		},
		getPaginationList: function() {
			var pagesNum = this.getTotalPagesNum();
			var paginationList = [];
			paginationList.push({
				name: $sce.trustAsHtml('&laquo;'),
				link: 'prev'
			});
			for (var i = 0; i < pagesNum; i++) {
				var name = i + 1;
				paginationList.push({
					name: $sce.trustAsHtml( String(name) ),
					link: i
				});
			};
			paginationList.push({
				name: $sce.trustAsHtml('&raquo;'),
				link: 'next'
			});
			if (pagesNum > 2) {
				return paginationList;
			}else {
				return null;
			}
		},
		getPrevPageProducts: function() {
			var prevPageNum = currentPage - 1;
			if ( prevPageNum < 0 ) prevPageNum = 0;
			return this.getPageProducts( prevPageNum );
		},
		getNextPageProducts: function() {
			var nextPageNum = currentPage + 1;
			var pagesNum = this.getTotalPagesNum();
			if ( nextPageNum >= pagesNum ) nextPageNum = pagesNum - 1;
			return this.getPageProducts( nextPageNum );
		},
		getCurrentPageNum: function() {
			return currentPage;
		},
	}
});

App.config(['$routeProvider', function($routeProvide) {
	$routeProvide
	.when('/',{
		templateUrl:'temp/main.html',
		controller:'MainController'
	})
	.when('/videos',{
		templateUrl:'temp/videos.html',
		controller:'VideosController'
	})
	.when('/news',{
		templateUrl:'temp/news.html',
		controller:'NewsController'
	})
	.when('/bestGames',{
		templateUrl:'temp/bestGames.html',
		controller:'BestGamesController'
	})
	.when('/timeTable',{
		templateUrl:'temp/timeTable.html',
		controller:'TimeTableController'
	})
	.when('/advertising',{
		templateUrl:'temp/advertising.html',
		controller:'AdvertisingController'
	})
	.when('/mems',{
		templateUrl:'temp/mems.html',
		controller:'MemsController'
	})
	.when('/mounting',{
		templateUrl:'temp/mounting.html',
		controller:'MountingController'
	})
	.when('/about',{
		templateUrl:'temp/about.html',
		controller:'AboutController'
	})
	.when('/feedback',{
		templateUrl:'temp/feedback.html',
		controller:'BackController'
	})
	.otherwise({
		redirectTo: '/'
	});
}]);

App.controller('MainController', function( $scope, $http, pagination ){
	$http.get('getController/videos.json').success(function(data){
		$scope.videos = data;
	});

	$http.get('getController/news.json').success(function(data){
		$scope.news = data;
	});
});

App.controller('VideosController', function( $scope, $http, pagination ){
	$http.get('getController/videos.json').success(function(data){
		$scope.menuObj = data;
		pagination.setProducts( data.products );
		$scope.products = pagination.getPageProducts( $scope.currentPage );
		$scope.paginationList = pagination.getPaginationList();
	});
	$scope.showPage = function(page) {
		if ( page == 'prev' ) {
			$scope.products = pagination.getPrevPageProducts();
		}else if ( page == 'next' ) {
			$scope.products = pagination.getNextPageProducts();
		}else {
			$scope.products = pagination.getPageProducts( page );
		}
	}
	$scope.currentPageNum = function() {
		return pagination.getCurrentPageNum();
	}
});

App.controller('NewsController', function( $scope, $http, pagination ){
	$http.get('getController/news.json').success(function(data){
		$scope.menuObj = data;
		pagination.setProducts( data.products );
		$scope.products = pagination.getPageProducts( $scope.currentPage );
		$scope.paginationList = pagination.getPaginationList();
	});
	$scope.showPage = function(page) {
		if ( page == 'prev' ) {
			$scope.products = pagination.getPrevPageProducts();
		}else if ( page == 'next' ) {
			$scope.products = pagination.getNextPageProducts();
		}else {
			$scope.products = pagination.getPageProducts( page );
		}
	}
	$scope.currentPageNum = function() {
		return pagination.getCurrentPageNum();
	}
});

App.controller('BestGamesController', function( $scope, $http, pagination ){
	$http.get('getController/bestGame.json').success(function(data){
		$scope.menuObj = data;
		pagination.setProducts( data.products );
		$scope.products = pagination.getPageProducts( $scope.currentPage );
		$scope.paginationList = pagination.getPaginationList();
	});
	$scope.showPage = function(page) {
		if ( page == 'prev' ) {
			$scope.products = pagination.getPrevPageProducts();
		}else if ( page == 'next' ) {
			$scope.products = pagination.getNextPageProducts();
		}else {
			$scope.products = pagination.getPageProducts( page );
		}
	}
	$scope.currentPageNum = function() {
		return pagination.getCurrentPageNum();
	}
});

App.controller('TimeTableController', function( $scope, $http, pagination ){
});

App.controller('AdvertisingController', function( $scope, $http, pagination ){
});

App.controller('MountingController', function( $scope, $http, pagination ){
});

App.controller('MemsController', function( $scope, $http, pagination ){
	$http.get('getController/mems.json').success(function(data){
		$scope.menuObj = data;
		pagination.setProducts( data.products );
		$scope.products = pagination.getPageProducts( $scope.currentPage );
		$scope.paginationList = pagination.getPaginationList();
	});
	$scope.showPage = function(page) {
		if ( page == 'prev' ) {
			$scope.products = pagination.getPrevPageProducts();
		}else if ( page == 'next' ) {
			$scope.products = pagination.getNextPageProducts();
		}else {
			$scope.products = pagination.getPageProducts( page );
		}
	}
	$scope.currentPageNum = function() {
		return pagination.getCurrentPageNum();
	}
});

App.controller('BackController', function( $scope, $http, pagination ){
});