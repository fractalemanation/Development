$('.sl').slick({
	autoplay: true,
	autoplaySpeed: 2500
});
$('.sl2').slick({
	autoplay: true,
	autoplaySpeed: 2500,
	dots: true,
	draggable: false,
	arrows: false,
	infinite: false,
	pauseOnHover: false,
	pauseOnDotsHover: false,
	PauseOnFocus: false,
	cssEase: 'ease-in'
});
$('.si').click(function() {
	$('#reg').slideDown(400);
	$('#sign').hide();
});
$('.button_start').click(function() {
	$('#reg').slideDown(400);
	$('#sign').hide();
});
$('#deletedr').click(function() {
	$('#reg').slideUp(300);
});

$('.sin').click(function() {
	$('#sign').slideDown(400);
	$('#reg').hide();
});
$('#deleted').click(function() {
	$('#sign').slideUp(300);
});

$('.log').click(function() {
	$('#sign').slideDown(400);
	$('#reg').hide();
});
$('.li').click(function() {
	$('#reg').slideDown(400);
	$('#sign').hide();
});

$('.sigu').click(function() {
	$('#reg').slideDown(400);
	$('#sign').hide();
});
$('.su').click(function() {
	$('#sign').slideDown(400);
	$('#reg').hide();
});

$('#remindpass').click(function() {
	$('#passres').slideDown(400);
	$('#sign').hide();
});
$('#delete').click(function() {
	$('#passres').slideUp(300);
});
$('.back').click(function() {
	$('#sign').slideDown(400);
	$('#passres').hide();
});

$('#submitRegistration').click(function() {
	if ($('#loginRegistration').val() > '' && $('#passwordRegistration').val() > '' && $('#emailRegistration').val() > '' && $('#regbox').prop('checked')) {
		localStorage.setItem('login', $('#loginRegistration').val());
		localStorage.setItem('password', $('#passwordRegistration').val());
		localStorage.setItem('email', $('#emailRegistration').val());
		$('#sign').slideDown(400);
		$('#reg').hide();
	}
});
$('#submitLog').click(function() {
	if ($('#loginLog').val() > '' && $('#passwordLog').val() > '') {
		if ($('#loginLog').val() == localStorage.getItem('login')) {
			if ($('#passwordLog').val() == localStorage.getItem('password')) {
				if ($('#remind').prop('checked')) {
					$('#sign').slideUp(300);
					$('.sin').hide();
					$('.si').hide();
					$('#block-sis').append('<a class="sinam" href="#/profile">Hello, '+localStorage.getItem('login')+'</a><div class="silog">Logout</div>');
					setTimeout('localStorage.clear()', 600000);
				} else {
					$('#sign').slideUp(300);
					$('.sin').hide();
					$('.si').hide();
					$('#block-sis').append('<a class="sinam" href="#/profile">Hello, '+localStorage.getItem('login')+'</a><div class="silog">Logout</div>');
				}
			} else {
				alert('Incorect password!');
			}
		} else {
			alert('Incorect login!');
		}
	}
});
$(document).on("click", ".silog", function() {
	localStorage.clear();
	$('.sinam').hide();
	$('.silog').hide();
	$('.sin').show();
	$('.si').show();
	document.location.href = "#/";

});
if (!localStorage.getItem('login')) {
	$('.sinam').hide();
	$('.silog').hide();
	$('.sin').show();
	$('.si').show();
} else {
	$('.sin').hide();
	$('.si').hide();
	$('#block-sis').append('<a class="sinam" href="#/profile">Hello, '+localStorage.getItem('login')+'</a><div class="silog">Logout</div>');
}
$('#sendReset').click(function() {
	if ($('#emailRegistration').val() > '') {
		if ($('#emailRegistration').val() == localStorage.getItem('email')) {
			var random = Math.floor(Math.random() * (1000000 - 100000 + 1)) + 100000;
			localStorage.setItem('password', random);
			alert('New your password: '+random);
			$('#sign').slideDown(400);
			$('#passres').hide();
		} else {
			alert('Incorect email!');
		}
	}
});
$('#submitSave').click(function() {
		if ($('#loginProfile').val() > '') localStorage.setItem('login', $('#loginProfile').val());
		if ($('#passwordProfile').val() > '') localStorage.setItem('password', $('#passwordProfile').val());
		if ($('#emailProfile').val() > '') localStorage.setItem('email', $('#emailProfile').val());
		$('.sinam').hide();
		$('.silog').hide();
		$('#block-sis').append('<a class="sinam" href="#/profile">Hello, '+localStorage.getItem('login')+'</a><div class="silog">Logout</div>');
});

$("select[name='lang']").on('change', function(){
x = $("select[name='lang']").val();
if (x == "1") {
	document.location.href = "#/";
}
else if (x == "2") {
	document.location.href = "#/mrus";
}
});

var phonecatApp = angular.module('route', ['ngRoute']);

phonecatApp.config(['$routeProvider', function($routeProvide) {
	$routeProvide
	.when('/',{
		templateUrl:'temp/meng.html',
		controller:'routeOne'
	})
	.when('/mrus',{
		templateUrl:'temp/mrus.html',
		controller:'routeSecond'
	})
	.when('/document',{
		templateUrl:'temp/document.html',
		controller:'document'
	})
	.when('/readMore',{
		templateUrl:'temp/readMore.html',
		controller:'readMore'
	})
	.when('/custom',{
		templateUrl:'temp/custom.html',
		controller:'custom'
	})
	.when('/web',{
		templateUrl:'temp/web.html',
		controller:'web'
	})
	.when('/video',{
		templateUrl:'temp/video.html',
		controller:'video'
	})
	.when('/partner',{
		templateUrl:'temp/partner.html',
		controller:'partner'
	})
	.when('/profile',{
		templateUrl:'temp/profile.html',
		controller:'profile'
	})
	.otherwise({
		redirectTo: '/'
	});
}]);

phonecatApp.controller('routes',['$scope','$http','$location', function($scope, $http, $location) {}]);
phonecatApp.controller('routes',['$scope','$http','$location', function($scope, $http, $location) {}]);
phonecatApp.controller('document',['$scope','$http','$location', function($scope, $http, $location) {}]);
phonecatApp.controller('readMore',['$scope','$http','$location', function($scope, $http, $location) {}]);
phonecatApp.controller('custom',['$scope','$http','$location', function($scope, $http, $location) {}]);
phonecatApp.controller('web',['$scope','$http','$location', function($scope, $http, $location) {}]);
phonecatApp.controller('video',['$scope','$http','$location', function($scope, $http, $location) {}]);
phonecatApp.controller('partner',['$scope','$http','$location', function($scope, $http, $location) {}]);
phonecatApp.controller('profile',['$scope','$http','$location', function($scope, $http, $location) {
	if (localStorage.length <= 2) document.location.href = "#/";
	$('#loginProfile').val(localStorage.getItem('login'));
	$('#passwordProfile').val(localStorage.getItem('password'));
	$('#emailProfile').val(localStorage.getItem('email'));
}]);

/*$(document).ready(function() {
    $('#block-body').scrollTop(0);
});
window.onload = function() {
	window.scrollTo(0, 0);
}*/