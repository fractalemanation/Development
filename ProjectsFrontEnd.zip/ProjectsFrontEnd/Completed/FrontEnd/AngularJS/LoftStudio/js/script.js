$('.sl').slick({
	autoplay: true,
	autoplaySpeed: 2500
});

$(".image-modal").fancybox();

$('.geolm').click(function() {
	$('#ifm1').slideDown(500);
});
$('#del1').click(function() {
	$('#ifm1').slideUp(400);
});

var app = angular.module('app', ['ngRoute']);
app.config(['$routeProvider', function($routeProvide) {
	$routeProvide
	.when('/',{
		templateUrl:'temp/main.html',
		controller:'Ctrl'
	})
	.when('/catalog',{
		templateUrl:'temp/catalog.html',
		controller:'CatalogCtrl'
	})
	.when('/price',{
		templateUrl:'temp/price.html',
		controller:'PriceCtrl'
	})
	.when('/gallery',{
		templateUrl:'temp/gallery.html',
		controller:'GalleryCtrl'
	})
	.when('/certificates',{
		templateUrl:'temp/certificates.html',
		controller:'CertificatesCtrl'
	})
	.when('/mozaika',{
		templateUrl:'temp/mozaika.html',
		controller:'MozaikaCtrl'
	})
	.when('/catalog/:itemId',{
		templateUrl:'temp/cat.html',
		controller:'CatCtrl'
	})
	.otherwise({
		redirectTo: '/'
	});
}]);
app.controller('Ctrl',['$scope','$http','$location', function($scope, $http, $location) {
	$http.get('adminPanel/main.json').success(function(data, status, headers, config) {
		$scope.main = data;
	});
}]);
app.controller('CatalogCtrl',['$scope','$http','$location', function($scope, $http, $location) {
	$http.get('adminPanel/catalog.json').success(function(data, status, headers, config) {
		$scope.catalogs = data;
	});
}]);
app.controller('PriceCtrl',['$scope','$http','$location', function($scope, $http, $location) {
	$http.get('adminPanel/price.json').success(function(data, status, headers, config) {
		$scope.prices = data;
	});
}]);
app.controller('GalleryCtrl',['$scope','$http','$location', function($scope, $http, $location) {
	$http.get('adminPanel/gallery.json').success(function(data, status, headers, config) {
		$scope.gallery = data;
	});
}]);
app.controller('MozaikaCtrl',['$scope','$http','$location', function($scope, $http, $location) {
	$('.element2').hide();
	$('.button1').click(function() {
		$('.element1').slideToggle(500);
		$('.element2').hide();
	});
	$('.button2').click(function() {
		$('.element2').slideToggle(500);
		$('.element1').hide();
	});
	$http.get('adminPanel/mozaika.json').success(function(data, status, headers, config) {
		$scope.mozaikas = data;
	});
}]);
app.controller('CertificatesCtrl',['$scope','$http','$location', function($scope, $http, $location) {
	$http.get('adminPanel/certificates.json').success(function(data, status, headers, config) {
		$scope.certificates = data;
	});
}]);
app.controller('CatCtrl',['$scope','$http','$location', '$routeParams', function($scope, $http, $location, $routeParams) {
	$scope.itemId = $routeParams.itemId;
	var url = 'adminPanel/'+$routeParams.itemId+'.json';
	
	$http.get(url).success(function(data) {
		$scope.item = data;
	});
}]);

app.directive('fancybox', function ($compile, $http) {
    return {
        restrict: 'A',
        controller: function($scope) {
            $scope.openFancybox = function (url) {
                    $http.get(url).then(function(response) {
                        if (response.status == 200) {
                            var template = angular.element(response.data);
                            var compiledTemplate = $compile(template);
                            compiledTemplate($scope);
                            $.fancybox.open({ content: template, type: 'html' });
                        }
                    });
            };
        }
    };
});