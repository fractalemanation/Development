﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Формат JSON - 3</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script>
$(document).ready( function() {
	$("select[name='country']").bind("change", function ()/*change это параметр которые применяется при изменении значения выбора*/ {
		$("select[name='city']").empty();/*empty очищает элемент если пользователь ничего не выбрал*/
		$.get("country-3.php", {country: $("select[name='country']").val()}, function (data)/*Функция срабатывает при успешном получении данных*/ {
			data = JSON.parse(data);/*JSON.parse преобразовывет данные массива с php на JavaScript, для того мы и использовали в php функцию json*/
			for (var id in data) {/*Перебираем в цикле ключи и их значения*/
				$("select[name='city']").append($("<option value='" + id + "'>" + data[id] + "</option>"));/*Подставляем в value ключи массива и потом указываем значения данного ключа*/
			}
		});
	});
});/*Метод get это ajax уже с установленным типом*/
</script>
</head>
<body>
<label>Укажите страну:</label>
<select name="country">
<option value="0" selected="selected"></option>
<option value="1">Америка</option>
<option value="2">Франция</option>
</select>
<label>Города:</label>
<select name="city">
<option value="0"></option>
</select>
</body>
</html>