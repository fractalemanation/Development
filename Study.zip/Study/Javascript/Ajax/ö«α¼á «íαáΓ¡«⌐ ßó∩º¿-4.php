﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Форма обратной связи - 4</title>
<script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
<script type="text/javascript">

$(document).ready(function() {
$("#form").submit(function() {
		$.ajax({
			type: "POST",
			url: "mail-4.php",
			data: $(this).serialize()
		}).done(function() {
			$(this).find("input").val("");
			alert("Спасибо за заявку! Скоро мы с вами свяжемся.");
			$("#form").trigger("reset");
		});
		return false;
	});
});

</script>
</head>
<body>
<form id="form">
<label for="name">Ваше имя</label><br />
<input type="text" name="name" placeholder="Ваше имя" required /><br />
<label for="phone">Ваше телефон</label><br />
<input type="text" name="phone" placeholder="Ваш телефон" required /><br />
<label for="text">Ваше сообщение</label><br />
<textarea name="text" cols="34" rows="10"></textarea><br />
<button>Отправить</button>
</form>
</body>
</html>
