﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Полный контроль - 1</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script>
function funcBefore() {
	$("#information").text("Ожидание данных...");
}
function funcSuccess(data)/*Передаем data, data это информация которая получена со страницы то есть ответ*/ {
	$("#information").text(data);/*Передали что в качестве ответа получим переменные которые указаны в параметре data*/
}

$(document).ready(function () {
	var admin = "Admin";
	$("#load").bind("click", function()/*Указали что при клике будет передоваться функция*/ {
		$.ajax/*Метод ajax все функции выполняются в этом же методе, он выполняет отправку данных, полученые данных то есть то что ожидаем*/ ({
			url: "content-1.php",/*В параметре url указываем куда перенправлять данные, все параметры перечисляются через запятую*/
			type: "POST",/*type устанавливает тип обработки данных*/
			data: ({name: admin, number: 5}),/*data передает переменные, переменные в ajax создаются названием переменной и через двоеточие указание значения переменной, значением переменной может быть другая переменная созданная в JS или новоприсвоеное значение*/
			dataType: "html",/*dataType устанавливает что мы передаем html текст с тегами или же text просто текст*/
			beforeSend: funcBefore,/*beforeSend передает функцию или элемент который будет показываться пока не прийдет ответ, функции указываются только именем без ковычек*/
			success: funcSuccess/*success передает функцию когда пришел ответ положительный или отрицательный, в конце параметров ничего не ставится*/
		});
	});
});
</script>
</head>
<body>
<p id="load" style="cursor:pointer;">Загрузить данные</p>
<div id="information"></div>
</body>
</html>