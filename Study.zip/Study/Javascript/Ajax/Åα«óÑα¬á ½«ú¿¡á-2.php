﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Проверка логина - 2</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script>
$(document).ready(function () {
	$("#done").bind("click", function() {
		$.ajax ({
			url: "check-2.php",
			type: "POST",
			data: ({name: $("#name").val()}),/*Передаем значение поля*/
			dataType: "html",
			beforeSend: function() {/*Сразу передали функцию*/
				$("#information").text("Ожидание данных...");
				$("#information").show();/*Отображаем ожидание данных после того как их скрыли после всплывающего окна*/
			},
			success: function(data) {
				if(data == "Fail") {
					$("#information").hide();/*Скрываем ожидание данных после того как вывели всплывающее окно*/
					alert("Имя занято");/*Заменяем вывод текста через php выводом текста в всплывающе окне*/
				}
				else
					$("#information").text (data);/*Если условие не сработало то выводим значение которые ввел пользователь в поле*/
			}
		});
	});
});
</script>
</head>
<body>
<input type="text" id="name" placeholder="Введите имя" />
<input type="button" id="done" value="Готово" /><br /><br />
<div id="information"></div>
</body>
</html>