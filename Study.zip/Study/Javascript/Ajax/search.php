<?php
define("DB_HOST","localhost");
define("DB_NAME","id250819_host");
define("DB_USER","id250819_root");
define("DB_PASSWORD","diablo0365");
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
$mysqli -> query("SET NAMES 'utf8'") or die ("Ошибка соединения с базой!");

if(!empty($_POST["referal"])){
	$referal = trim(strip_tags(stripcslashes(htmlspecialchars($_POST["referal"]))));
	$db_referal = $mysqli->query("SELECT * FROM vacancies WHERE title LIKE '%$referal%'");
	while ($row = $db_referal->fetch_array()) {echo "\n<li>".$row["title"]."</li>";}
}
?>