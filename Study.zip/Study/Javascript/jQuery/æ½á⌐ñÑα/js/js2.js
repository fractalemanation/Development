$('.sl').slick({
	autoplay: true,
	autoplaySpeed: 1000,
	speed: 500,//Скорость смены с картинки на картнку
	cssEase: 'ease-in',
	centerMode: true,//По углам
	centerPadding: '100px',//Ширина по углам
	dots: true,//Навигация
	//arrows: false, Отключение стрелок
	//fade: true, Сменение затемнением отключает centerMode
	//draggable: false, Отключение перемотки курсора
	//infinite: false Отключение перемотки с первого на последний и наоборот
	//edgeFriction: '0.5' Длинна при перетягивании когда отключена бесконечность
	//pauseOnHover: false, Отключение остановки прокрутки при наведении
	pauseOnDotsHover: true,//Перемотка при наведении на навигацию остановка
	//lazyLoad: 'ondemand', Подгрузка картинок при смене
	//PauseOnFocus: true, Остановка фокусе к примеру на input
	//rtl: true, Смена направления смены картинок
	//vertical: true, Слайд вертикальный
	//rows: 2, Сколько с троку
	//slidesPerRow: 2, При вертикальном если нужно в строку
	//slidesToShow: 3, Сколько видно одновременно слайдов при горизонтальном
	//slidesToScroll: 3, Сколько слайдов перематывается сразу
	zindex: 1,
	responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    }
	]//Адаптивность слайда
});