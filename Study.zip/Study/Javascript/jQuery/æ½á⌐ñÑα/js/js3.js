$('.sl').slick({
	autoplay: true,
	autoplaySlide: 1000,
	asNavFor: '.sl2',//Привязаность слайдера
	initialSlide: 0,//С какого слайда начинать показ
	zindex: 50000
});
$('.sl2').slick({
	dots: true,
	slidesToShow: 7,
	centerMode: true,
	centerPadding: '40px',
	asNavFor: '.sl',
	focusOnSelect: true,//Смена синхронно
	arrows: false,
	responsive: [
	{
		breakpoint: 1100,
		settings: {
			slidesToShow: 6
		}
	},
	{
		breakpoint: 960,
		settings: {
			slidesToShow: 5
		}
	},
	{
		breakpoint: 800,
		settings: {
			slidesToShow: 4
		}
	},
	{
		breakpoint: 640,
		settings: {
			slidesToShow: 3
		}
	},
	{
		breakpoint: 480,
		settings: {
			dots: false,
			slidesToShow: 2,
			centerMode: false
		}
	},
	]
});