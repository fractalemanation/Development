const spoof = () => window.spoofAddBlock = true;
spoof();