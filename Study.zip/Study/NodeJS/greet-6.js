module.exports = greeting => name => `${greeting}, ${name}`;
/*function (greeting) {
	return function (name) {
		return `${greeting}, ${name}`;
	}
}//Если функцию возвращаем сразу, то её имя можно не указывать.*/

/*файл APP - практическое применение
const connection = require('./db')('mongodb://...');

console.log(connection.connectionString);
*/