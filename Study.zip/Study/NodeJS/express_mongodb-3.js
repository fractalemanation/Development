var express = require ('express');
var bodyParser = require ('body-parser');
var MongoClient = require('mongodb').MongoClient;
var ObjectID = require('mongodb').ObjectID;//Раскрываем объект для работы с базой

var app = express ();
var db;

app.use (bodyParser.json());
app.use (bodyParser.urlencoded({extended: true}));

app.get ('/', function (req, res) {
	res.send ('Hello API');
});

app.get ('/artists', function (req, res) {
	db.collection ('artists').find ().toArray (function (err, docs) {
		if (err) {
			console.log (err);
			return res.sendStatus (500);
		}
		res.send (docs);
	});//Извлечение из бд, переводим в массив для извлечения
});

app.get('/artists/:id', function (req, res) {
	db.collection('artists').findOne({ _id: ObjectID(req.params.id) }, function (err, doc) {
		if (err) {
			console.log(err);
			return res.sendStatus(500);
		}
		res.send(doc);
  });//Извлекаем определенный документ с помощью objectID созданный ранее
});

app.post('/artists', function (req, res) {
	var artist = {name: req.body.name};
	db.collection('artists').insert(artist, (err, result) => {
		if (err) {
			console.log(err);
			return res.sendStatus(500);
		}
		res.send(artist);
	});//Добавляем в коллекцию наши данные
});

app.put ('/artists/:id', function (req, res) {
	db.collection ('artists').updateOne ({_id: ObjectID(req.params.id)}, {name: req.body.name}, function (err, result) {
		if (err) {
			console.log (err);
			return res.sendStatus (500);
		}
		res.sendStatus (200);
	});
});

app.delete ('/artists/:id', function (req, res) {
	db.collection ('artists').deleteOne ({_id: ObjectID(req.params.id)}, function (err, result) {
		if (err) {
			console.log (err);
			return res.sendStatus (500);
		}
		res.sendStatus (200);
	});
});

MongoClient.connect('mongodb://localhost:27017/myapi', function (err, database) {
	if (err) {
		return console.log(err);
	}
	db = database;
	app.listen(3000, function () {
		console.log('API app started');
	});//Подключаемся к порту после подключения к базе данных
});