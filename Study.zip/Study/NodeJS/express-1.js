var express = require ('express');//Подключаем к проекту express

var app = express ();//Создаем веб-сервер

var artists = [
{
	id: 1,
	name: 'Metallica'
},
{
	id: 2,
	name: 'Iron Maiden'
},
{
	id: 3,
	name: 'Deep Purple'
}
];

app.get ('/', function (req, res) {
	res.send ('Hello API');//Вывод текста
	var ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.socket.remoteAddress || req.connection.socket.remoteAddress;//Получение ip пользователя
	console.log(ip);
});//При данной локации будет срабатывать данный код

app.get ('/artists', function (req, res) {
	res.send (artists);
});

app.get ('/artists/:id', function (req, res) {
	//console.log(req.params);
	//res.send(req.params);
	var artist = artists.find (function (artist) {
		return artist.id == Number(req.params.id);//По умолчанию params всегда передает строку
	});//Ищем совпадение по id
	res.send (artist);
});

app.listen (3000, function () {
	console.log ('API app started');
});//Указываем на каком localhost борту будет запускаться приложение

//app.use(express.static(path.join(__dirname, 'твоя папка где все статические файлы')));