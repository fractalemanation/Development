const greet = require('./greet-6')('Привет');

console.log(greet('Олег'));
console.log(greet('Дима'));

/*файл DB - практическое применение
const mongodb = require('./mongodb');

module.exports = connectionString => {
	const connection = mongodb.connect(connectionString);
	return connection;
}
*/