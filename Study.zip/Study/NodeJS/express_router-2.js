var express = require ('express');
var bodyParser = require ('body-parser');//Подключаем body-parser

var app = express ();

app.use (bodyParser.json());//Чтобы правильно парсить json из bodyparser
app.use (bodyParser.urlencoded({extended: true}));//Чтобы правильно парсить данные формы


var artists = [
{
	id: 1,
	name: 'Metallica'
},
{
	id: 2,
	name: 'Iron Maiden'
},
{
	id: 3,
	name: 'Deep Purple'
}
];

app.get ('/', function (req, res) {
	res.send ('Hello API');
});

app.get ('/artists', function (req, res) {
	res.send (artists);
});

app.get ('/artists/:id', function (req, res) {
	var artist = artists.find (function (artist) {
		return artist.id == Number(req.params.id);
	});
	res.send (artist.name);
});

app.post('/artists', function (req, res) {
	var artist = {
		id: Date.now (),
		name: req.body.name
	};
	artists.push (artist);//Добавляем в json новые данные

	console.log(req.body);
	res.send(artist);//Выводим сообщение при добавлении
});//Оформление пост запроса

app.put ('/artists/:id', function (req, res) {
	var artist = artists.find (function (artist) {
		return artist.id == Number(req.params.id);
	});
	artist.name = req.body.name;
	res.sendStatus (200);
});//Обновление данных

app.delete ('/artists/:id', function (req, res) {
	artists = artists.filter (function (artist) {
		return artist.id != Number (req.params.id);
	});
	res.sendStatus (200);
});

app.listen (3000, function () {
	console.log ('API app started');
});