const greet = require('./greet-6')('Здравствуйте');

console.log(greet('Олег'));
console.log(greet('Андрей'));

/*файл MONGODB - практическое применение
module.exports = {connect: connectionString => ({connectionString})}
*/