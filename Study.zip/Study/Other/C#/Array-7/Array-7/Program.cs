﻿using System;

namespace Array7 {
	class MainClass {
		public static void Main (string[] args) {
			int[] array = new int[6];//С помощью скобок указываем что это массив, и в них указываем длинну массива
			array[0] = 24;
			array[1] = 14;
			array[2] = 74;
			array[3] = 42;
			array[4] = 34;
			array [5] = 10;
			Console.WriteLine (array[5]);
			for (int i = 0; i < array.Length; i++) {
				Console.Write (array[i] + " ");
			}
			Console.WriteLine ();
		}
	}
}
