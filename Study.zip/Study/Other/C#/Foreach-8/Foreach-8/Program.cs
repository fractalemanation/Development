﻿using System;

namespace Foreach8 {
	class MainClass {
		public static void Main (string[] args) {
			float[] nums = {1.23f, 1.50f, 2.80f,5.50f}; 
			foreach (float el in nums) {
				Console.Write (el + " ");
			}//Перебрали массив
			Console.WriteLine();
		}
	}
}
