﻿using System;
using System.Collections.Generic;

namespace Nasled16 {
	class Animal {
		public string Name { get; set;}

		public Animal (string name) {
			Name = name;
		}

		public void Print () {
			Console.WriteLine (Name);
		}
	}

	class Dog : Animal {
		private float speed;

		public Dog (float speed, string name) : base (name) {
			this.speed = speed;
		}
	}

	class Cat : Animal {
		private float speed;

		public Cat (float speed, string name) : base (name) {
			this.speed = speed;
		}
	}

	class MainClass {
		public static void Main (string[] args) {
			List<Animal> animals = new List<Animal> ();
			animals.Add (new Dog (25.25f, "Alex"));
			animals.Add (new Dog (18.25f, "Tom"));//массив указываем на главный класс и не спасобен применять функции наследуемого класса
			animals.Add (new Cat (12.25f, "Mey"));

			foreach (Animal animal in animals) {
				Console.WriteLine (animal.Name);
			}
			Console.WriteLine ();
			foreach (Animal animal in animals) {
				if (animal is Cat)//Проверяем принадлежность
					Console.WriteLine (animal.Name + "\n");
				if (animal is Cat)
					(animal as Cat).Print ();//as отличается от is только тем что он в случае непреобразования выкидывает null а не исключение как is
			}
		}
	}
}