﻿using System;

namespace Enum22 {
	enum Bread {Dog, Cat, Bird, Bear, Tiger};
	class Animal {
		public Bread bread;//Вместо типа указываем наш enum чтобы автоматически подстраивался тип под выбранный объект

		public Animal (Bread bread) {
			this.bread = bread;
		}

		public void Print () {
			Console.WriteLine (bread);
		}
	}

	class MainClass {
		public static void Main (string[] args) {
			Animal dog = new Animal (Bread.Bird);
			dog.Print ();
		}
	}
}
