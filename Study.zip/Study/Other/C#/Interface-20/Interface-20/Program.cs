﻿using System;

namespace Interface20 {
	interface ISomeInterface {//Создали интерфейс, он не требует установления модификаторов доступа
		int  prop { get; set; }
		void Print ();//Если класс ссылается на интерфейс то в классе должно быть все реализовано из интерфейса
	}

	interface IDraw {
		void Draw ();
	}

	class Test : ISomeInterface, IDraw {//Унаследовали два интерфейса
		public int prop { get; set;}
		public void Print () {
			Console.WriteLine ("Some text");
		}

		public void Draw () {
			Console.WriteLine ("Draw method");
		}
	}

	class Test_2 : ISomeInterface {
		public int prop { get; set;}
		public void Print () {
			Console.WriteLine ("This is text_2");
		}
	}

	class MainClass {
		public static void Main (string[] args) {
			Test test = new Test ();
			Test_2 test_2 = new Test_2 ();

			test.prop = 12;
			test.Print ();
			Console.WriteLine (test.prop);
			test.Draw ();
			Console.WriteLine ();
			test_2.prop = 22;
			test_2.Print ();
			Console.WriteLine (test_2.prop);
		}
	}
}
