﻿using System;

namespace First1 {
	class MainClass {
		public static void Main (string[] args){
			Console.WriteLine ("Hello Wrold!\nHello!");
			Console.ReadKey ();//Не выключит программу пока пользователь не нажмет что либо
		}
	}
}