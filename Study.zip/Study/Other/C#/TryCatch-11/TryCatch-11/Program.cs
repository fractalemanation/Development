﻿using System;

namespace TryCatch11 {
	class MainClass {
		public static void Main (string[] args) {
			Console.Write ("Enter number: ");
			try {
				int num = Convert.ToInt32 (Console.ReadLine ());
				Console.WriteLine ("Num is " + num);
			} catch (DivideByZeroException)/*catch срабатывает при ошибке указанной в параметрах, Exception работает для всех исключений*/ {
				Console.WriteLine ("Exception");
			} catch (FormatException) {//Можно задавать несколько catch, FormatException, DivideByZeroException, IndexOutOfRangeException
				Console.WriteLine ("Format Exception");
			} finally {//Срабатывает всегда и после завершения программы
				Console.WriteLine ("This programm is final");
			}
		}
	}
}
