﻿using System;

namespace Function9 {
	class MainClass {
		public static void Main (string[] args) {
			WriteHello ("Hello!");
			Console.Write ("Enter num1: ");
			int num1 = Convert.ToInt32 (Console.ReadLine ());
			Console.Write ("Enter num2: ");
			int num2 = Convert.ToInt32 (Console.ReadLine ());
			Add (num1, num2);
			int result = Adds (num1, num2);//С возвратными функциями мы можем работать присваивав их в переменные
			Console.WriteLine (result);
		}

		public static void WriteHello (string str) {
			Console.WriteLine (str);
		}

		public static void Add (int num1, int num2) {
			Console.WriteLine ("Result is " + num1 * num2);
		}

		public static int Adds (int num1, int num2) {
			return num1 * num2;
		}
	}
}
