﻿using System;

namespace Classes12 {
	class Animal {
		public string name;
		public int age;
		public float hap;//По умолчанию модификатор доступа private
		public static int count = 0;//static работает для класса а не для созданных новых объектов с помощью класса, их можно вызывать только через класс

		public Animal () {//Конструктор, должны иметь имя класса
			name = "Spat";
			age = 7;
			hap = 0.5f;

			count++;
			Print ();
		}

		public Animal (string name, int age, float hap) {//Конструктор, должны иметь имя класса
			this.name = name;
			this.age = age;
			this.hap = hap;

			count++;
			Print ();
		}

		public void Print () {
			Console.WriteLine ("Name: " + name);
			Console.WriteLine ("Age: " + age);
			Console.WriteLine ("Hap: " + hap);
			Console.WriteLine ("Class: " + count);
		}
	}

	class MainClass {
		public static void Main (string[] args) {
			Animal cat = new Animal ();
			Console.WriteLine ();
			Animal dog = new Animal ("Tom", 20, 30f);
		}
	}
}