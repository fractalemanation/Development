﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Script : MonoBehaviour {
	public GameObject obj;
	private Light myLight;
	private int num = 10;

	void Start () {
		myLight = GetComponent <Light> ();

		for (int i = 0; i < num; i++)
			Debug.Log ("Create " + i + " nums!");
	}

	void Update () {
		if (Input.GetKeyUp (KeyCode.Space))/*Нажатие на клавишу*/ {
			myLight.enabled = !myLight.enabled;
		}//По нажатию на enter будет включаться или выключаться свет

		if (Input.GetKeyUp (KeyCode.A)) {
			obj.SetActive (false);
		} else if (Input.GetKeyUp (KeyCode.D)) {
			obj.SetActive (true);
		}

		if (Input.GetKeyUp (KeyCode.S)) {
			Destroy (obj);//Удаление объекта
		}

		if (Input.GetKeyUp (KeyCode.R))
			obj.GetComponent <Renderer> ().material.color = Color.red;
		else if (Input.GetKeyUp (KeyCode.T))
			obj.GetComponent <Renderer> ().material.color = Color.green;
		else if (Input.GetKeyUp (KeyCode.Y))
			obj.GetComponent <Renderer> ().material.color = Color.blue;
	}
}
