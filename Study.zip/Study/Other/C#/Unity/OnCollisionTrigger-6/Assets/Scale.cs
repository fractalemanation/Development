﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scale : MonoBehaviour {
	void OnCollisionEnter (Collision other) {
		print (other.gameObject.name);//При столкновении выведеться имя объекта с которым столкнулись
	}

	void OnCollisionExit (Collision other) {
		print (other.gameObject.name);//После столкновения выведеться имя объекта с которым столкнулись
	}

	void OnCollisionStay (Collision other) {
		print (other.gameObject.name);//При столкновении выведеться имя объекта с которым столкнулись
	}

	void OnTriggerEnter (Collider other) {
		print (other.gameObject.name);//Также имеет Exit и Stay, при тригерах необязательно чтобы имелся rigibody
	}
}