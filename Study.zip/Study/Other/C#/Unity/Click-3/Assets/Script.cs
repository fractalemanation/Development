﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Script : MonoBehaviour {
	void OnMouseDown () {//OnMouseDown как только нажали кнопку, OnMouseUp как нажали и отпустили, OnMouseUpAsButton как нажали и отпустили на объекте
		transform.localScale = new Vector3 (transform.localScale.x / 2f, transform.localScale.y / 2f, transform.localScale.z / 2f);
	}
}