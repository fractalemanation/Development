﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Script : MonoBehaviour {
	[SerializeField]//Переменная будет показана в unity но не будет изменятся через инспектор
	private float i = 23.55f;
	private AudioSource a;//изначально у переменных тип доступа private и её нельзя использовать в unity

	void Awake () {
		print ("Hi Awake!");
	}//Выполняется до функции start

	void Start () {
		print ("Hi");
		Show ();
	}

	void FixedUpdate () {
		Debug.Log ("FixedUpdate time: " + Time.deltaTime);
	}//Движения объекта, каждые 0.2 сек

	void Update () {
		for (int i = 0; i <= 3; i++)
			print (i);
		Debug.Log ("Update time: " + Time.deltaTime);//Debag.Log это аналог print
	}//Движения объекта, каждые 0.15 - 0.4 сек

	void Show () {
		print (i);
	}
}
