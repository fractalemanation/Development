﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Script : MonoBehaviour {
	public GameObject[] objects;//массив из объектов
	private GameObject inst_obj;

	void Start () {
		int rand = Random.Range (0, objects.Length - 1);
		/*Instantiate (objects[rand], objects[rand].transform.position, Quaternion.identity);Создание объекта, 1 параметр это объект который создаем, 2 позиция, 
		3 вращение, Quaternion.identity - по нулям*/

		/*for (int i = 0; i < objects.Length; i++)
			Instantiate (objects[i], objects[i].transform.position, Quaternion.identity); Создание сразу всех объектов*/

		inst_obj = Instantiate (objects[rand], objects[rand].transform.position, Quaternion.identity) as GameObject;//Через as указываем к чему относится код
		inst_obj.transform.localScale = new Vector3 (0.25f, 0.25f, 0.25f);//Можем задавать параметры через переменную
	}
}
