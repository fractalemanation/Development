﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Scale : MonoBehaviour {

	private Text txt;
	private int count;

	void Start () {
		txt = GameObject.Find ("Text").GetComponent <Text> ();
	}

	void OnCollisionStay (Collision other) {
		count++;
		txt.text = count.ToString () + other.gameObject.name;
	}
}