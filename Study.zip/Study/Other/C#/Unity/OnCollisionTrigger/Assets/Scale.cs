﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scale : MonoBehaviour {
	void OnCollisionEnter (Collision other) {
		print (other.gameObject.name);//При столкновении выведеться имя объекта с которым столкнулись
	}
}
