﻿using System;

namespace Classes12 {
	class Animal {
		public string name = "Spat";
		public int age = 7;
		public float hap = 0.5f;//По умолчанию модификатор доступа private
		public void Print () {
			Console.WriteLine ("Name: " + name);
			Console.WriteLine ("Age: " + age);
			Console.WriteLine ("Hap: " + hap);
		}
	}

	class MainClass {
		public static void Main (string[] args) {
			Animal cat = new Animal ();
			Console.WriteLine (cat.name);
			cat.name = "Tom";
			Console.WriteLine (cat.name);
			cat.Print ();
		}
	}
}
