﻿using System;

namespace Nasled16 {
	class Animal {
		public string Name { get; set;}//protected видно в классе и в наследниках класса

		public Animal (string name) {
			Name = name;
		}

		public void Print () {
			Console.WriteLine (Name);
		}
	}

	class Dog : Animal/*Наследовали класс animal через :*/ {
		private float speed;

		public Dog (float speed, string name) : base (name) {//Указываем какие параметры передаем с класса который наследуем
			this.speed = speed;
			Console.WriteLine ("Speed: " + speed);
			Console.WriteLine ("Name: " + name);
		}
	}

	class MainClass {
		public static void Main (string[] args) {
			Dog tom = new Dog (12.23f, "Tom");
			Console.WriteLine (tom.Name);
			Console.WriteLine ();
			Dog j = new Dog (22.23f, "J");
			j.Print();
		}
	}
}