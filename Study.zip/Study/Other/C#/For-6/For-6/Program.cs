﻿using System;

namespace For6 {
	class MainClass {
		public static void Main (string[] args) {
			for (int i = 0; i <= 5; i++) {
				if (i == 4)
					continue;//Если выполняется условие то пропускает его и продолжает выполнением программы дальше
				Console.Write (i);
			}
			Console.WriteLine ();
			for (int i = 0; i <= 5; i++) {
				if (i == 4)
					break;//Если выполняется условие то остонавливает выполнение
				Console.Write (i);
			}
			Console.WriteLine ();
			int v = 0;
			while (v <= 5) {
				Console.Write (v);
				v++;
			}
			Console.WriteLine ();
			int number;
			do {
				Console.Write("Enter number 5: ");
				number = Convert.ToInt32 (Console.ReadLine ());
			} while (number != 5);
		}
	}
}
