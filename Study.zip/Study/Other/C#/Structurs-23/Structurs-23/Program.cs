﻿using System;

namespace Structurs23 {
	struct Book {//Создание структуры
		public string title;
		public string name;
		public string aut;
		public void Print () {
			Console.WriteLine (title + " " + name + " " + aut);
		}
	}//Структуры занимают меньше памяти чем классы

	class MainClass {
		public static void Main (string[] args) {
			Book b;//Создали объект с помощью структуры в виде переменной
			b.title = "Django";
			b.name = "Nick";
			b.aut = "King";
			b.Print ();
		}
	}
}
