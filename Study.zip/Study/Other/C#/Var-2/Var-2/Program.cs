﻿using System;

namespace Var2 {
	class MainClass {
		public static void Main (string[] args) {
			var num = 10;//Если пишем var то требуется сразу присваивать значение
			int nums;//Если инициализировать класс переменной то можно задать значение позже
			nums = 10;
			uint num_1;//uint не может иметь отрицательного значения
			num_1 = 10;
			float f = 1.23f;//В конце требуется добавить f
			bool boolean = false;
			string  str = "George";
			char c = 'G';//Используется в одинарных ковычках
			Console.WriteLine (num + nums + num_1 + f);
			Console.Write (boolean);
			Console.Write (c);
			Console.WriteLine (str);

			int num1, num2;
			Console.Write ("Enter first num: ");
			num1 = Convert.ToInt32 (Console.ReadLine ());//Конверутируем принимаемые значение со строки в цифры
			Console.Write ("Enter second num: ");
			num2 = Convert.ToInt32 (Console.ReadLine ());

			Console.WriteLine ("The result is: " + (num1 + num2).ToString ());
		}
	}
}

