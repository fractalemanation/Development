﻿using System;
using System.Collections.Generic;

namespace Nasled16 {
	class Animal {
		public string Name { get; set;}

		public Animal (string name) {
			Name = name;
		}

		public virtual void Print () {//Виртуальный метод этот тот метод который можно переопределить
			Console.WriteLine (Name);
		}
	}

	class Dog : Animal {
		private float speed;

		public Dog (float speed, string name) : base (name) {
			this.speed = speed;
		}

		public override void Print () {//Переопределяем метод с помощью слова override
			base.Print ();//Берем все строчки кода из метода до поределения
			Console.WriteLine ("Dog Speed: " + speed);
		}
	}

	class Cat : Animal {
		private float speed;

		public Cat (float speed, string name) : base (name) {
			this.speed = speed;
		}

		public override void Print () {//Переопределяем метод с помощью слова override
			base.Print ();//Берем все строчки кода из метода до поределения
			Console.WriteLine ("Cat Speed: " + speed);
		}
	}

	class MainClass {
		public static void Main (string[] args) {
			List<Animal> animals = new List<Animal> ();
			animals.Add (new Dog (25.25f, "Alex"));
			animals.Add (new Dog (18.25f, "Tom"));//массив указываем на главный класс и не спасобен применять функции наследуемого класса
			animals.Add (new Cat (12.25f, "Mey"));

			foreach (Animal animal in animals) {
				animal.Print ();
			}
		}
	}
}