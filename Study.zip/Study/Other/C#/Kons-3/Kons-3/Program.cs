﻿using System;

namespace Kons3 {
	class MainClass {
		public static void Main (string[] args) {
			const float score = 2.35f;//Создаем константу которую нельзя будет изменить
			Console.WriteLine (score);
			Console.WriteLine (10 % 6);
			var num1 = 2;
			num1++;
			Console.WriteLine (num1);
		}
	}
}
