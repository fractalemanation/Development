﻿using System;
using System.Collections.Generic;

namespace Nasled16 {
	abstract class Animal {//Сделали абстрактный класс словом abstract
		public string Name { get; set;}

		public Animal (string name) {
			Name = name;
		}

		public abstract void Print ();//Абстрактный метод не требует реализации, его можно реализовать в классах наследниках
	}

	class Dog : Animal {

		private float speed;

		public Dog (float speed, string name) : base (name) {
			this.speed = speed;
		}

		public override void Print () {
			Console.WriteLine ("Dog Speed: " + speed);
		}
	}

	class Cat : Animal {
		private float speed;

		public Cat (float speed, string name) : base (name) {
			this.speed = speed;
		}

		public override void Print () {
			Console.WriteLine ("Cat Speed: " + speed);
		}
	}

	class MainClass {
		public static void Main (string[] args) {
			List<Animal> animals = new List<Animal> ();
			animals.Add (new Dog (25.25f, "Alex"));
			animals.Add (new Dog (18.25f, "Tom"));//массив указываем на главный класс и не спасобен применять функции наследуемого класса
			animals.Add (new Cat (12.25f, "Mey"));

			foreach (Animal animal in animals) {
				animal.Print ();
			}
		}
	}
}