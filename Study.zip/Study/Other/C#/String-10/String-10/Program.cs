﻿using System;

namespace String10 {
	class MainClass {
		public static void Main (string[] args) {
			string str = "Hello WORLD!";
			Console.WriteLine (str [1]);
			Console.WriteLine (str.Length);
			Console.WriteLine (String.IsNullOrEmpty (str));//Проверяет пустая ли строка
			Console.WriteLine (String.IsNullOrWhiteSpace (str));//Проверяет строку на пустоту, пробелы и табуляцию

			Console.WriteLine (String.Compare ("a", "b"));//Сравнивает какая строка больше, первая - 1, вторая - -1
			Console.WriteLine (str.ToLower ());//Преобразует все элементы строки в нижний регистр
			Console.WriteLine (str.ToUpper ());//Преобразует все элементы строки в нижний регистр
			Console.WriteLine (str.Contains ("llo"));//Проверяет есть ли такое же содержимое которое указано в параметрах функции
			Console.WriteLine (str.StartsWith ("He"));//Проверяет начинается ли строка с указаного слова в параметрах
			//Console.WriteLine (str.EndsWidth ("lD"));//Проверяет заканчивается ли строка с указаного слова в параметрах
			Console.WriteLine (str.Insert (5, "ld"));//Вставляем строку в параметрах указываем индекс после какого вставить строку а во втором строку
			Console.WriteLine (str.Remove (5));//Очистка строкы в параметрах указываем с какого обрезать индекса
			Console.WriteLine (str.Replace ("llo", "ll"));//Заменяет строку указаную в первом параметре на ту строку которая указано во втором параметре
			char[] sym = str.ToCharArray ();//Преобразовали строку в массив символов
			string str2 = "Arsenal, Real, Barselona";
			string[] clubs = str2.Split (',');//Разбили строку с помощью символа и сможем обращаться как к массиву
			Console.WriteLine (clubs[2]);
		}
	}
}