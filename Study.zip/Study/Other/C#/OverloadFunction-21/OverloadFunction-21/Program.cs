﻿using System;

namespace OverloadFunction21 {
	class Some {
		public void MP (int a, int b) {
			Console.WriteLine ("Result is " + a * b);
		}

		public void MP (int a, int b, int c) {
			Console.WriteLine ("Result is " + a * b * c);
		}//Перегрузка методов это когда метод с одним и тем же именем принимает разные параметры(кол-во параметров или тип параметров)

		public void MP (string str) {
			Console.WriteLine ("Result is " + str);
		}
	}

	class MainClass {
		public static void Main (string[] args) {
			Some mp = new Some ();
			mp.MP (5, 3);
			mp.MP (5, 3, 5);
			mp.MP ("Overload");
		}
	}
}
