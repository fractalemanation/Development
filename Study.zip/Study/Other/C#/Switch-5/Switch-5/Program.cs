﻿using System;

namespace Switch5 {
	class MainClass {
		public static void Main (string[] args) {
			Random randNum = new Random ();
			int num = randNum.Next (1, 6);//Рандомные числа

			switch (num) {
			case 1:
				Console.WriteLine ("Num is - " + num);
				break;
			case 2:
				Console.WriteLine ("Num is equal to - " + num);
				break;
			default:
				Console.WriteLine ("Nortingis equal - " + num);
				break;
			}
		}
	}
}
