﻿using System;

namespace GetSet15 {
	class Student {
		private string name;
		private int course;
		private bool stipuha;

		public int Course {
			get {
				return course;
			}//get и set можно использовать раздельно, можно использовать get; set; если что то сделать private то право отберется на чтение или присваивание
			set {
				if (value < 1)
					course = 1;
				else if (value > 5)
					course = 5;
				else
					course = value;
			}//Здесь можем узнать через value какое значение имеет возвращаемое значение
		}

		public Student () {
			name = "Alex";
			course = 2;
			stipuha = true;

			PrintAll ();
		}

		public Student (string name, int course, bool stipuha) {
			this.name = name;
			this.course = course;
			this.stipuha = stipuha;

			PrintAll ();
		}

		public void PrintAll () {
			Console.WriteLine ("Name: " + name);
			Console.WriteLine ("Course: " + course);
			Console.WriteLine ("Stipuha: " + stipuha);
		}
	}

	class MainClass {
		public static void Main (string[] args) {
			Student Alex = new Student ();
			Console.WriteLine ();
			Student Charl = new Student ("Charl", 2, false);
			Console.WriteLine ();
			Student Dima = new Student ();
			Dima.Course = 8;
			Console.WriteLine (Dima.Course);
		}
	}
}
