from django import forms
from .models import *

class SubscriberForm (forms.ModelForm):
	class Meta:
		model = Subscriber#Делаем форму
		exclude = ['']#Поля которые нужно исключить, указываем exclude или fields #fields = ['']#Поля которые нужно включить