from django.shortcuts import render
from .forms import SubscriberForm
from products.models import *

def landing (request):
	form = SubscriberForm(request.POST or None)
	if request.method == 'POST' and form.is_valid():
		#print(form)#Отображаем формуprint(request.POST)#Все параметры которые передаютсяprint(form.cleaned_data)#Параметры без дополнительных полейprint(form.cleaned_data['name'])#Определенный параметр из формы
		form_save = form.save()#Сохранить в бд
	return render(request, 'landing/landing.html', locals())

def main (request):
	products_images = ProductImage.objects.filter(is_active=True, is_main=True, product__is_active=True)
	products_images_phones = products_images.filter(product__category_id=1)
	products_images_laptops = products_images.filter(product__category_id=2)
	return render(request, 'landing/main.html', locals())#locals перекидывает все переменные и функции в шаблон