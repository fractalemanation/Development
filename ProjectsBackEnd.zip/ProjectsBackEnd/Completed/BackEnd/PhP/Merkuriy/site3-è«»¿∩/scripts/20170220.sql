CREATE TABLE `site_variables` (
  `variable_name` varchar(255) NOT NULL,
  `variable_value` varchar(255) NOT NULL,
  PRIMARY KEY (`variable_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `id250819_host`.`site_variables` (`variable_name`, `variable_value`) VALUES ('release_version', '2017-02-15');

ALTER TABLE `id250819_host`.`send` CHANGE COLUMN `version` `version` VARCHAR(20) NOT NULL;
