﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
</head>
<body>
<?php
	include ("parts/header.php");
?>
<div id="block-body">

<div id="on-inform" style="height:500px;">

<div id="block-inform">

<h2 class="h2-titles"><div class="lang_56_4">Голландия</div></h2>
<div class="textons"><p align="justify"><h3>Виза в Голландию (мультивиза 90/180) – от 175 Евро</h3>
<p align="justify"><b>Получение Визы (100%) за 3 дня!</b>
<br />В пакет услуг входит:
<br />- Комплексный пакет документов для получения визы. Подготовлен индивидуально под ваше путешествие.
<br />- Страхование жизни на весь период поездки.
<br />- Детальный план маршрута.
<br />- Сопроводительные документы, такие как: авиабилеты/подтверждение оплаты отеля.
<p align="justify"><b>Список документов для получения визы в Голландию:</b>
<br />1. Загранпаспорт (который должен быть действителен еще 6 месяцев после возвращения из путешествия);
<br />2. 2 фото 3.5х4.5 см (80% лица);
<br />3. Копия гражданского паспорта;
<br />4. Справка с работы;
<br />5. Справка с банка (движение денег за 3 мес.).
</div>

</div>

</div>

</div>

<?php
	include ("parts/footer.php");
?>

<script src="js/slick.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>
