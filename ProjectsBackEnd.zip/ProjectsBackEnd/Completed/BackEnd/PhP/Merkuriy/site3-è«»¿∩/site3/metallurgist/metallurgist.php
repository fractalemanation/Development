﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
<link rel="stylesheet" type="text/css" href="../css/style.css" />
</head>

<body>

<div id="block-body">

<div class="box2">
	<div class="thumbbox"><img src="../images/thumbnails/71.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="../images/thumbnails/68.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="../images/thumbnails/72.jpg" class="thumbnail">
	</div>
</div>

<div id="on-inform" style="height:2000px;">

<div id="block-inform">

<h2 class="h2-titles"><div class="lang_">Металлург</div></h2>
<div class="textons"><p align="justify"><h3>Металлург (г. Люблин, Польша)</h3>
<p align="justify"><b>Ваши задачи и обязанности:</b> 
<br />(Работа ведется на металлургическом заводе, на горячих печах «коксовнях»)
<br />- Работа (5-6 дней в неделю, 10-12 часов в день)
<br />- Плавка и заливка форм алюминием
<br />- Изготовление форм с металла
<br />
<p align="justify"><a href="../feedback.php" style="color: green"><b>Нажмите чтобы узнать контактную информацию</a></b><br /> 
<br /><b>Ваши навыки и опыт:</b>
<br />- Более важен опыт, чем образование (иметь  опыт работы на металлургических заводах <b>обязательно</b>).
<br />- Знание польского языка <b>обязательно</b>, для понимания  выполнения задач.
<br />
<p align="justify"><b>Зарплата:</b>
<br />16 злотых в час (<b>Нетто</b>)
<br />Выплата «ЗП» выполняется с 10 по 15 число каждого месяца после закрытия актов выполненных работ .
<br />
<br /><b>Требования:</b>
<br />- Самодисциплина, мотивация к работе.
<br />- Добросовестное выполнение своих обязанностей.
<br />- Без вредных привычек
<br />- Необходима справка от врача <b>«психолога» и санитарная книжка</b> (о состояния здоровья) можно приезжать со справкой выданной  на  Украине.
<br />
<br /><b>Мы Вам предлагаем:
<br />Проживание:</b>  бесплатное  (за счет работодателя)  «снимаются квартиры для жилья»  фотографии жилья  будут доступны.
<br />Стабильную работу на основе трудового договора + бонусы в зависимости от результатов
<br />Необходимые инструменты для работы
<br />Возможность личного  и профессионального развития
<br />Страховку , больничные 
<br />Легальное трудоустройство 
<br />Новоприбывших встречают на вокзале, связь при пересечении границы  с менеджером  «Merkury Polska», который  будет вас сопровождать до места работы.
<br />
<br /><b>Проживание:</b>

</div>
<div style="height:10px;">
</div>
<div class="box2">
	<div class="thumbbox"><img src="../images/thumbnails/73.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="../images/thumbnails/74.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="../images/thumbnails/75.jpg" class="thumbnail">
	</div>
	
</div>
<div class="box2">
	<div class="thumbbox"><img src="../images/thumbnails/76.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="../images/thumbnails/77.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="../images/thumbnails/78.jpg" class="thumbnail">
	</div>
	
</div>
<div class="box2">
	<div class="thumbbox"><img src="../images/thumbnails/79.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="../images/thumbnails/80.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="../images/thumbnails/81.jpg" class="thumbnail">
	</div>
</div>
<div class="box2">
	<div class="thumbbox"><img src="../images/thumbnails/82.jpg" class="thumbnail">
	</div>
</div>
</div>
</div>
</body>
</html>
