﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
<link rel="stylesheet" type="text/css" href="../css/style.css" />
</head>

<body>

<div id="block-body">

<div class="box2">
	<div class="thumbbox"><img src="../images/thumbnails/70.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="../images/thumbnails/93.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="../images/thumbnails/94.jpg" class="thumbnail">
	</div>
</div>

<div id="on-inform" style="height:800px;">

<div id="block-inform">

<h2 class="h2-titles"><div class="lang_">Телемаркетолог</div></h2>
<div class="textons"><p align="justify"><h3>Работа в Польше, город Хелм, филиал во Львове</h3>
<p align="justify"><b> (студенты со знанием хорошего польского языка )</b> 
<br />Если вы имеете желание работать, то у Вас наверняка успешно получится работать оператором call-центра/телемаркетологом.
<br />
<p align="justify"><a href="../feedback.php" style="color: green"><b>Нажмите чтобы узнать контактную информацию</a></b><br /> 
<br /><b>Работа (оператор call-центра/телемаркетолог)</b>
<br />Студенты с опытом и без опыта работа
<br />
<p align="justify"><b>Работа в  две смены:</b>
<br />Первая с 8:00 по 14:30 
<br />Вторая  с 14:30 по 21:00
<br />Так же можно работать в одной смене с 6 до 8 часов.
<br />
<br /><b>Обязанности:</b>
<br />Знание  польского языкa (очень хорошо) .
<br />
<br /><b>Требования:</b>  
<br />Более важен польский язык чем опыт работы.
<br />Самодисциплина, мотивация к работе,
<br />Добросовестное выполнение своих обязанностей,
<br />Без вредных привычек,
<br />Четкая дикция,
<br />Грамотная речь,
<br />Коммуникабельность,
<br />Нацеленность на результат.
<br />
<br /><b>Зарплата:</b>
<br />10-11 зл. в час (Нетто)
<br />
</div>
</div>
</div>
</body>
</html>
