﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
<link rel="stylesheet" type="text/css" href="../css/style.css" />
<link rel="stylesheet"
	href="../font-awesome-4.7.0/css/font-awesome.min.css">
</head>

<body>

<div id="block-body">

<div class="topvacancies">
	<span class="toplabel">АКТУАЛЬНЫЕ ВАКАНСИИ</span>
</div>
<div class="box2">
	<div class="thumbbox">
		<a href="metallurgist.php">
			<img src="../images/thumbnails/68.jpg" class="thumbnail">
			<span class="thumblabel">Металлург</span>
		</a>
	</div>
	
<div id="on-inform">


</div>

</body>
</html>
