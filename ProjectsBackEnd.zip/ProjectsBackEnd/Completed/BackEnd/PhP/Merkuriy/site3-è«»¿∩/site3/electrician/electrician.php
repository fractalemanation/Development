﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
<link rel="stylesheet" type="text/css" href="../css/reset.css" />
<link rel="stylesheet" type="text/css" href="../css/style.css" />
<link rel="stylesheet" href="../css/slick.css" />
<link rel="stylesheet" href="../css/slick-theme.css" />
<link rel="stylesheet" href="../css/sweetalert.css" />

<script src="../js/jquery-2.2.4.js"></script>
<script src="../js/jquery-1.8.2.min.js"></script>
<script src="../js/jquery.validate.js"></script>
<script src="../js/jquery.cookie.min.js"></script>
<script src="../js/slick.min.js"></script>
<script src="../js/sweetalert.min.js"></script>
<script src="../js/jquery.form.js"></script>
<script src="../js/TextChange.js"></script>
<script src="../js/jcarousellite_1.0.1.js"></script>
<script src="../js/script.js"></script>
<link rel="shortcut icon" type="image/x-icon" href="../images/logo.png">
<link rel="stylesheet" href="../font-awesome-4.7.0/css/font-awesome.min.css">
</head>

<body>
<div id="header">
		<div class="topmenu-wrapper">
			<div class="box logo">
			    <img src="../images/header_logo.png" style="width: auto; height: 100%"></img>
			</div>
			<div class="box center">
				<nav>
				<ul class="topmenu">
					<li><a href="../index.php" id="lang_1">Главная</a></li>
					<li><a href="#" class="submenu-link" id="lang_86">Трудоустройство</a>
						<ul class="submenu">
							<li><a href="../rab.php"><div class="lang_87">Вакансии</div></a></li>
							<li><a href="../sp.php"><div class="lang_76">Стоимость программы</div></a></li>
							<li><a href="../nd.php"><div class="lang_77">Необходимые документы</div></a></li>
							<li><a href="../pro.php"><div class="lang_78">Процедура оформления</div></a></li>
						</ul>
					</li>
					<li><a href="../vis.php" id="lang_53">Визы</a></li>
					<li><a href="http://www.kyivre.com/" target="_blank" id="lang_88">Страхование</a></li>
					<li><a href="#" class="submenu-link" id="lang_89">О нас</a>
						<ul class="submenu">
							<li><a href="../our.php"><div class="lang_89">О нас</div></a></li>
							<li><a href="../rev.php"><div class="lang_90">Отзывы</div></a></li>
							<li><a href="../feedback.php"><div class="lang_11">Контакты</div></a></li>
						</ul>
					</li>
					<li><a href="#" class="submenu-link" id="lang_91">Разное</a>
						<ul class="submenu">
							<li><a href="../po.php"><div class="lang_32">Программное обеспечение</div></a></li>
							<li><a href="../avto.php"><div class="lang_33">Заказ автомобилей</div></a></li>
							<li><a href="../blf.php"><div class="lang_58">Благотворительные фонды</div></a></li>
						</ul>
					</li>
				</ul>
				</nav>
			</div>
			<div class="box left">
				<a class="button" id="vv" rel="alternate"><span id="lang_99">Заявка</span></a>
				<select name="lang" id="lang">
				<option value="1" selected="selected">Русский</option>
				<option value="2">Polski</option>
				<option value="3">English</option>
				<option value="4">Español</option>
				<option value="5">Français</option>
			</select>
			</div>
		</div>
	</div>
	<div id="ifm1">
		<a class="hide"><img
			src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png"
			id="del1" /></a>
		<iframe id="iframem"
			src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2541.0743921724415!2d30.52062895097995!3d50.43971497937319!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40d4ceffb42714d5%3A0x594f58265e7d4158!2z0LLRg9C70LjRhtGPINCR0LDRgdC10LnQvdCwLCAxMiwg0JrQuNGX0LI!5e0!3m2!1sru!2sua!4v1487706875114"
			width="800" height="500" frameborder="0" style="border: 0"
			allowfullscreen></iframe>
	</div>

	<div id="ifm2">
		<a class="hide"><img
			src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png"
			id="del2" /></a>
		<iframe
			src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d8667.993672601573!2d23.4609060352321!3d51.13341006114667!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47239a4e912c3263%3A0xe24105ac8c241087!2zTHViZWxza2EgNTIsIENoZcWCbSwg0J_QvtC70YzRiNCw!5e0!3m2!1sru!2sua!4v1485418464097"
			width="800" height="500" frameborder="0" style="border: 0"
			allowfullscreen></iframe>
	</div>

	<div id="block-dr">
		<a class="hide-dr"><img
			src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png"
			id="deletedr" /></a>
		<h2 class="h2-title"><div class="lang_95">Форма Резюме</div></h2>
		<form id="for" method="post" action="include/send.php">
			<p id="reg_message"></p>
			<ul id="feedback">
				
			<li><input type="text" name="fio" placeholder="Ваше Имя" required />
			<input class="lang_104" type="text" name="city" placeholder="Город, Область" required /></li>
				
			<li><select  required name="age" id="age">
						<option value=""><div class="lang_97">Выбрать Возраст</div></option>
						<option value="16">До 16</option>
						<option value="16-18">16-18</option>
						<option value="18-20">18-20</option>
						<option value="20-25">20-25</option>
						<option value="25-40">25-40</option>
						<option value="40-50">40-50</option>
						<option value="50-55">50-55</option>
						<option value="55">55 и более</option>
			</select>
			<select  required name="vacancy" id="vacancy">
						<option value=""><div class="lang_97">Выбрать Вакансию</div></option>
<?php
define ( 'kop', true );
include ('include/db_connect.php');

$result = mysql_query ( "SELECT * FROM vacancies ORDER BY title ASC", $link );
if (mysql_num_rows ( $result ) > 0) {
	$row = mysql_fetch_array ( $result );
	do {
		echo '<option value="'.$row [id].'">'.$row [title].'</option>';
	} while ( $row = mysql_fetch_array ( $result ) );
}
?>
			</select>				
			</li>
				<div class="lang_102" id="radio">Наличие загран паспорта</div>
				<div>
					<input type="radio" name="passport" id="R1" value="да" required><label for="R1"><div class="lang_100" id="answer1">Да</label></div></div> 
				<div>
					<input type="radio" name="passport" id="R2" value="нет"><label for="R2"><div class="lang_101" id="answer2">Нет</label></div></div><br><br>
				<div class="lang_103" id="radio">Есть ли открытая виза</div>
				<div>
					<input type="radio" name="visa" id="R3" value="да" required><label for="R3"><div class="lang_100" id="answer1">Да</label></div></div> 
				<div>
					<input type="radio" name="visa" id="R4" value="нет"><label for="R4"><div class="lang_101" id="answer2">Нет</label></div></div> <br><br>  
			<li><select  required name="language" id="language">
						<option value="" class="lang_105">Знание польского языка</option>
						<option value="1" class="lang_106">не понимаю по польски</option>
						<option value="2" class="lang_107">понимаю много польских слов</option>
						<option value="3" class="lang_108">немного говорю по польски</option>
						<option value="4" class="lang_109">говорю по польски хорошо</option>
			</select>
				<input type="text" name="phon"	placeholder="Ваш Телефон" required />
			</li>
			<li>
				<input type="text" name="emai" id="mail" placeholder="E-mail" required />
			</li>
				<textarea name="text" placeholder="Пожелания" cols="34" rows="10"></textarea></li>
			<li>
					<div id="block-captch">
						<img src="include/reg_captcha.php" /> <input type="text"
							name="reg_captch" id="reg_captcha" class="cvalue" />
						<p id="reloadcaptch" class="lang_75">Обновить</p>
					</div>
				</li>
			</ul>
			<input type="submit" name="send_message" id="submit" />
		</form>
	</div>
<div id="block-body">

<div class="box2">
	<div class="thumbbox" style="height: 274px;"><img src="../images/thumbnails/49.jpg" class="thumbnail">
	</div>
	<div class="thumbbox" style="height: 274px;"><img src="../images/thumbnails/50.jpg" class="thumbnail">
	</div> 
	<div class="thumbbox" style="height: 274px;"><img src="../images/thumbnails/51.jpg" class="thumbnail">
	</div>
</div>

<div id="on-inform" style="height:1950px;">

<div id="block-inform">

<h2 class="h2-titles"><div class="lang_">Электрик</div></h2>
<div class="textons"><p align="justify"><h3>Электрик г.Люблин</h3>
<p align="justify"><b>Если вы имеете определённые навыки, квалификации и опыт электрика, то у Вас наверняка успешно получится работать в г. Люблин. Нехватка специалистов среди местного населения Польши требует постоянного привлечения работников  со стран СНГ (Украина, Беларусь). В последнее время особый спрос на электриков.<br />
<p align="justify"><a href="../feedback.php" style="color: green"><b>Нажмите чтобы узнать контактную информацию</a></b><br /> 
<br />Электрик с опытом роботы.</b>
<br />Компании требуются электрики, для работы на новопостроенных объектах.
<br /><b>Виды работ:</b>
<br />Установка электрических систем на новопостроенных объектах.
<br />Разводка и подключение электропроводки.
<br />
<p align="justify"><b>Условия труда и оплата:</b>
<br />- График: 10-12 часов в день, есть возможность работы в субботу
<br />- Оплата: от 12-18 зл./час. нетто в зависимости от опыта
<br />- Проживание: жилье оплачивает работодатель, квартира со всем удобствами на 4 человека
<br />- Работодатель предоставляет рабочую одежду, обувь
<br />- Полностью официальное оформление, медицинское и социальное страхование, зарплатный счет в банке, помогают с оформлением Вида на жительство (карта побыту)
<br />
<br /><b>Требования:</b>
<br />- Минимум 1 летний опыт в работе на должности электрика.
<br />- Самодисциплина, мотивация к работе.
<br />- Добросовестное выполнение своих обязанностей
<br />- Без вредных привычек
<br />
<br /><b>Обязанности:</b>
<br />Важен опыт электрика, знание польского (языкa).
<br />
<br /><b>ОТВЕТСТВЕННОСТЬ:</b>
<br />Електрик должен быть опытный и ответственный сотрудник, отлично знающий своё дело. 
<br />
<br /><b>Требования:</b>
<br />Знание польского для понимания выполнения задачи. Необходима справка  от врача (психолога  и санитарная книжка о состояния здоровья), можно приезжать со справкой, выданной в Украине. 
<br />
<br /><b>Зарплата:</b>
<br />Официальное оформление. 
<br />Выплата авансов по необходимости.
<br />Выплата ЗП с 10го по 15е число каждого месяца.
<br />
<br /><b>Разрешение на работу:</b>
<br />Виза (05 или 06)
<br />
<br /><b>Проживание на територии базы:</b>
<br />Бесплатное, согласно нормальных норм проживания без пьянок и драк (одно нарушение - штраф взымается с работника от 550-600 злотовок).
<br />
<br /><b>Дополнительно:</b>
<br />Новоприбывших встречают на вокзале и связь при пересечение границы с менеджером Польши, который сопровождает работника и встречает. 
<br />Легальное трудоустройство. 
<br />Страховка, больничные. 
<br />Работа круглый год, теплую одежду иметь форму с  логотипом компании бесплатно выдается
<br />
<br /><b>Иметь при себе на роботу:</b>
<br />Дорогие друзья, здесь мы опишем, что, по нашему мнению, нужно обязательно с собой брать на работу в Польшу. 
Хочу рассказать Вам, что обязательно положить в чемодан, а что нежелательно! 
<br />- 1-2 комплекта постельного белья! Какое не жаль, на первое время если едете впервые! 
<br />- Полотенца(Большое и поменьше, и кухонное!).
<br />- Комнатные тапочки! 
<br />- Зубная паста, щетка, мыло туалетное(2 шт) и стиральное(2 шт) - оно быстро будет использовано, шампунь(не большая бутылка!), мужчинам - пена для бритья, станок, На первое время!!! Гели для душа ! На первое время выше перечисленного вполне достаточно будет!!! Если читаете на этикетках производителей, то в основном все ПОЛЬША! Там нет дефицита на шампунь, бальзам и крем, там ещё дешевле будет чем здесь!!!
<br />- Чашка, тарелка, ложка, вилка, нож! Желательно маленькую и легкую кастрюльку взять!
<br />- Пара-две сменной обуви!
<br />- Одежда(рабочая/домашняя и парадная). Много не берите! 
<br />
<br /><b>АПТЕЧКА:</b>
<br />-берите свои основные лекарства!
<br />-от гриппа(температуры/кашля/горла).
<br />-от разных расстройств желудка!!!
<br />-И КРЕМА/БАЛЬЗАМЫ ОТ МЫШЕЧНЫХ СПАЗМОВ, ОТ БОЛИ В ПОЯСНИЦЕ, В СУСТАВАХ! 
<br /><b>ОБЯЗАТЕЛЬНО, если едите на работу!!!</b>
<br />-На аптечке не экономьте! В других странах лекарственные препараты ОЧЕНЬ ДОРОГИЕ! Да и если что-то случится, то в чужой стране и без знания языка вряд ли дадут нужные Вам препараты, а в инструкциях по применению тоже будет написано не на родном языке нужная информация!
<br /><b>ПРОДУКТЫ:</b>
<br />-В дорогу возьмите бутики и печеньки, а на остановках/заправках или в автобусе/поезде купите себе чай/кофе уже!
<br />-Возьмите с собой чай или кофе на первое время, немного соли и любимых приправ!
<br />-Положите в чемодан любимую крупу(но не большую пачку!). 
<br />-И есть заправка в супы(брикетиками она с различными крупами), будет быстрым завтраком/обедом или ужином! Возьмите пару штук, ведь жидкое нужно кушать! И ВСЕ!!! Больше ничего не тащите с собой!!! На первое время этого вполне хватит!!! Остальное докупите!!!
<br /><b>ЭЛЕКТРОНИКА:</b>      
<br />-По желанию
</div>
</div>
</div>

<div id="footer">
	<div id="footer_center">
		<a href="../index.php"><img src="../images/header_logo.png" id="img_footer" /></a>
		<div id="footer-phone">
			<h4>	
				<div class="lang_27">Телефоны</div>
			</h4>
			<h3>+38068 324 66 25</h3>
			<h3>+38099 324 66 25</h3>
			<h3>+48 574 746 394</h3>
			<p class="lang_28">Пн. - Пт. 9:00-19:00</p>
		</div>
		<div id="mnnn">
			<h3 id="mnn">
				<div class="lang_11">Контакты</div>
			</h3>
			<p id="mn">
				Lubelska 52 <br />Chelm, Poland<br />wejście w łuk<br />piętro 3<br />
				<font class="geol">Геолокация</font>
			</p>
		</div>
		<div id="mnnn">
			<h3 id="mnn">
				<div class="lang_11">Контакты</div>
			</h3>
			<p id="mn">
				ул. Бассейная 12 <br />Киев <br />Украина <br /><br />
				<font class="geolm">Геолокация</font>
			</p>
		</div>
		<div id="nav_footer">
			<h3 id="nav_footer_title">
				<div class="lang_0">Навигация</div>
			</h3>
			<ul id="nav_footer_ul">
				<a href="../vis.php" class="footer_a"><li class="footer_li"><div
							class="lang_53">Визы</div></li></a>
				<a href="../rab.php" class="footer_a"><li class="footer_li"><div
							class="lang_70">Работа в Польше</div></li></a>
				<a href="http://www.kyivre.com/" target="_blank" class="footer_a"><li
					class="footer_li"><div class="lang_88">Страхование</div></li></a>
				<a href="../avto.php" class="footer_a"><li class="footer_li"><div
							class="lang_3">Заказ Автомобилей</div></li></a>
				<a href="../po.php" class="footer_a"><li class="footer_li"><div
							class="lang_2">Програмное Обеспечение</div></li></a>
				<a href="../feedback.php" class="footer_a"><li class="footer_li"><div
							class="lang_11">Контакты</div></li></a>
			</ul>
		</div>
		<div id="ss">
			<h3 id="title_ss">
				<div class="lang_30">Социальные сети</div>
			</h3>
			<div id="sss">
				<a href="https://vk.com/merkurypoland" target="_blank"><img
					src="images/vk.png" class="img_ss" /></a> <a
					href="https://www.facebook.com/%D0%9B%D0%B5%D0%B3%D0%B0%D0%BB%D1%8C%D0%BD%D0%B0%D1%8F-%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0-%D0%B2-%D0%9F%D0%BE%D0%BB%D1%8C%D1%88%D0%B5-%D0%B2%D0%B8%D0%B7%D1%8B%D1%81%D1%82%D1%80%D0%B0%D1%85%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5-598380013705992/"
					target="_blank"><img src="images/facebook.png" class="img_ss" /></a>
				<a href="https://twitter.com/Merkurij2016" target="_blank"><img
					src="images/twitter.png" class="img_ss" /></a>
			</div>
			<div id="ros">
				<h3 id="title_ros">
					<div class="lang_31">Рассказать о сайте</div>
				</h3>
				<script src="//yastatic.net/es5-shims/0.0.2/es5-shims.min.js"></script>
				<script src="//yastatic.net/share2/share.js"></script>
				<div class="ya-share2" data-services="vkontakte,facebook,odnoklassniki,moimir,gplus,twitter,skype"></div>
			</div>
		</div>
	</div>
</div>
<div id="mc">Merkury Polska © 2015-2017</div>
</body>
</html>
