﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
</head>
<body>
<?php
	include ("parts/header.php");
?>
<div id="block-body">

<div id="on-inform" style="height:430px;">

<div id="block-inform">

<h2 class="h2-titles"><div class="lang_53">Визы</div></h2>

<div class="block-v"><div class="h2-titles-minis1"><div class="lang_51">Польские Визы</div></div><img src="images/Flag_of_Poland.png" class="imag" />
<div class="text-1"><img src="images/Flag_of_Poland.png" class="imag2"><a href="vis_pol_nat.php" class="lang_56">Польская национальная 180/365</div></a>
<div class="text-1"><img src="images/Flag_of_Poland.png" class="imag2"><a href="vis_gov.php" class="lang_56_1">Польская от Воеводы</div></a>
<div class="text-1"><img src="images/Flag_of_Europe.png" class="imag2"><a href="vis_pol_sheng.php" class="lang_56_2">Польская шенген</div></a>
</div>

<div class="block-v"><div class="h2-titles-minis1"><div class="lang_53">Визы</div></div><img src="images/Visa.jpg" class="imag" />
<div class="text-1"><img src="images/lt.png" class="imag2"><a href="vis_lit.php" class="lang_56_3">Литва</div></a>
<div class="text-1"><img src="images/Flag_Netherlands.png" class="imag2"><a href="vis_hol.php" class="lang_56_4">Голландия</div></a>
<div class="text-1"><img src="images/Flag_Spain.png" class="imag2"><a href="vis_spain.php" class="lang_56_5">Испания</div></a>
</div>

<div class="block-v"><div class="h2-titles-minis1"><div class="lang_52">Иммиграция</div></div><img src="images/Pass.jpg" class="imag" /><div class="text-1"><div class="lang_55">Карта Побыта (Польша)<br />Получения гражданства ЕС<br />Бизнес в ЕС<br />Недвижимость в ЕС</div></div></div>
</div>

</div>

</div>

<?php
	include ("parts/footer.php");
?>

<script src="js/slick.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>