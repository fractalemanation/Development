﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
</head>
<body>
<?php
include ("parts/header.php");
?>

<div id="block-body">

<div id="on-inform" style="height:550px;">

<div id="block-inform">

<div id="block-message">
<h2 class="h2-title"><div class="lang_65">Форма обратной связи</div></h2>

<form id="form" method="post" action="include/mail.php">
<ul id="feedback">
<li><label><div class="lang_66">Ваше Имя</div></label><input class="input" type="text" name="name" placeholder="Name" required /></li>
<li><label><div class="lang_67">Ваш E-mail</div></label><input class="input" type="text" name="email" id="mail2" placeholder="E-mail" required /></li>
<li><label><div class="lang_68">Ваш Телефон</div></label><input class="input" type="text" name="phone" placeholder="Phone" required /></li>
<li><label><div class="lang_69">Текст сообщения</div></label><textarea id="textarea" placeholder="Message text" name="text" cols="34" rows="10"></textarea></li>
<li>
<div id="block-captcha">
<img src="include/reg_captcha.php" />
<input type="text" name="reg_captcha" id="reg_captcha" class="cvalue" />
<p id="reloadcaptcha" class="lang_75">Обновить</p>
</div>
</li>
</ul>
<input type="submit" name="send_message" id="submit2" value="Отправить" />
</form>

</div>

<div id="form_nomer">
<div class="lang_11">Контакты</div>
<div>+38068 324 66 25</div>
<div>+38099 324 66 25</div>
<div>+38063 749 75 25</div>
<p></p>
<div>+48 825 643 716</div>
<div>+48 666 911 168</div>
<div>+48 574 746 394</div>
</div>

</div>

</div>

</div>

<?php
	include ("parts/footer.php");
?>

<script src="js/slick.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>