﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
</head>
<body>
<?php
include ("parts/header.php");
?>
<div id="block-body">

<div id="block-dr2">
<a class="hide-dr"><img src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png" id="deletedr" /></a>
<h2 class="h2-title"> <div class="lang_92">Форма Отзыва</h2>
<form id="for2" method="post" action="include/send_rev.php">
<p id="reg_message"></p>
<ul id="feedback">
<li><input type="text" name="fname" placeholder="Ваше Имя" required /></li>
<li><input type="text" name="ema" id="mail2" placeholder="E-mail" required /></li>
<li><textarea name="text" placeholder="Текст сообщения" cols="34" rows="10"></textarea></li>
<li>
<div id="block-captc">
<img src="include/reg_captcha.php" />
<input type="text" name="reg_captc" id="reg_captcha" class="cvalue" />
<p id="reloadcaptc" class="lang_75">Обновить</p>
</div>
</li>
</ul>
<input type="submit" name="send_message" value="Отправить" id="submit2" />
</form>
</div>
<div id="on-inform" style="height:350px;">

<div id="block-inform2">

<h2 class="h2-titles"><div><div class="#"></div></div><div class="dr2" id="dr2"><div class="lang_94">ДОБАВИТЬ ОТЗЫВ</div></div></h2>
<?php
include ("parts/feedbacks.php");
?>
</div>

</div>

</div>

<?php
	include ("parts/footer.php");
?>

<script src="js/slick.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>
