﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
</head>
<body>
<?php
include ("parts/header.php");
?>
<div id="block-body">

<div id="on-inform" style="height:6900px;">

<div id="block-inform">

<h2 class="h2-titles"><div class="lang_32">Программное обеспечениe</div></h2>
<div id="header-list-cart">
<div id="head1">Company</div>
<div id="head1">Position</div>
<div id="head1">StartDate-endDate</div>
<div id="head5">Responsibilities</div>
</div>
<div class="block-list-cart">
<div class="header-list-carts">
<div class="head3">Synergetica at Synergetica</div>
<div class="head3">Senior Java Developer</div>
<div class="head3">August 2014 - June 2015</div>
<div class="head4">Senior java dev, PM, communication with customers, code review, interviews with candidates</div>
</div>
<div class="header-list-carts">
<div class="head3">ARG Systems</div>
<div class="head3">Software Architect</div>
<div class="head3">April 2014 - July 2014</div>
<div class="head4"></div>
</div>
<div class="header-list-carts">
<div class="head3">Own biz</div>
<div class="head3">Java Developer</div>
<div class="head3">March 2014 - April 2014</div>
<div class="head4">PM, architectwith ow team that created/developed/tested portal</div>
</div>
<div class="header-list-carts">
<div class="head3">Own product for public entertainment</div>
<div class="head3">PM, TechLead, Developer</div>
<div class="head3">October 2013 - March 2014</div>
<div class="head4">Documentation, design, development of backend solutions</div>
</div>
<div class="header-list-carts">
<div class="head3">Ciklum</div>
<div class="head3">Senior Java Developer, Architect</div>
<div class="head3">October 2013 - January 2014</div>
<div class="head4">Documentation, design, development of backend solutions</div>
</div>
<div class="header-list-carts">
<div class="head3">NOVASOL AS</div>
<div class="head3">Senior Java Developer</div>
<div class="head3">February 2013 - January 2014</div>
<div class="head4">RESTful web services development, last line support, kanban</div>
</div>
<div class="header-list-carts">
<div class="head3">own biz</div>
<div class="head3">PM, TechLead, Developer</div>
<div class="head3">February 2013 - January 2014</div>
<div class="head4">Managing distributed team of frontend and backend developers using kanbanflow.com, bitbucket.org</div>
</div>
<div class="header-list-carts">
<div class="head3">Ciklum</div>
<div class="head3">Consultant, Senior Java Developer, Senior Web Developer</div>
<div class="head3">June 2013 - October 2013</div>
<div class="head4">RESTful web service development, Web application development, Business analysis,SCRUM (1 week iterations). Remote work</div>
</div>
<div class="header-list-carts">
<div class="head3">IntroPro</div>
<div class="head3">Senior Java Developer,Tech Lead</div>
<div class="head3">October 2012 - September 2013</div>
<div class="head4">Started as senoir java developer, then took technical leadership position</div>
</div>
<div class="header-list-carts">
<div class="head3">DAXX</div>
<div class="head3">Senior Java Developer</div>
<div class="head3">February 2012 - September 2012</div>
<div class="head4">My part was to develop a web portal based on a homegrown CRM. Most of my work was mixture of frontend and backend development.Also I used web services for integrations with external systems. As a part of quality assurance I developed automated tests for each piece of functionality</div>
</div>
<div class="header-list-carts">
<div class="head3">Ciklum</div>
<div class="head3">Java Developer</div>
<div class="head3">September 2011 - October 2011</div>
<div class="head4">Coding of backend. Testing was done only for Frontend layer by QA in Germany. Developed code in Java. Collaborated with developer in Germany</div>
</div>
<div class="header-list-carts">
<div class="head3">Ciklum</div>
<div class="head3">Java Developer</div>
<div class="head3">November 2011 - December 2011</div>
<div class="head4">Coding. Testing was done by QA in Germany. Remote communications were done with PM in Kiev's office.I took part in 2 stages of the project. The first one – implementation of the spec and some bug fixing, thesecond - last bugs and some additional features. Developed code in NetbiscuitsML. Collaborated with developer in Germany</div>
</div>
<div class="header-list-carts">
<div class="head3">Anotheria Inc</div>
<div class="head3">Senior Java Developer</div>
<div class="head3">July 2010 - October 2011</div>
<div class="head4">But mostly I developed remotely. Role Backend and Frontend Engineer working remotely in communication with a team in the office with everyday's scrum meetings and regular onsite planning, QA on customers behalf responsibilities and Key Accomplishments Requirements implementation, coding, unit testing, Covering all the required functionality with ExtAPI. Collaborated remotely with development team</div>
</div>
<div class="header-list-carts">
<div class="head3">Anotheria Inc</div>
<div class="head3">Senior Backend Engineer</div>
<div class="head3">April 2010 - July 2010</div>
<div class="head4">Role Backend Engineer in pair with another Backend Engineer with everyday's scrum meetings, responsibilities and Key Accomplishments Page5Requirement analysis and finalization. Prototyping, Covering all the required functionality with ExtAPI. Collaborated with a remote project manager and one remote developer</div>
</div>
<div class="header-list-carts">
<div class="head3">Anotheria.net</div>
<div class="head3">Senior Backend Engineer</div>
<div class="head3">February 2010 - April 2010</div>
<div class="head4">Role System Analyst, Developer, responsibilities and Key Accomplishments, Requirement analysis and finalization, Developed code in Java, Collaborated with product owner. Later the project was applied for a customer</div>
</div>
</div>

<div id="header-list-carts">
<div id="head1">Company</div>
<div id="head1">Techs</div>
<div id="head1">Product</div>
<div id="head5">Description</div>
</div>
<div class="block-list-cart">
<div class="header-list-carts">
<div class="head3">Synergetica at Synergetica</div>
<div class="head3">
<ul>
<li>JDK 1.7</li>
<li>JBOSS AS7</li>
<li>GlassFish 4.1</li>
<li>MySQL</li>
<li>JPA</li>
<li>CDI</li>
<li>REST</li>
<li>EJB3</li>
<li>Eclipse Luna</li>
<li>Selenium web driver</li>
<li>Arquillian</li>
<li>jQuery</li>
<li>AngularJS</li>
<li>HTML/CSS</li>
<li>Jenkins</li>
<li>Linux</li>
<li>bash</li>
<li>exterlal webservices</li>
<li>JIRA cloud (Agile)</li>
<li>Scrum (weekly sprints)</li>
<li>skype</li>
<li>java 1.8</li>
<li>vertx</li>
<li>web sockets</li>
<li>ReactiveX</li>
<li>couchbase community server</li>
<li>CentOS</li>
<li>JIRA</li>
<li>scrum</li>
</ul>
</div>
<div class="head3">Web portal for summerhouses rental</div>
<div class="head4">Started a project as a senior dev- further created prototype, which passed customer approval,then planned tasks in JIRA according to the functional design doc, created first Gannt for the project, developers were added to the project, the team grew up to 15 people (developers, QA, PM), I was able to delegate tasks to them all and end up with a tech leading role. The project is passed to customer for deployment to production</div>
</div>
<div class="header-list-carts">
<div class="head3">ARG Systems</div>
<div class="head3">
<ul>
<li>Postgres (w/ JSON)</li>
<li>JPA</li>
<li>JSF/Primefaces</li>
<li>jQuery</li>
<li>facelets</li>
<li>Wildfly 8 (JBoss)</li>
<li>JDK 1.8</li>
<li>websocket</li>
<li>CDI</li>
<li>EJB3</li>
<li>Arquillian unit/integration testing</li>
<li>Jenkins</li>
<li>Linux Shell Scripting</li>
<li>Ubuntu</li>
</ul>
</div>
<div class="head3">Taxi Service in Moskow</div>
<div class="head4">Project was already started about 2 months, technologies were integrated partially, my role at start was to develop UI in JSF and also backend, later I was given more tasks to process communication on backend using web sockets with Android clients</div>
</div>
<div class="header-list-carts">
<div class="head3">Own biz</div>
<div class="head3">
<ul>
<li>OpenOffice Base database)</li>
<li>Postgres (w/JSON)</li>
<li>JPA</li>
<li>JSF/Primefaces</li>
<li>jQuery</li>
<li>facelets</li>
<li>Wildfly 8 (JBoss)</li>
<li>jboss security</li>
<li>JDK 1.8</li>
<li>websocket</li>
<li>CDI</li>
<li>EJB3</li>
<li>Arquillian unit/integration testing</li>
</ul>
</div>
<div class="head3">Web portal for managing our family business we had then</div>
<div class="head4">The business was related to construction of buildings in Kiev. We did manage teams of builders for that and used that portal</div>
</div>
<div class="header-list-carts">
<div class="head3">Own product for public entertainment</div>
<div class="head3">
<ul>
<li>Java</li>
<li>JMS</li>
<li>Mongo</li>
<li>MySQL</li>
<li>Java NIO</li>
<li>JSP</li>
<li>Spring MVC</li>
<li>Maven</li>
</ul>
</div>
<div class="head3">Server, patched client and portal for a well known public online game with own plugin</div>
<div class="head4">Secure user registration web site, data encryption, product enhancements, scam protection system</div>
</div>
<div class="header-list-carts">
<div class="head3">Ciklum</div>
<div class="head3">
<ul>
<li>Java</li>
<li>WebServices</li>
<li>JAXB</li>
<li>Miltithreading</li>
<li>Eclipse</li>
<li>JDBC</li>
<li>clusters</li>
<li>home grown deployment system</li>
<li>SVN</li>
<li>SCRUM</li>
<li>kanban</li>
<li>Confluence</li>
<li>UML</li>
</ul>
</div>
<div class="head3">Air|rail|car|hotel bookings</div>
<div class="head4">For existing system developed new functionality that integrates with3rd party data providers</div>
</div>
<div class="header-list-carts">
<div class="head3">NOVASOL AS</div>
<div class="head3">
<ul>
<li>Java</li>
<li>Tomcat</li>
<li>Postgres</li>
<li>Master/slave replicas</li>
<li>Spring</li>
<li>Spring JDBC</li>
<li>Mule ESB</li>
<li>Jenkins</li>
<li>Open Build System</li>
<li>Satelite</li>
<li>shell scripting</li>
<li>Linux</li>
<li>home grown CRMs</li>
</ul>
</div>
<div class="head3">Web portal for summerhouses rental</div>
<div class="head4"></div>
</div>
<div class="header-list-carts">
<div class="head3">Own biz</div>
<div class="head3">
<ul>
<li>HTML</li>
<li>css</li>
<li>jQuery</li>
<li>JSP</li>
<li>Spring MVC</li>
<li>Maven</li>
<li>JPA</li>
<li>JAXB</li>
<li>Tomcat</li>
<li>ObjectDB</li>
</ul>
</div>
<div class="head3">Created our own CMS and admin tool for delivering web sites</div>
<div class="head4">Creating web sites for local customers</div>
</div>
<div class="header-list-carts">
<div class="head3">Ciklum</div>
<div class="head3">
<ul>
<li>Java</li>
<li>REST</li>
<li>Tomcat/WebSphere</li>
<li>Spring MVC</li>
<li>Hibernate/JPA</li>
<li>MySQL/Oracle</li>
<li>Struts/JSP/Servlets</li>
<li>jQuery/EmberJS/Ajax</li>
<li>HTML/CSS/JS</li>
</ul>
</div>
<div class="head3">Software for sales</div>
<div class="head4">Continued development of backend and participated integration of UI solutions written in JSF to pure frontend with EmberJS</div>
</div>
<div class="header-list-carts">
<div class="head3">IntroPro</div>
<div class="head3">
<ul>
<li>Weblogic</li>
<li>clustered environment</li>
<li>JMS</li>
<li>MDB</li>
<li>EJB</li>
<li>WS</li>
<li>JAXRS</li>
<li>JAXB</li>
<li>REST</li>
<li>Java</li>
<li>Spring</li>
<li>Hibernate/JPA</li>
<li>Oracle</li>
<li>Ubuntu</li>
<li>Shell scripting</li>
<li>Ant</li>
<li>Jenkins</li>
<li>Jboss</li>
</ul>
</div>
<div class="head3">Backend software for satelites</div>
<div class="head4">Developed core parts of clustered web application for a big company from USA</div>
</div>
<div class="header-list-carts">
<div class="head3">DAXX</div>
<div class="head3">
<ul>
<li>HTML</li>
<li>CSS</li>
<li>prototype</li>
<li>jQuery</li>
<li>JSP</li>
<li>JSTL</li>
<li>Tomcat</li>
<li>Spring MVC</li>
<li>Hibernate/JPA</li>
<li>MySQL</li>
<li>Maven</li>
<li>Jenkins</li>
<li>SVN</li>
<li>Eclipse</li>
<li>JRebel</li>
</ul>
</div>
<div class="head3">In total a few web portals based on a home-grown CMS</div>
<div class="head4">Most of the time worked remotely with every day constant skype calls to on-site developers in Netherlands. The functionality I implemented: web pages and controllers - 70%, services, DAO, Hebernate entities,external web service integrations - 30%</div>
</div>
<div class="header-list-carts">
<div class="head3">Ciklum</div>
<div class="head3">
<ul>
<li>Java</li>
<li>Struts</li>
<li>XML/XSLT</li>
<li>code generation</li>
<li>Java Reflection</li>
</ul>
</div>
<div class="head3">Sport</div>
<div class="head4">This short-term business trip to Kaiserslautern, Germany followed by remote development activities with one developer in Germany. My part was to provide the fastest possible XML feed parser based on open source streaming XML parsers. After that I created Struts actions that were later customized by the dev in Germany who also developed NetBiscuitsML frontend. In developing frontends my part was minor. Most of my work was on backend. The duration of the project – 1 month</div>
</div>
<div class="header-list-carts">
<div class="head3">Ciklum</div>
<div class="head3">
<ul>
<li>Java</li>
<li>NetBiscuitsML</li>
<li>HTML</li>
<li>CSS</li>
<li>JS</li>
<li>Struts/Tiles</li>
</ul>
</div>
<div class="head3">World Of Coca Cola</div>
<div class="head4">This project was about developing mobile portal for “World Of Coca Cola” entertainment center located in Atlanta, USA. Most of work was pure handcoding of NetBiscuitsML pages with only minor functionality based on some feed parsing</div>
</div>
<div class="header-list-carts">
<div class="head3">Anotheria Inc</div>
<div class="head3">
<ul>
<li>Java</li>
<li>MAF (aka Struts)</li>
<li>SOA</li>
<li>DistributeMe</li>
<li>ConfigureMe</li>
<li>iBatis</li>
<li>PostgresQL</li>
<li>HTML</li>
<li>JS</li>
<li>all development and testing in Linux and MacOS</li>
</ul>
</div>
<div class="head3">Parship ScamSweeper Tool</div>
<div class="head4">This project is to detect/manage possible predictable scams on parship.de. The key idea of it was to provide service which can be called by parship web application in case of possible scam detection. The service stores all such events and then The ScamSweeper admin can review them. On the first stages of that project I was the only frontend/backend developer but I worked remotely. I ordered HTML mock pages from a web designer then my made them work as JSPs. Later in Kievs office a team was created for the project since the Parship company decided to overwhelm this product with tons of requirements. I took part in further development of almost all of them. Also I visited Anotheria offices regularly for scrum planning meetings before each new stage</div>
</div>
<div class="header-list-carts">
<div class="head3">Anotheria Inc</div>
<div class="head3">
<ul>
<li>Java</li>
<li>Spring</li>
<li>iBatis</li>
<li>PostgresQL</li>
<li>HTML</li>
<li>JS</li>
<li>RESTful design</li>
<li>ConfigureMe</li>
</ul>
</div>
<div class="head3">Parship ExtAPI</div>
<div class="head4">This project is a part of mobile integrations made for parship.de. The key idea of it was to provide RESTful API for third party development team that created front-end for online dating on parship.de. The facade of the API was several HTTP requests with parameters that allow for XML or JSON output. The internal processing calls parship internal services. By then there was no internal services at all, there was only common functionality between parhip.de web site and ExtAPI which was distributed as simple JAR with tons of spring configuration. After long internal migration process started that I took part later. The idea of that process was to create remote configurable services for both ExtAPI and current web application. Ugly spring solutions were eliminated and replaced with more flexible and scalable configurable services</div>
</div>
<div class="header-list-carts">
<div class="head3">Anotheria.net</div>
<div class="head3">
<ul>
<li>Java</li>
<li>RMI</li>
<li>OOP/OOD</li>
<li>JDBC</li>
<li>XML</li>
<li>DistributeMe</li>
<li>ConfigureMe</li>
</ul>
</div>
<div class="head3">MosKITo Central</div>
<div class="head4">This short-term project is part of open source products line of Anotheria Inc. The idea of MosKITo is to provide customizations for online runtime statistics for Java web applications. The extension points are based on service oriented approach. Once MosKITo is integrated in a java web application the statistics can be simply viewed as a separate web page provided by MosKITo. The idea of “MosKITo Central” is to provide configurable persistent storages for MosKITo statistics. The implementation of the storages can be plugged into MosKITo enabled web app. Implementations were: local XML files, JDBC, remote service as proxy. This was a pure java project with uses of DistributeMe and ConfigureMe open source Anotheria products. This was my first project with Anotheria Inc and I discovered relatively new approaches to development of web apps. They hate Spring and use the approaches developed by their open source community. ConfigureMe is used instead of spring. Maybe it does not give that flexible means but for the most part it allows for built-in configurable changes WITHOUT downtime of software. I was convinced that replacing Spring with ConfigureMe only leads to a better OOD and allows for more flexible runtime configurations</div>
</div>

</div>

</div>

</div>

</div>

<?php
	include ("parts/footer.php");
?>

<script src="js/slick.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>