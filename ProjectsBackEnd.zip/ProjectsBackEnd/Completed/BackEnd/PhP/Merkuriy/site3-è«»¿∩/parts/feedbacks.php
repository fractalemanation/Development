<div id="ot">
<div class="otsivi"><div class="lang_17">Отзывы</div></div>

<div class="maining">
 <div class="sl">
 
  <div class="sl__slide">
  <img src="images/6202.jpg" alt="Картинка слайда 1" class="sl_img" />
  <div class="sl_text">
  <h3 class="sl_zag"><div class="lang_18">АЛЕКСАНДР КОЛОСЮК</div></h3>
  <p class="lang_19">Покупатель виз в нашей компании «Merkury Polska», а также активный помощник в работе Благотворительного Фонда.</p>
  <p class="lang_20">«Очень благодарен компании «Merkury Polska». Оформление проходит быстро и профессионально. Спасибо Вам большое!</p>
  </div>
  </div>
  
  <div class="sl__slide">
  <img src="images/6232.jpg" alt="Картинка слайда 2" class="sl_img" />
  <div class="sl_text">
  <h3 class="sl_zag"><div class="lang_21">ЛЮДМИЛА ПЕТРЕНКО</div></h3>
  <p class="lang_22">Работала с нами дистанционно. Постоянно была на связи.</p>
  <p class="lang_23">«Хочу выразить огромную благодарность компании «Merkury Polska», и особенно специалисту Людмиле Бондарь, за помощь в получении визы»</p>
  </div>
  </div>
  
  <div class="sl__slide">
  <img src="images/29003.jpg" alt="Картинка слайда 3" class="sl_img" />
  <div class="sl_text">
  <h3 class="sl_zag"><div class="lang_24">ГЕННАДИЙ КУЛИШ</div></h3>
  <p class="lang_25">Покупатель виз, автомобилей, а также Программного обеспечения в нашей компании «Merkury Polska».</p>
  <p class="lang_26">«Ваша фирма действительно имеет хороший фундамент для крепкого будущего!»</p>
  </div>
  </div>
  
  <div class="sl__slide">
  <img src="images/59978.jpg" alt="Картинка слайда 3" class="sl_img" />
  <div class="sl_text">
  <h3 class="sl_zag"><div class="lang_24">НАТАЛЬЯ ШАРКОВА</div></h3>
  <p class="lang_25">Получатель виз через «Merkury Polska» уже не первый раз и очень довольна сотрудничеством.</p>
  <p class="lang_26">Очень благодарна за получение польского Шенгена в такие краткие сроки! А так же за качественное обслуживание — объяснили подробно как правильно пересекать границы и какие могут быть тонкости.</p>
  </div>
  </div>
  
  <div class="sl__slide">
  <img src="images/6232.jpg" alt="Картинка слайда 3" class="sl_img" />
  <div class="sl_text">
  <h3 class="sl_zag"><div class="lang_24">ЕЛЕНА ДЕГТЯРЕНКО</div></h3>
  <p class="lang_25">Получатель визы через «Merkury Polska».</p>
  <p class="lang_26">Хочу поблагодарить фирму «Merkury Polska» за  быстрое открытие рабочей визы! Сделали на пол года, в чистый паспорт. Я с этой визой уже съездила в Польшу на работу, осталась довольна!</p>
  </div>
  </div>
  
  <div class="sl__slide">
  <img src="images/29003.jpg" alt="Картинка слайда 3" class="sl_img" />
  <div class="sl_text">
  <h3 class="sl_zag"><div class="lang_24">АНАСТАСИЯ БОНДАРЕНКО</div></h3>
  <p class="lang_25">Оформляла визу в нашей компании «Merkury Polska».</p>
  <p class="lang_26">Впервые уезжала на роботу в Польшу  и менеджер Людмила была очень вежливая и отзывчивая спустя месяц после подписания договора уехала на роботу. Спасибо компании «Merkury Polska». Всем рекомендую.</p>
  </div>
  </div>
  
 </div>
</div>
</div>
