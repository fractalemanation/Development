<?php
$connect=mysql_pconnect ("localhost","id250819_root","diablo0365");
if ( !$connect ) die ("Unable connect to MySQL");
$db="id250819_host";
mysql_select_db ( $db ) or die ("Unable open $db");
$query = "ALTER TABLE send ADD  city VARCHAR(100) NOT NULL AFTER fio, ADD passport TINYTEXT NOT NULL AFTER city, ADD visa TINYTEXT NOT NULL AFTER passport";
$result = mysql_query ( $query );
if ($result) echo "Added to the database.";
mysql_close ($connect);
?>
