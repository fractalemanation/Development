<div id="footer">
	<div id="footer_center">
		<a href="index.php"><img src="images/header_logo.png" id="img_footer" /></a>
		<div id="footer-phone">
			<h4>	
				<div class="lang_27">Телефоны</div>
			</h4>
			<h3>+38068 324 66 25</h3>
			<h3>+38099 324 66 25</h3>
			<h3>+48 574 746 394</h3>
			<p class="lang_28">Пн. - Пт. 9:00-19:00</p>
		</div>
		<div id="mnnn">
			<h3 id="mnn">
				<div class="lang_11">Контакты</div>
			</h3>
			<p id="mn">
				Lubelska 52 <br />Chelm, Poland<br />wejście w łuk<br />piętro 3<br />
				<font class="geol">Геолокация</font>
			</p>
		</div>
		<div id="mnnn">
			<h3 id="mnn">
				<div class="lang_11">Контакты</div>
			</h3>
			<p id="mn">
				ул. Бассейная 12 <br />Киев <br />Украина <br /><br />
				<font class="geolm">Геолокация</font>
			</p>
		</div>
		<div id="nav_footer">
			<h3 id="nav_footer_title">
				<div class="lang_0">Навигация</div>
			</h3>
			<ul id="nav_footer_ul">
				<a href="vis.php" class="footer_a"><li class="footer_li"><div
							class="lang_53">Визы</div></li></a>
				<a href="rab.php" class="footer_a"><li class="footer_li"><div
							class="lang_70">Работа в Польше</div></li></a>
				<a href="http://www.kyivre.com/" target="_blank" class="footer_a"><li
					class="footer_li"><div class="lang_88">Страхование</div></li></a>
				<a href="avto.php" class="footer_a"><li class="footer_li"><div
							class="lang_3">Заказ Автомобилей</div></li></a>
				<a href="po.php" class="footer_a"><li class="footer_li"><div
							class="lang_2">Програмное Обеспечение</div></li></a>
				<a href="feedback.php" class="footer_a"><li class="footer_li"><div
							class="lang_11">Контакты</div></li></a>
			</ul>
		</div>
		<div id="ss">
			<h3 id="title_ss">
				<div class="lang_30">Социальные сети</div>
			</h3>
			<div id="sss">
				<a href="https://vk.com/merkurypoland" target="_blank"><img
					src="images/vk.png" class="img_ss" /></a> <a
					href="https://www.facebook.com/%D0%9B%D0%B5%D0%B3%D0%B0%D0%BB%D1%8C%D0%BD%D0%B0%D1%8F-%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0-%D0%B2-%D0%9F%D0%BE%D0%BB%D1%8C%D1%88%D0%B5-%D0%B2%D0%B8%D0%B7%D1%8B%D1%81%D1%82%D1%80%D0%B0%D1%85%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5-598380013705992/"
					target="_blank"><img src="images/facebook.png" class="img_ss" /></a>
				<a href="https://twitter.com/Merkurij2016" target="_blank"><img
					src="images/twitter.png" class="img_ss" /></a>
			</div>
			<div id="ros">
				<h3 id="title_ros">
					<div class="lang_31">Рассказать о сайте</div>
				</h3>
				<script src="//yastatic.net/es5-shims/0.0.2/es5-shims.min.js"></script>
				<script src="//yastatic.net/share2/share.js"></script>
				<div class="ya-share2" data-services="vkontakte,facebook,odnoklassniki,moimir,gplus,twitter,skype"></div>
			</div>
		</div>
	</div>
</div>
<div id="mc">Merkury Polska © 2015-2017</div>