﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
</head>
<body id="rol">
<?php
	include ("parts/header.php");
?>
<div id="block-body">

<div id="on-inform">

<div id="block-inform">

<h2 class="h2-titless"><div class="lang_70">Работа в Польше</div></h2>
<div id="brp">
<div id="srp">

<ul class="filter-ul">
<li><a id="block-sort-name"><?php
include("include/db_connect.php");
$sorting = $_GET["sort"];
switch ($sorting) {
	case 'gold-asc';
	$sorting = 'gold ASC';
	$sort_name = 'Маленькие зарплаты ∨';
	$sortings = 'sort=gold-asc';
	break;
	case 'gold-desc';
	$sorting = 'gold DESC';
	$sort_name = 'Большие зарплаты ∨';
	$sortings = 'sort=gold-desc';
	break;
	case 'title';
	$sorting = 'title ASC';
	$sort_name = 'По алфавиту ∨';
	$sortings = 'sort=title';
	break;
	case 'news';
	$sorting = 'id DESC';
	$sort_name = 'По дате обновления ∨';
	$sortings = 'sort=news';
	break;
	case 'male';
	$sorting = "sort_sex = '1' DESC";
	$sort_name = 'Мужчины ∨';
	$sortings = 'sort=male';
	break;
	case 'female';
	$sorting = "sort_sex = '2' DESC";
	$sort_name = 'Женщины ∨';
	$sortings = 'sort=female';
	break;
	case 'age';
	$sorting = "age DESC";
	$sort_name = 'Возраст ∨';
	$sortings = 'sort=age';
	break;
	case 'exp';
	$sorting = "exp DESC";
	$sort_name = 'Возраст ∨';
	$sortings = 'sort=exp';
	break;
	default:
	$sorting = 'id DESC';
	$sort_name = 'Сортировка ∨';
	$sortings = 'q='.$search = $_GET["q"];
	break;
}
echo $sort_name;
?>
</a>
<ul id="block-sort-ul">
<li><a href="search.php?sort=title">По алфавиту</a></li>
<li><a href="search.php?sort=news">По дате обновления</a></li>
<li><a href="search.php?sort=gold-asc">Маленькие зарплаты</a></li>
<li><a href="search.php?sort=gold-desc">Большие зарплаты</a></li>
<li><a href="search.php?sort=male">Мужчины</a></li>
<li><a href="search.php?sort=female">Женщины</a></li>
<li><a href="search.php?sort=age">Возраст</a></li>
<li><a href="search.php?sort=exp">Опыт работы</a></li>
</ul>
</li>
</ul>

</div>
<div class="lines"></div>
<div id="srp">

<div id="block-paramater"> 
<form method="GET" action="search.php?q="> 

<ul class="filter-ul">
<li><a id="block-filter-name1"><?php
$filter_1 = $_GET["filter_1"];
switch ($filter_1) {
	case '1500';
	$filter_1 = "AND gold_filter = '1'";
	$filter_name = '1500 ∨';
	$sortings = 'filter_1=1500';
	break;
	case '1500-2000';
	$filter_1 = "AND gold_filter = '2'";
	$filter_name = '1500-2000 ∨';
	$sortings = 'filter_1=1500-2000';
	break;
	case '2000-2500';
	$filter_1 = "AND gold_filter = '3'";
	$filter_name = '2000-2500 ∨';
	$sortings = 'filter_1=2000-2500';
	break;
	case '2500-3000';
	$filter_1 = "AND gold_filter = '4'";
	$filter_name = 'filter_1=2500-3000 ∨';
	break;
	case '3000-4000';
	$filter_1 = "AND gold_filter = '5'";
	$filter_name = '3000-4000 ∨';
	$sortings = 'filter_1=3000-4000';
	break;
	case '4000-5000';
	$filter_1 = "AND gold_filter = '6'";
	$filter_name = '4000-5000 ∨';
	$sortings = 'filter_1=4000-5000';
	break;
	case '5000-7000';
	$filter_1 = "AND gold_filter = '7'";
	$filter_name = '5000-7000 ∨';
	$sortings = 'filter_1=5000-7000';
	break;
	case '7000-10000';
	$filter_1 = "AND gold_filter = '8'";
	$filter_name = '7000-10000 ∨';
	$sortings = 'filter_1=7000-10000';
	break;
	case '10000-15000';
	$filter_1 = "AND gold_filter = '9'";
	$filter_name = '10000-15000 ∨';
	$sortings = 'filter_1=10000-15000';
	break;
	case '15000';
	$filter_1 = "AND gold_filter = '10'";
	$filter_name = 'Более 15000 ∨';
	$sortings = 'filter_1=15000';
	break;
	default:
	$filter_1 = '';
	$filter_name = 'Зарплата ∨';
	break;
}
echo $filter_name;
?></a>
<ul id="block-filter-ul1">
<li><a href="search.php?filter_1=1500">1500PLN</a></li>
<li><a href="search.php?filter_1=1500-2000">1500-2000PLN</a></li>
<li><a href="search.php?filter_1=2000-2500">2000-2500PLN</a></li>
<li><a href="search.php?filter_1=2500-3000">2500-3000PLN</a></li>
<li><a href="search.php?filter_1=3000-4000">3000-4000PLN</a></li>
<li><a href="search.php?filter_1=4000-5000">4000-5000PLN</a></li>
<li><a href="search.php?filter_1=5000-7000">5000-7000PLN</a></li>
<li><a href="search.php?filter_1=7000-10000">7000-10000PLN</a></li>
<li><a href="search.php?filter_1=10000-15000">10000-15000PLN</a></li>
<li><a href="search.php?filter_1=15000">Более 15000PLN</a></li>
</ul>
</li>
</ul>

<ul class="filter-ul">
<li><a id="block-filter-name"><?php
$filter_2 = $_GET["filter_2"];
switch ($filter_2) {
	case 'day';
	$filter_2 = "AND date = 'day'";
	$filter_name = '1 день ∨';
	$sortings = 'filter_2=day';
	break;
	case 'week';
	$filter_2 = "AND date = 'week'";
	$filter_name = '1 неделя ∨';
	$sortings = 'filter_2=week';
	break;
	case 'weekend';
	$filter_2 = "AND date = 'weekend'";
	$filter_name = '2 недели ∨';
	$sortings = 'filter_2=weekend';
	break;
	case 'month';
	$filter_2 = "AND date = 'month'";
	$filter_name = '1 месяц ∨';
	$sortings = 'filter_2=month';
	break;
	case 'monthed';
	$filter_2 = "AND date = 'monthed'";
	$filter_name = '3 месяцa ∨';
	$sortings = 'filter_2=monthed';
	break;
	case 'monthend';
	$filter_2 = "AND date = 'monthend'";
	$filter_name = 'Более 3-х месяцев ∨';
	$sortings = 'filter_2=monthend';
	break;
	default:
	$filter_2 = '';
	$filter_name = 'Дата обновления ∨';
	break;
}
echo $filter_name;
?></a>
<ul id="block-filter-ul">
<li><a href="search.php?filter_2=day">1 день</a></li>
<li><a href="search.php?filter_2=week">1 неделя</a></li>
<li><a href="search.php?filter_2=weekend">2 недели</a></li>
<li><a href="search.php?filter_2=month">1 месяц</a></li>
<li><a href="search.php?filter_2=monthed">3 месяца</a></li>
<li><a href="search.php?filter_2=monthend">Более 3-х месяцев</a></li>
</ul>
</li>
</ul>

<ul class="filter-ul">
<li><a id="block-filter-name_2"><?php
$filter_3 = $_GET["filter_3"];
switch ($filter_3) {
	case 'male';
	$filter_3 = "AND sort_sex = '1'";
	$filter_name = 'Мужчины ∨';
	$sortings = 'filter_3=male';
	break;
	case 'female';
	$filter_3 = "AND sort_sex = '2'";
	$filter_name = 'Женщины ∨';
	$sortings = 'filter_3=female';
	break;
	case 'femamale';
	$filter_3 = "AND sort_sex = '3'";
	$filter_name = 'Муж. и Жен. ∨';
	$sortings = 'filter_3=femamale';
	break;
	case 'family';
	$filter_3 = "AND sort_sex = '4'";
	$filter_name = 'Семейные пары ∨';
	$sortings = 'filter_3=family';
	break;
	case 'other';
	$filter_3 = "AND sort_sex = '5'";
	$filter_name = 'Другие варианты ∨';
	$sortings = 'filter_3=other';
	break;
	default:
	$filter_3 = '';
	$filter_name = 'Пол ∨';
	break;
}
echo $filter_name;
?></a>
<ul id="block-filter-ul_2">
<li><a href="search.php?filter_3=male">Мужчины</a></li>
<li><a href="search.php?filter_3=female">Женщины</a></li>
<li><a href="search.php?filter_3=femamale">Муж. и Жен.</a></li>
<li><a href="search.php?filter_3=family">Семейные пары</a></li>
<li><a href="search.php?filter_3=other">Другие варианты</a></li>
</ul>
</li>
</ul>

<ul class="filter-ul">
<li><a id="block-filter-name_3"><?php
$filter_4 = $_GET["filter_4"];
switch ($filter_4) {
	case '20';
	$filter_4 = "AND age_filter = '1'";
	$filter_name = 'До 20-ти ∨';
	$sortings = 'filter_4=20';
	break;
	case '20-40';
	$filter_4 = "AND age_filter = '2'";
	$filter_name = '20-40 ∨';
	$sortings = 'filter_4=20-40';
	break;
	case '40-50';
	$filter_4 = "AND age_filter = '3'";
	$filter_name = '40-50 ∨';
	$sortings = 'filter_4=40-50';
	break;
	case 'age';
	$filter_4 = "AND age_filter = '4'";
	$filter_name = 'Не указан ∨';
	$sortings = 'filter_4=age';
	break;
	default:
	$filter_4 = '';
	$filter_name = 'Возраст ∨';
	break;
}
echo $filter_name;
?></a>
<ul id="block-filter-ul_3">
<li><a href="search.php?filter_4=20">До 20-ти</a></li>
<li><a href="search.php?filter_4=20-40">20-40</a></li>
<li><a href="search.php?filter_4=40-50">40-50</a></li>
<li><a href="search.php?filter_4=age">Не указан</a></li>
</ul>
</li>
</ul>

<ul class="filter-ul">
<li><a id="block-filter-name_4"><?php
$filter_5 = $_GET["filter_5"];
switch ($filter_5) {
	case 'wexp';
	$filter_5 = "AND exp_filter = '1'";
	$filter_name = 'С опытом ∨';
	$sortings = 'filter_5=wexp';
	break;
	case 'oexp';
	$filter_5 = "AND exp_filter = '2'";
	$filter_name = 'Без опыта ∨';
	$sortings = 'filter_5=oexp';
	break;
	default:
	$filter_5 = '';
	$filter_name = 'Опыт ∨';
	break;
}
echo $filter_name;
?></a>
<ul id="block-filter-ul_4">
<li><a href="search.php?filter_5=wexp">С опытом</a></li>
<li><a href="search.php?filter_5=oexp">Без опыта</a></li>
</ul>
</li>
</ul>

<ul class="filter_ul">
<input type="text" id="input-search" name="q" placeholder="Название профессии" autocomplete="off" value="<?php echo $search = $_GET["q"];?>" />
<ul id="result-search">
</ul>
</ul>
<center><input type="submit" id="search" value="Фильтры" /></center> 
</form>
</div>

</div>

<div id="drp">
<div id="zarp" class="lang_71">Изображение</div>
<div id="opis" class="lang_72">Описание</div>
<div id="zarp" class="lang_73">Зарплата</div>
</div>
</div>

<div id="workpol">
<?php
define('kop', true);
include('include/db_connect.php');

$search = $_GET["q"];

function uan ($first) {
	$second = 6.76;
	$summa = $first * $second;
	return $summa;
}
function usd ($first) {
	$second = 4.09;
	$summa = $first / $second;
	return $summa;
}
function eur ($first) {
	$second = 4.37;
	$summa = $first / $second;
	return $summa;
}


$num = 40;
$page = (int)$_GET['page'];
$count = mysql_query("SELECT COUNT(*) FROM vacancies WHERE title LIKE '%$search%' $filter_1 $filter_2 $filter_3 $filter_4 $filter_5", $link);
$temp = mysql_fetch_array($count);
if ($temp[0] > 0) {
	$tempcount = $temp[0];
	$total = (($tempcount - 1) / $num) + 1;
	$total = intval($total);
	$page = intval($page);
	if (empty($page) or $page < 0) $page = 1;
	if ($page > $total) $page = $total;
	$start = $page * $num - $num;
	$qury_start_num = "LIMIT $start, $num";
}

$result = mysql_query("SELECT * FROM vacancies WHERE title LIKE '%$search%' $filter_1 $filter_2 $filter_3 $filter_4 $filter_5 ORDER BY $sorting $qury_start_num", $link);
if (mysql_num_rows($result) > 0) {
	$row = mysql_fetch_array($result);	
do {
	echo '
	<ul>
	<div class="zarp">'.$row[gold].'<br />'.round($sum = uan ($row[gold])).'-'.round($sum = uan (substr($row[gold], 5))).' UAH <br />'.round($sum = usd ($row[gold])).'-'.round($sum = usd (substr($row[gold], 5))).' USD <br />'.round($sum = eur ($row[gold])).'-'.round($sum = eur (substr($row[gold], 5))).' EUR</div>
	<li>
	<img src="images/vacancies/'.$row[image].'" />
	<a href="">'.$row[title].'</a>
	<p>Страна:'.$row[country].'</p>
	<p>Пол: '.$row[sex].'</p>
	<p>Возраст: '.$row[age].'</p>
	<p>Опыт работы: '.$row[exp].'</p>
	<p>Обязанности: '.$row[charge].'</p>
	<p>Условия проживания: '.$row[live].'</p>
	<p>Рабочий график: '.$row[work].'</p>
	</li>
	<div class="dr" id="'.$row[id].'">ДОБАВИТЬ РЕЗЮМЕ</div>
	</ul>
	';
}while ($row = mysql_fetch_array($result));
}
?>
</div>

<?php
if ($page != 1){ $pstr_prev = '<li><a class="pstr-prev" href="search.php?'.$sortings.'&page='.($page - 1).'">&lt;</a></li>';}
if ($page != $total) $pstr_next = '<li><a class="pstr-next" href="search.php?'.$sortings.'&page='.($page + 1).'">&gt;</a></li>';

if($page - 5 > 0) $page5left = '<li><a href="search.php?'.$sortings.'&page='.($page - 5).'">'.($page - 5).'</a></li>';
if($page - 4 > 0) $page4left = '<li><a href="search.php?'.$sortings.'&page='.($page - 4).'">'.($page - 4).'</a></li>';
if($page - 3 > 0) $page3left = '<li><a href="search.php?'.$sortings.'&page='.($page - 3).'">'.($page - 3).'</a></li>';
if($page - 2 > 0) $page2left = '<li><a href="search.php?'.$sortings.'&page='.($page - 2).'">'.($page - 2).'</a></li>';
if($page - 1 > 0) $page1left = '<li><a href="search.php?'.$sortings.'&page='.($page - 1).'">'.($page - 1).'</a></li>';
 
if($page + 5 <= $total) $page5right = '<li><a href="search.php?'.$sortings.'&page='.($page + 5).'">'.($page + 5).'</a></li>';

if($page + 4 <= $total) $page4right = '<li><a href="search.php?'.$sortings.'&page='.($page + 4).'">'.($page + 4).'</a></li>';
if($page + 3 <= $total) $page3right = '<li><a href="search.php?'.$sortings.'&page='.($page + 3).'">'.($page + 3).'</a></li>';
if($page + 2 <= $total) $page2right = '<li><a href="search.php?'.$sortings.'&page='.($page + 2).'">'.($page + 2).'</a></li>';
if($page + 1 <= $total) $page1right = '<li><a href="search.php?'.$sortings.'&page='.($page + 1).'">'.($page + 1).'</a></li>';
 
 
if ($page+5 < $total) {
    $strtotal = '<li><p class="nav-point">...</p></li><li><a href="search.php?'.$sortings.'&page='.$total.'">'.$total.'</a></li>';
}else {
    $strtotal = ""; 
}
if ($total > 1) {
    echo '
    <div class="pstrnav">
    <ul>
    ';
    echo $pstr_prev.$page5left.$page4left.$page3left.$page2left.$page1left."<li><a class='pstr-active' href='search.php?".$sortings."&page=".$page."'>".$page."</a></li>".$page1right.$page2right.$page3right.$page4right.$page5right.$strtotal.$pstr_next;
    echo '
    </ul>
    </div>
    ';
}
?>

</div>

</div>

</div>

<?php
	include ("parts/footer.php");
?>

<script src="js/slick.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>