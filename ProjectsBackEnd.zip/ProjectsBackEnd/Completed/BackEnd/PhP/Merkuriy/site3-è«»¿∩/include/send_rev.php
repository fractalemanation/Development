﻿<?php
$recepient = "bondar3171@gmail.com";
$sitename = "merkurij.pl";

$fio = trim($_POST["fname"]);
$email = trim($_POST["ema"]);
$text = trim($_POST["text"]);

$message = "Имя: $fio \nEmail: $email \nТекст: $text";

$pagetitle = "Новый отзыв с сайта \"$sitename\" - от $fio";

mail($recepient, $pagetitle, $message, "Content-type: text/plain; charset=\"utf-8\"\n From: $recepient");

$fio2 = trim($_POST["fname"]);
$email2 = trim($_POST["ema"]);
$sitename2 = "merkurij.pl";
$message2 = "Уважаемый(ая) $fio2 \nВаш отзыв получен и в ближайшее время будет обработан. \nРады сотрудничеству с Вами.";
 
$pagetitle2 = "Подтверждение отзыва на сайте \"$sitename2\"";
mail($email2, $pagetitle2, $message2, "Content-type: text/plain; charset=\"utf-8\"");



mysql_connect("localhost", "root", "Distribx01!"); 
mysql_query("SET NAMES utf8");
mysql_select_db("id250819_host");
mysql_query("INSERT INTO send_rev (`fio`, `email`, `text`) VALUES('".$fio."', '".$email."', '".$text."')");
?>
