﻿<?php
defined('kop') or die ('<h1 align="center">Доступ запрещён!</h1>');
$db_host = 'localhost';
$db_user = 'id250819_root';
$db_pass = 'diablo0365';
$db_database = 'id250819_host';
$link = mysql_connect($db_host, $db_user, $db_pass);
mysql_set_charset("utf8", $link);
mysql_select_db($db_database, $link) or die ("Нет соедения с БД ".mysql_error());
?>
