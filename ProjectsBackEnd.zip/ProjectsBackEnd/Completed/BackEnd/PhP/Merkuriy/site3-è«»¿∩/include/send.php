﻿<?php
$recepient = "bondar3171@gmail.com";
$sitename = "merkurij.pl";

$fio = trim($_POST["fio"]);
$city = trim($_POST["city"]);
$age = trim($_POST["age"]);
$vacancy = trim($_POST["vacancy"]);
$passport= trim($_POST["passport"]);
$visa = trim($_POST["visa"]);
$lang = trim($_POST["language"]);
$email = trim($_POST["emai"]);
$phone = trim($_POST["phon"]);
$text = trim($_POST["text"]);

$message = "Имя: $fio \nГород: $city \nВозраст: $age \nВакансия: $vacancy \nПаспорт: $passport \nНаличие открытой визы: $visa \nЯзык: $lang \nEmail: $email \nТелефон: $phone \nТекст: $text";

$pagetitle = "Новая заявка с сайта \"$sitename\" - от $fio, $city";
mail($recepient, $pagetitle, $message, "Content-type: text/plain; charset=\"utf-8\"\n From: $recepient");

//$link = mysqli_connect("localhost", "root", "Distribx01!", "id250819_host"); 
//mysqli_query($link, "INSERT INTO `send` VALUES('', '".$fio."', '".$city."', '".$age."', '".$vacancy."', '".$passport."', '".$visa."', '".$lang."', '".$email."', '".$phone."', '".$text."', NOW(),)");

mysql_connect("localhost", "root", "Distribx01!"); 
mysql_query("SET NAMES utf8");
mysql_select_db("id250819_host");
mysql_query("INSERT INTO send (`fio`, `city`, `age`, `vacancy`, `passport`, `visa`, `lang`, `email`, `phone`, `text`, `date`, `version`) VALUES('".$fio."', '".$city."', '".$age."', '".$vacancy."', '".$passport."', '".$visa."', '".$lang."', '".$email."', '".$phone."', '".$text."', NOW(), (SELECT `variable_value` FROM `id250819_host`.`site_variables` WHERE `variable_name` = 'release_version'))");
?>