<?php
	session_start();   
    if($_SESSION['img_captcha'] == strtolower($_POST['reg_captc']))
    {
        echo 'true';
    } else { echo 'false'; }
?>