﻿<?php
$recepient = "merkurijpoland@gmail.com";
$sitename = "merkurij.pl";

$name = trim($_POST["name"]);
$email = trim($_POST["email"]);
$phone = trim($_POST["phone"]);
$text = trim($_POST["text"]);
$message = "Имя: $name \nEmail: $email \nТелефон: $phone \nТекст: $text";

$pagetitle = "Новая информация от $name, т. $phone";

mail($recepient, $pagetitle, $message, "Content-type: text/plain; charset=\"utf-8\"\n From: $recepient");
mail($email, $pagetitle, "Ваш отзыв успешно отправлен!\n".$message, "Content-type: text/plain; charset=\"utf-8\"\n From: $recepient");

mysql_connect("localhost", "root", "Distribx01!"); 
mysql_query("SET NAMES utf8");
mysql_select_db("id250819_host");
mysql_query("INSERT INTO mail (`name`, `email`, `phone`, `text`, `date`) VALUES('".$name."', '".$email."', '".$phone."', '".$text."', NOW())");

?>