﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
</head>
<body>
<?php
include ("parts/header.php");
?>
<div id="block-body">

<div id="on-inform" style="height:619px;">

<div id="block-inform">

<h2 class="h2-titles"><div class="lang_58">Благотворительные фонды</div></h2>
<div class="textons"><div class="lang_59">Киевский благотворительный фонд «Возрождение Украинской Нации» осуществляет помощь детям, беженцам из Крыма, религиозным организациям.<br />Учредители фонда – киевская волонтерская группа, в которуювходят организаторы украинцы и беженцы из Крымских татар.<br />Украинцы же верят в святое правило «Помоги ближнему и тебевоздастся вдвойне», а также считают что возрождение Украинской нациисильно затрудненно без союзников которые испытуют похожие трудности.</div></div>
<div class="h2-titles-mini"><div class="lang_60">Наша Миссия</div></div>
<div id="imag_text">
<div class="img_and_text"><img src="images/children.jpg" class="img" /><div class="text"><div class="lang_61">Фонд помощи «Возрождение Украинской Нации», приобрел генератор, батарейки и свечи для трех детей из Крыма, которым помогает детская региональная программа фонда. Речь идет о детях стяжелыми заболеваниями, ограничивающими их срок жизни.</div></div></div>
<div class="img_and_text"><img src="images/reab.jpg" class="img" /><div class="text"><div class="lang_62">Благодаря финансовой поддержке Благотворительному фонду«Возрождение Украинской Нации», детей повезли на курс лечения иреабилитации в США. Медицина, как и уровень жизни там заслуживает всяческого уважения и восхищения..</div></div></div>
<div class="img_and_text"><img src="images/church.jpg" class="img" /><div class="text"><div class="lang_63">Благотворительный фонд «Возрождение Украинской Нации», всегда помогает возрождению украинским церквям. Религиозная идентичность вправославных странах во многом зависит от того, кем является человекили чем он занимается.</div></div></div>
<div class="img_and_text"><img src="images/mechet.jpg" class="img" /><div class="text"><div class="lang_64">Благотворительный фонд оказывает помощь в реставрации старых мечетей на территории Украины.<br />«Вся мудрость в том, чтоб радостно»<br />«Во славу Аллаха петь и помогать»<br />«Равно да будет сладостно и жить, и умереть»</div></div></div>
</div>

</div>

</div>

</div>

<?php
	include ("parts/footer.php");
?>

<script src="js/slick.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>