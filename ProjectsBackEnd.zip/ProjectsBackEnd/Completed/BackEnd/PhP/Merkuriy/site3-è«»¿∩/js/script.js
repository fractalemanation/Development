$(function(){
var x;
if(navigator.cookieEnabled){
if($.cookie('lang')&&$("select[name='lang']").val()!==$.cookie('lang')){
x = $.cookie('lang');
$("select[name='lang']").val(x);
$.get('/include/json.php',
{lang:x},
function(data){
data = JSON.parse(data);
$('div[class="lang_0"]').html(data["0"]);
$('div[class="lang_1"]').html(data["1"]);
$('a[id="lang_1"]').html(data["1"]);
$('div[class="lang_2"]').html(data["2"]);
$('div[class="lang_3"]').html(data["3"]);
$('div[class="lang_4"]').html(data["4"]);
$('div[class="lang_5"]').html(data["5"]);
$('div[class="lang_6"]').html(data["6"]);
$('div[class="lang_7"]').html(data["7"]);
$('div[class="lang_8"]').html(data["8"]);
$('div[class="lang_9"]').html(data["9"]);
$('div[class="lang_10"]').html(data["10"]);
$('div[class="lang_11"]').html(data["11"]);
$('div[class="lang_12"]').html(data["12"]);
$('div[class="lang_13"]').html(data["13"]);
$('div[class="lang_14"]').html(data["14"]);
$('p[class="lang_15"]').html(data["15"]);
$('div[class="lang_16"]').html(data["16"]);
$('div[class="lang_17"]').html(data["17"]);
$('div[class="lang_18"]').html(data["18"]);
$('p[class="lang_19"]').html(data["19"]);
$('p[class="lang_20"]').html(data["20"]);
$('div[class="lang_21"]').html(data["21"]);
$('p[class="lang_22"]').html(data["22"]);
$('p[class="lang_23"]').html(data["23"]);
$('div[class="lang_24"]').html(data["24"]);
$('p[class="lang_25"]').html(data["25"]);
$('p[class="lang_26"]').html(data["26"]);
$('div[class="lang_27"]').html(data["27"]);
$('p[class="lang_28"]').html(data["28"]);
$('div[class="lang_29"]').html(data["29"]);
$('div[class="lang_30"]').html(data["30"]);
$('div[class="lang_31"]').html(data["31"]);
$('div[class="lang_32"]').html(data["32"]);
$('div[class="lang_33"]').html(data["33"]);
$('div[class="lang_34"]').html(data["34"]);
$('div[class="lang_35"]').html(data["35"]);
$('div[class="lang_36"]').html(data["36"]);
$('div[class="lang_37"]').html(data["37"]);
$('div[class="lang_38"]').html(data["38"]);
$('div[class="lang_39"]').html(data["39"]);
$('div[class="lang_40"]').html(data["40"]);
$('div[class="lang_41"]').html(data["41"]);
$('div[class="lang_42"]').html(data["42"]);
$('div[class="lang_43"]').html(data["43"]);
$('div[class="lang_44"]').html(data["44"]);
$('div[class="lang_45"]').html(data["45"]);
$('div[class="lang_46"]').html(data["46"]);
$('div[class="lang_47"]').html(data["47"]);
$('div[class="lang_48"]').html(data["48"]);
$('div[class="lang_49"]').html(data["49"]);
$('div[class="lang_50"]').html(data["50"]);
$('div[class="lang_51"]').html(data["51"]);
$('div[class="lang_52"]').html(data["52"]);
$('div[class="lang_53"]').html(data["53"]);
$('a[id="lang_53"]').html(data["53"]);
$('div[class="lang_54"]').html(data["54"]);
$('div[class="lang_55"]').html(data["55"]);
$('div[class="lang_56"]').html(data["56"]);
$('a[class="lang_56"]').html(data["56"]);
$('div[class="lang_56_1"]').html(data["56_1"]);
$('a[class="lang_56_1"]').html(data["56_1"]);
$('a[class="lang_56_2"]').html(data["56_2"]);
$('div[class="lang_56_2"]').html(data["56_2"]);
$('div[class="lang_56_3"]').html(data["56_3"]);
$('a[class="lang_56_3"]').html(data["56_3"]);
$('a[class="lang_56_4"]').html(data["56_4"]);
$('div[class="lang_56_4"]').html(data["56_4"]);
$('a[class="lang_56_5"]').html(data["56_5"]);
$('div[class="lang_56_5"]').html(data["56_5"]);
$('div[class="lang_57"]').html(data["57"]);
$('div[class="lang_58"]').html(data["58"]);
$('div[class="lang_59"]').html(data["59"]);
$('div[class="lang_60"]').html(data["60"]);
$('div[class="lang_61"]').html(data["61"]);
$('div[class="lang_62"]').html(data["62"]);
$('div[class="lang_63"]').html(data["63"]);
$('div[class="lang_64"]').html(data["64"]);
$('div[class="lang_65"]').html(data["65"]);
$('div[class="lang_66"]').html(data["66"]);
$('div[class="lang_67"]').html(data["67"]);
$('div[class="lang_68"]').html(data["68"]);
$('div[class="lang_69"]').html(data["69"]);
$('div[class="lang_70"]').html(data["70"]);
$('div[class="lang_71"]').html(data["71"]);
$('div[class="lang_72"]').html(data["72"]);
$('div[class="lang_73"]').html(data["73"]);
$('div[class="lang_74"]').html(data["74"]);
$('p[class="lang_75"]').html(data["75"]);
$('div[class="lang_76"]').html(data["76"]);
$('div[class="lang_77"]').html(data["77"]);
$('div[class="lang_78"]').html(data["78"]);
$('div[class="lang_79"]').html(data["79"]);
$('div[class="lang_80"]').html(data["80"]);
$('div[class="lang_81"]').html(data["81"]);
$('div[class="lang_82"]').html(data["82"]);
$('div[class="lang_83"]').html(data["83"]);
$('div[class="lang_84"]').html(data["84"]);
$('div[class="lang_85"]').html(data["85"]);
$('a[id="lang_86"]').html(data["86"]);
$('div[class="lang_87"]').html(data["87"]);
$('div[class="lang_88"]').html(data["88"]);
$('a[id="lang_88"]').html(data["88"]);
$('div[class="lang_89"]').html(data["89"]);
$('a[id="lang_89"]').html(data["89"]);
$('div[class="lang_90"]').html(data["90"]);
$('a[id="lang_91"]').html(data["91"]);
$('div[class="lang_92"]').html(data["92"]);
$('div[class="lang_93"]').html(data["93"]);
$('div[class="lang_94"]').html(data["94"]);
$('div[class="lang_95"]').html(data["95"]);
$('div[class="lang_96"]').html(data["96"]);
$('div[class="lang_97"]').html(data["97"]);
$('div[class="lang_98"]').html(data["98"]);
$('span[id="lang_99"]').html(data["99"]);
$('div[class="lang_100"]').html(data["100"]);
$('div[class="lang_101"]').html(data["101"]);
$('div[class="lang_102"]').html(data["102"]);
$('div[class="lang_103"]').html(data["103"]);
//$('body').append($('<input name="city" placeholder="'data["104"])+'" />');
$('option[class="lang_105"]').html(data["105"]);
$('option[class="lang_106"]').html(data["106"]);
$('option[class="lang_107"]').html(data["107"]);
$('option[class="lang_108"]').html(data["108"]);
$('option[class="lang_109"]').html(data["109"]);
$('div[class="lang_110"]').html(data["110"]);
$('h3[class="lang_111"]').html(data["111"]);
$('p[class="lang_112"]').html(data["112"]);
$('p[class="lang_113"]').html(data["113"]);
$('p[class="lang_114"]').html(data["114"]);
$('p[class="lang_115"]').html(data["115"]);
$('p[class="lang_116"]').html(data["116"]);

if (x == "1") {
	$('#block-news').show();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
}
else if (x == "2") {
	$('#block-news2').show();
	$('#block-news').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker2").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev2",
	btnNext: "#news-next2",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (x == "3") {
	$('#block-news3').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker3").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev3",
	btnNext: "#news-next3",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (x == "4") {
	$('#block-news4').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news5').hide();
	$("#newsticker4").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev4",
	btnNext: "#news-next4",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (x == "5") {
	$('#block-news5').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$("#newsticker5").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev5",
	btnNext: "#news-next5",
	visible: 3,
	auto: 3000,
	speed: 500
});
}

});
}
}

$("select[name='lang']").on('change', function(){
x = $("select[name='lang']").val();
$.get('/include/json.php',
{lang:x},
function(data){
data = JSON.parse(data);
$('div[class="lang_0"]').html(data["0"]);
$('div[class="lang_1"]').html(data["1"]);
$('a[id="lang_1"]').html(data["1"]);
$('div[class="lang_2"]').html(data["2"]);
$('div[class="lang_3"]').html(data["3"]);
$('div[class="lang_4"]').html(data["4"]);
$('div[class="lang_5"]').html(data["5"]);
$('div[class="lang_6"]').html(data["6"]);
$('div[class="lang_7"]').html(data["7"]);
$('div[class="lang_8"]').html(data["8"]);
$('div[class="lang_9"]').html(data["9"]);
$('div[class="lang_10"]').html(data["10"]);
$('div[class="lang_11"]').html(data["11"]);
$('div[class="lang_12"]').html(data["12"]);
$('div[class="lang_13"]').html(data["13"]);
$('div[class="lang_14"]').html(data["14"]);
$('p[class="lang_15"]').html(data["15"]);
$('div[class="lang_16"]').html(data["16"]);
$('div[class="lang_17"]').html(data["17"]);
$('div[class="lang_18"]').html(data["18"]);
$('p[class="lang_19"]').html(data["19"]);
$('p[class="lang_20"]').html(data["20"]);
$('div[class="lang_21"]').html(data["21"]);
$('p[class="lang_22"]').html(data["22"]);
$('p[class="lang_23"]').html(data["23"]);
$('div[class="lang_24"]').html(data["24"]);
$('p[class="lang_25"]').html(data["25"]);
$('p[class="lang_26"]').html(data["26"]);
$('div[class="lang_27"]').html(data["27"]);
$('p[class="lang_28"]').html(data["28"]);
$('div[class="lang_29"]').html(data["29"]);
$('div[class="lang_30"]').html(data["30"]);
$('div[class="lang_31"]').html(data["31"]);
$('div[class="lang_32"]').html(data["32"]);
$('div[class="lang_33"]').html(data["33"]);
$('div[class="lang_34"]').html(data["34"]);
$('div[class="lang_35"]').html(data["35"]);
$('div[class="lang_36"]').html(data["36"]);
$('div[class="lang_37"]').html(data["37"]);
$('div[class="lang_38"]').html(data["38"]);
$('div[class="lang_39"]').html(data["39"]);
$('div[class="lang_40"]').html(data["40"]);
$('div[class="lang_41"]').html(data["41"]);
$('div[class="lang_42"]').html(data["42"]);
$('div[class="lang_43"]').html(data["43"]);
$('div[class="lang_44"]').html(data["44"]);
$('div[class="lang_45"]').html(data["45"]);
$('div[class="lang_46"]').html(data["46"]);
$('div[class="lang_47"]').html(data["47"]);
$('div[class="lang_48"]').html(data["48"]);
$('div[class="lang_49"]').html(data["49"]);
$('div[class="lang_50"]').html(data["50"]);
$('div[class="lang_51"]').html(data["51"]);
$('div[class="lang_52"]').html(data["52"]);
$('div[class="lang_53"]').html(data["53"]);
$('a[id="lang_53"]').html(data["53"]);
$('div[class="lang_54"]').html(data["54"]);
$('div[class="lang_55"]').html(data["55"]);
$('div[class="lang_56"]').html(data["56"]);
$('a[class="lang_56"]').html(data["56"]);
$('div[class="lang_56_1"]').html(data["56_1"]);
$('a[class="lang_56_1"]').html(data["56_1"]);
$('a[class="lang_56_2"]').html(data["56_2"]);
$('div[class="lang_56_2"]').html(data["56_2"]);
$('div[class="lang_56_3"]').html(data["56_3"]);
$('a[class="lang_56_3"]').html(data["56_3"]);
$('a[class="lang_56_4"]').html(data["56_4"]);
$('div[class="lang_56_4"]').html(data["56_4"]);
$('a[class="lang_56_5"]').html(data["56_5"]);
$('div[class="lang_56_5"]').html(data["56_5"]);
$('div[class="lang_57"]').html(data["57"]);
$('div[class="lang_58"]').html(data["58"]);
$('div[class="lang_59"]').html(data["59"]);
$('div[class="lang_60"]').html(data["60"]);
$('div[class="lang_61"]').html(data["61"]);
$('div[class="lang_62"]').html(data["62"]);
$('div[class="lang_63"]').html(data["63"]);
$('div[class="lang_64"]').html(data["64"]);
$('div[class="lang_65"]').html(data["65"]);
$('div[class="lang_66"]').html(data["66"]);
$('div[class="lang_67"]').html(data["67"]);
$('div[class="lang_68"]').html(data["68"]);
$('div[class="lang_69"]').html(data["69"]);
$('div[class="lang_70"]').html(data["70"]);
$('div[class="lang_71"]').html(data["71"]);
$('div[class="lang_72"]').html(data["72"]);
$('div[class="lang_73"]').html(data["73"]);
$('div[class="lang_74"]').html(data["74"]);
$('p[class="lang_75"]').html(data["75"]);
$('div[class="lang_76"]').html(data["76"]);
$('div[class="lang_77"]').html(data["77"]);
$('div[class="lang_78"]').html(data["78"]);
$('div[class="lang_79"]').html(data["79"]);
$('div[class="lang_80"]').html(data["80"]);
$('div[class="lang_81"]').html(data["81"]);
$('div[class="lang_82"]').html(data["82"]);
$('div[class="lang_83"]').html(data["83"]);
$('div[class="lang_84"]').html(data["84"]);
$('div[class="lang_85"]').html(data["85"]);
$('a[id="lang_86"]').html(data["86"]);
$('div[class="lang_87"]').html(data["87"]);
$('div[class="lang_88"]').html(data["88"]);
$('a[id="lang_88"]').html(data["88"]);
$('div[class="lang_89"]').html(data["89"]);
$('a[id="lang_89"]').html(data["89"]);
$('div[class="lang_90"]').html(data["90"]);
$('a[id="lang_91"]').html(data["91"]);
$('div[class="lang_92"]').html(data["92"]);
$('div[class="lang_93"]').html(data["93"]);
$('div[class="lang_94"]').html(data["94"]);
$('div[class="lang_95"]').html(data["95"]);
$('div[class="lang_96"]').html(data["96"]);
$('div[class="lang_97"]').html(data["97"]);
$('div[class="lang_98"]').html(data["98"]);
$('span[id="lang_99"]').html(data["99"]);
$('div[class="lang_100"]').html(data["100"]);
$('div[class="lang_101"]').html(data["101"]);
$('div[class="lang_102"]').html(data["102"]);
$('div[class="lang_103"]').html(data["103"]);
//$('body').append($('<input name="city" placeholder="'data["104"])+'" />');
$('option[class="lang_105"]').html(data["105"]);
$('option[class="lang_106"]').html(data["106"]);
$('option[class="lang_107"]').html(data["107"]);
$('option[class="lang_108"]').html(data["108"]);
$('option[class="lang_109"]').html(data["109"]);
$('div[class="lang_110"]').html(data["110"]);
$('h3[class="lang_111"]').html(data["111"]);
$('p[class="lang_112"]').html(data["112"]);
$('p[class="lang_113"]').html(data["113"]);
$('p[class="lang_114"]').html(data["114"]);
$('p[class="lang_115"]').html(data["115"]);
$('p[class="lang_116"]').html(data["116"]);

if (x == "1") {
	$('#block-news').show();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
}
else if (x == "2") {
	$('#block-news2').show();
	$('#block-news').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker2").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev2",
	btnNext: "#news-next2",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (x == "3") {
	$('#block-news3').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker3").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev3",
	btnNext: "#news-next3",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (x == "4") {
	$('#block-news4').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news5').hide();
	$("#newsticker4").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev4",
	btnNext: "#news-next4",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (x == "5") {
	$('#block-news5').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$("#newsticker5").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev5",
	btnNext: "#news-next5",
	visible: 3,
	auto: 3000,
	speed: 500
});
}

if(navigator.cookieEnabled){
	$.cookie('lang',x, {expires: 365, path:'/'});
}
});
});
});



$(function(){
var z;
if(navigator.cookieEnabled){
if($.cookie('lang')&&$("select[name='lang']").val()!==$.cookie('lang')){
z = $.cookie('lang');
$("select[name='lang']").val(z);
if (z == "1") {
	$('#block-news').show();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
}
else if (z == "2") {
	$('#block-news2').show();
	$('#block-news').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker2").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev2",
	btnNext: "#news-next2",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (z == "3") {
	$('#block-news3').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker3").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev3",
	btnNext: "#news-next3",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (z == "4") {
	$('#block-news4').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news5').hide();
	$("#newsticker4").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev4",
	btnNext: "#news-next4",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (z == "5") {
	$('#block-news5').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$("#newsticker5").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev5",
	btnNext: "#news-next5",
	visible: 3,
	auto: 3000,
	speed: 500
});
}

}
}

$("select[name='lang']").on('change', function(){
z = $("select[name='lang']").val();
if (z == "1") {
	$('#block-news').show();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
}
else if (z == "2") {
	$('#block-news2').show();
	$('#block-news').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker2").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev2",
	btnNext: "#news-next2",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (z == "3") {
	$('#block-news3').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news4').hide();
	$('#block-news5').hide();
	$("#newsticker3").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev3",
	btnNext: "#news-next3",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (z == "4") {
	$('#block-news4').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news5').hide();
	$("#newsticker4").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev4",
	btnNext: "#news-next4",
	visible: 3,
	auto: 3000,
	speed: 500
});
}
else if (z == "5") {
	$('#block-news5').show();
	$('#block-news').hide();
	$('#block-news2').hide();
	$('#block-news3').hide();
	$('#block-news4').hide();
	$("#newsticker5").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev5",
	btnNext: "#news-next5",
	visible: 3,
	auto: 3000,
	speed: 500
});
}

if(navigator.cookieEnabled){
	$.cookie('lang', z, {expires: 365, path:'/'});
}

});

});


$("#block-sort-name").click (function () {
	$("#block-sort-ul").slideToggle(200);
});

$("#block-filter-name1").click (function () {
	$("#block-filter-ul1").slideToggle(200);
});

$("#block-filter-name").click (function () {
	$("#block-filter-ul").slideToggle(200);
});

$("#block-filter-name_2").click (function () {
	$("#block-filter-ul_2").slideToggle(200);
});

$("#block-filter-name_3").click (function () {
	$("#block-filter-ul_3").slideToggle(200);
});

$("#block-filter-name_4").click (function () {
	$("#block-filter-ul_4").slideToggle(200);
});

$('#input-search').bind('textchange', function() {
	var input_search = $("#input-search").val();
	if (input_search.length >= 1 && input_search.length < 150) {
		$.ajax ({
			type: "POST",
			url: "include/search.php",
			data: "text="+input_search,
			dataType: "html",
			cache: false,
			success: function(data) {
				if (data > '') {
					$("#result-search").show().html(data);
				}else {
					$("#result-search").hide();
				}
			}
		});
	}else {
		$("#result-search").hide();
	}
});

$(document).ready(function () {
	$(".dr").bind("click", function () {
		$("#block-dr").slideDown(500);
		var id_row = this.id;
		$('#vacancy option').each(function () {
			if ($(this).val() == id_row) {
				this.selected = true;
				}else {
					this.selected = false;
				}
		});
	});
	
	$(".hide-dr").bind("click", hidedr);
	function hidedr() {
		$("#block-dr").slideUp(500);
	}
});

$(document).ready(function () {
	$("#dr2").bind("click", function () {
		$("#block-dr2").slideDown(500);
		var id_row = this.id;
		$('#vacancy option').each(function () {
			if ($(this).val() == id_row) {
				this.selected = true;
				}else {
					this.selected = false;
				}
		});
	});
	$(".hide-dr").bind("click", hidedr);
	function hidedr() {
		$("#block-dr2").slideUp(500);
	}
});
$(document).ready(function() {
$(".show").bind("click", show);
$(".shide").bind("click", shide);
$(".hide").bind("click", hide);
function show() {
	$("#navig").show(500);
	$(".show").hide();
	$(".shide").show();
}
function shide(){
		$("#navig").hide(500);
		$(".shide").hide();
		$(".show").show();
}
function hide(){
		$("#navig").hide(500);
		$(".shide").hide();
		$(".show").show();
}
});

$('.geol').click(function() {
	$('#ifm2').slideToggle(500);
	$('#ifm1').hide();
});

$('.geolm').click(function() {
	$('#ifm1').slideToggle(500);
	$('#ifm2').hide();
});

$('#del1').click(function() {
	$('#ifm1').slideUp(400);
});

$('#del2').click(function() {
	$('#ifm2').slideUp(400);
});

$('#vv').click(function() {
	$('#block-dr').slideToggle(500);
});

$(document).ready(function() {  
$("#form").validate({   
rules:{
                        "reg_captcha":{
                            required:true,
                            remote: {
                            type: "post",    
                            url: "include/check_captcha.php"
							}
							},
							"email":{
							required:true,
                            email:true
                        	}
							},
					
                    messages:{
                        "reg_captcha":{
                            required:"Введите код!",
                            remote: "Неверный код!"
                        },
                        "email":{
                            required:"Укажите свой E-mail",
                            email:"Не корректный E-mail"
                        }
                    },
					submitHandler: function(form){
					$(form).ajaxSubmit({
						success: function() {
							swal("Ваше сообщение успешно отправлено!");
							$('#block-captcha > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
							$(".cvalue").val("");
					} 
				}); 
			}
});
});

$('#reloadcaptcha').click(function() {
	$('#block-captcha > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
});

$(document).ready(function() {  
$('#for').validate({   
rules:{
                        "reg_captch":{
                            required:true,
                            remote: {
                            type: "post",    
                            url: "include/check_captch.php"
							}
							},
							"emai":{
							required:true,
                            email:true
                        	}
							},
					
                    messages:{
                        "reg_captch":{
                            required:"Введите код!",
                            remote: "Неверный код!"
                        },
                        "emai":{
                            required:"Укажите свой E-mail",
                            email:"Не корректный E-mail"
                        }
                    },
					submitHandler: function(form){
					$(form).ajaxSubmit({
						success: function() {
							swal("Ваше сообщение успешно отправлено!");
							$('#block-captch > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
							$(".cvalue").val("");
					} 
				}); 
			}
});
});

$('#reloadcaptch').click(function() {
	$('#block-captch > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
});


$(document).ready(function() {  
$('#for2').validate({   
rules:{
                        "reg_captc":{
                            required:true,
                            remote: {
                            type: "post",    
                            url: "include/check_captc.php"
							}
							},
							"ema":{
							required:true,
                            email:true
                        	}
							},
					
                    messages:{
                        "reg_captc":{
                            required:"Введите код!",
                            remote: "Неверный код!"
                        },
                        "ema":{
                            required:"Укажите свой E-mail",
                            email:"Не корректный E-mail"
                        }
                    },
					submitHandler: function(form){
					$(form).ajaxSubmit({
						success: function() {
							swal("Ваше сообщение успешно отправлено!");
							$('#block-captc > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
							$(".cvalue").val("");
					} 
				}); 
			}
});
});

$('#reloadcaptc').click(function() {
	$('#block-captc > img').attr("src", "include/reg_captcha.php?r=" + Math.random());
});

$('.sl').slick({
	autoplay: true,
	autoplaySpeed: 10000
});

$("#newsticker").jCarouselLite ({
	vertical: true,
	hoverPause: true,
	btnPrev: "#news-prev",
	btnNext: "#news-next",
	visible: 3,
	auto: 3000,
	speed: 500
});