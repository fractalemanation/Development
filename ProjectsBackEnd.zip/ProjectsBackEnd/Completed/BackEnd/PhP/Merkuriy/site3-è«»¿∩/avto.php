﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
</head>
<body>
<?php
include ("parts/header.php");
?>
<div id="block-body">

<div id="on-inform" style="height:612px;">

<div id="block-inform">

<h2 class="h2-titles"><div class="lang_33">Заказ автомобилей</div></h2>
<div class="h2-titles-mini"><div class="lang_34">Основные услуги</div></div>
<ul id="list-style">
<li class="list-style1"><div class="lang_35">Пригнать и растаможить автомобиль под заказ</div></li>
<li class="list-style2"><div class="lang_36">Пригнать но без растаможки автомобиля передать покупателю</div></li>
<li class="list-style3"><div class="lang_37">Пригнать новый автомобиль под заказ (растаможен/не растаможен)</div></li>
<li class="list-style4"><div class="lang_38">Покупка и продажа автомобиля не по заказу</div></li>
</ul>
<div class="h2-titles-mini"><div class="lang_39">Дополнительные услуги</div></div>
<ul id="list-style">
<li class="list-style1"><div class="lang_40">Trade-in / Выкуп – если человек хочет купить у нас авто, мы можем забрать его старый авто и с его доплатой продать ему пригнанный. Автомобили можно перекидывать перекупщикам или продавать самостоятельно</div></li>
<li class="list-style2"><div class="lang_41">Автострахование</div></li>
</ul>
<div id="header-list-cart">
<div id="head1"><div class="lang_42">Растаможка</div></div>
<div id="head2"><div class="lang_43">Новые авто из салона за границей</div></div>
<div id="head2"><div class="lang_44">Автомобили бывшие в употреблении</div></div>
</div>
<div class="block-list-cart">
<div class="header-list-carts">
<div class="head1"><div class="lang_45">С раcтаможкой</div></div>
<div class="head2"><div class="lang_46">Покупка уникальных и качественных авто по выгодным ценам. Оформление доверенности для разтаможки на покупателя после доставки из салона. Возможность продажи/возврата авто после использования.</div></div>
<div class="head2"><div class="lang_47">Покупка уникальных и качественных авто по выгодным ценам. Оформление доверенности для разтаможки на покупателя после доставки из салона. Возможность продажи/возврата авто после использования.</div></div>
</div>
<div class="header-list-carts">
<div class="head1"><div class="lang_48">Без раcтаможки</div></div>
<div class="head2"><div class="lang_49">Существенная экономия на разтаможке авто. Обязательство регулярно пересекать границу в указанные сроки. Возможность продажи/возврата авто после использования.</div></div>
<div class="head2"><div class="lang_50">Значительная экономия на разтаможке авто. Обязательство регулярно пересекать границу в сроки. Возможность продажи/возврата авто после использования.</div></div>
</div>

</div>

</div>

</div>

</div>

<?php
	include ("parts/footer.php");
?>

<script src="js/slick.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>