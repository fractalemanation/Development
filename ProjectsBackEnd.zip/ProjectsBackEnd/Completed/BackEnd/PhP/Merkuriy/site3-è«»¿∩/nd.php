﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
</head>
<body>
<?php
include ("parts/header.php");
?>
<div id="block-body">

<div id="on-inform" style="height:290px;">

<div id="block-inform">

<h2 class="h2-titles"><div class="lang_77">Необходимые документы</div></h2>
<ul id="list-style">
<div class="lang_79"><li>Загранпаспорт</li><li>Паспорт Украины</li><li>Для специалистов обязательно документы, подтверждающие квалификацию, дипломы, сертификаты, трудовая книга</li><li>Идентификационный код</li><li>Фото (3 шт.) 3,5 х 4,5 (80% лица)</li><li>Оформление документов для выезда занимает 3-4 недели!</li><li>До момента оформления документов кандидату необходимо заполнить АНКЕТУ (обязательно с фото 3 х 4 80% лица)</li></div>
</ul>

</div>

</div>

</div>

</div>

<?php
	include ("parts/footer.php");
?>

<script src="js/slick.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>