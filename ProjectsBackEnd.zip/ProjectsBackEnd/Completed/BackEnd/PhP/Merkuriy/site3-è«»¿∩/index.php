﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
</head>
<body ng-App="App" ng-controller="Ctrl">
<?php
include ("parts/header.php");
?>
<div id="block-body">

<div class="topvacancies">
	<span class="toplabel">АКТУАЛЬНЫЕ ВАКАНСИИ</span>
</div>
<div class="box">
	<div class="thumbbox">
		<a href="construction">
			<img src="images/thumbnails/01.jpg" class="thumbnail">
			<span class="thumblabel">Стройка</span>
		</a>
	</div>
	<div class="thumbbox">
		<a href="drivers">
			<img src="images/thumbnails/02.jpg" class="thumbnail">
			<span class="thumblabel">Транспорт, логистика</span>
		</a>
	</div>
	<div class="thumbbox">
		<a href="electrician/electrician.php">
			<img src="images/thumbnails/51.jpg" class="thumbnail">
			<span class="thumblabel">Электрик</span>
		</a>
	</div>
</div>
<div class="box">
	<div class="thumbbox">
		<a href="metallurgist">
			<img src="images/thumbnails/68.jpg" class="thumbnail">
			<span class="thumblabel">Металлург</span>
		</a>
	</div>
	<div class="thumbbox">
		<a href="locksmith_carpenter">
			<img src="images/thumbnails/69.jpg" class="thumbnail">
			<span class="thumblabel">Плотник/Слесарь</span>
		</a>
	</div>
	<div class="thumbbox">
		<a href="general_worker">
			<img src="images/thumbnails/04.jpg" class="thumbnail">
			<span class="thumblabel">Разнорабочий</span>
		</a>
	</div>
</div>
<div class="box">
	<div class="thumbbox">
		<a href="office_work">
			<img src="images/thumbnails/70.jpg" class="thumbnail">
			<span class="thumblabel">Работа в офисе</span>
		</a>
	</div>
	<div class="thumbbox">
		<a href="rab.php?page=3#v97">
			<img src="images/thumbnails/05.jpg" class="thumbnail">
			<span class="thumblabel">Отели</span>
		</a>
	</div>
	<div class="thumbbox">
		<a href="farm">
			<img src="images/thumbnails/06.jpg" class="thumbnail">
			<span class="thumblabel">Ферма</span>
		</a>
	</div>
</div>

<div id="tov">

<h2 class="tov"><div class="lang_16">Список новостей нашей компании</div>
</h2>
<div id="block-news">
<center><div id="news-prev"></div></center>
<div id="newsticker">
<ul>
<?php
define('kop', true);
include('include/db_connect.php');
$result = mysql_query("SELECT * FROM news ORDER BY id DESC", $link);
if (mysql_num_rows($result) > 0) {
	$row = mysql_fetch_array($result);	
do {
	echo '
	<li>
	<img src="images/'.$row[image].'" />
	<a href="">'.$row[title].'</a>
	<p>'.$row[text].'</p>
	<span>'.$row[date].'</span>
	</li>
	';
}while ($row = mysql_fetch_array($result));
}
?>
</ul>
</div>
<center><div id="news-next"></div></center>
</div>

<div id="block-news2">
<center><div id="news-prev2"></div></center>
<div id="newsticker2">
<ul>
<?php
define('kop', true);
include('include/db_connect.php');
$result = mysql_query("SELECT * FROM news ORDER BY id DESC", $link);
if (mysql_num_rows($result) > 0) {
	$row = mysql_fetch_array($result);	
do {
	echo '
	<li>
	<img src="images/'.$row[image].'" />
	<a href="">'.$row[title_pol].'</a>
	<p>'.$row[text_pol].'</p>
	<span>'.$row[date].'</span>
	</li>
	';
}while ($row = mysql_fetch_array($result));
}
?>
</ul>
</div>
<center><div id="news-next2"></div></center>
</div>

<div id="block-news3">
<center><div id="news-prev3"></div></center>
<div id="newsticker3">
<ul>
<?php
define('kop', true);
include('include/db_connect.php');
$result = mysql_query("SELECT * FROM news ORDER BY id DESC", $link);
if (mysql_num_rows($result) > 0) {
	$row = mysql_fetch_array($result);	
do {
	echo '
	<li>
	<img src="images/'.$row[image].'" />
	<a href="">'.$row[title_eng].'</a>
	<p>'.$row[text_eng].'</p>
	<span>'.$row[date].'</span>
	</li>
	';
}while ($row = mysql_fetch_array($result));
}
?>
</ul>
</div>
<center><div id="news-next3"></div></center>
</div>

<div id="block-news4">
<center><div id="news-prev4"></div></center>
<div id="newsticker4">
<ul>
<?php
define('kop', true);
include('include/db_connect.php');
$result = mysql_query("SELECT * FROM news ORDER BY id DESC", $link);
if (mysql_num_rows($result) > 0) {
	$row = mysql_fetch_array($result);	
do {
	echo '
	<li>
	<img src="images/'.$row[image].'" />
	<a href="">'.$row[title_esp].'</a>
	<p>'.$row[text_esp].'</p>
	<span>'.$row[date].'</span>
	</li>
	';
}while ($row = mysql_fetch_array($result));
}
?>
</ul>
</div>
<center><div id="news-next4"></div></center>
</div>

<div id="block-news5">
<center><div id="news-prev5"></div></center>
<div id="newsticker5">
<ul>
<?php
define('kop', true);
include('include/db_connect.php');
$result = mysql_query("SELECT * FROM news ORDER BY id DESC", $link);
if (mysql_num_rows($result) > 0) {
	$row = mysql_fetch_array($result);	
do {
	echo '
	<li>
	<img src="images/'.$row[image].'" />
	<a href="">'.$row[title_fran].'</a>
	<p>'.$row[text_fran].'</p>
	<span>'.$row[date].'</span>
	</li>
	';
}while ($row = mysql_fetch_array($result));
}
?>
</ul>
</div>
<center><div id="news-next5"></div></center>
</div>

</div>

<div id="imgot"></div>
</div>

<?php
	include ("parts/footer.php");
?>

<script src="js/slick.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>