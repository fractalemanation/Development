﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
<link rel="stylesheet" type="text/css" href="/css/reset.css" />
<link rel="stylesheet" type="text/css" href="/css/style.css" />
<link rel="stylesheet" href="/css/slick.css" />
<link rel="stylesheet" href="/css/slick-theme.css" />
<link rel="stylesheet" href="/css/sweetalert.css" />

<script src="/js/jquery-2.2.4.js"></script>
<script src="/js/jquery-1.8.2.min.js"></script>
<script src="/js/jquery.validate.js"></script>
<script src="/js/jquery.cookie.min.js"></script>
<script src="/js/slick.min.js"></script>
<script src="/js/sweetalert.min.js"></script>
<script src="/js/jquery.form.js"></script>
<script src="/js/TextChange.js"></script>
<script src="/js/jcarousellite_1.0.1.js"></script>
<script src="/js/script.js"></script>
<link rel="shortcut icon" type="image/x-icon" href="/images/logo.png">
<link rel="stylesheet" href="/font-awesome-4.7.0/css/font-awesome.min.css">
</head>

<body>
<div id="header">
		<div class="topmenu-wrapper">
			<div class="box logo">
			    <img src="/images/header_logo.png" style="width: auto; height: 100%"></img>
			</div>
			<div class="box center">
				<nav>
				<ul class="topmenu">
					<li><a href="/index.php" id="lang_1">Главная</a></li>
					<li><a href="#" class="submenu-link" id="lang_86">Трудоустройство</a>
						<ul class="submenu">
							<li><a href="/rab.php"><div class="lang_87">Вакансии</div></a></li>
							<li><a href="/sp.php"><div class="lang_76">Стоимость программы</div></a></li>
							<li><a href="/nd.php"><div class="lang_77">Необходимые документы</div></a></li>
							<li><a href="/pro.php"><div class="lang_78">Процедура оформления</div></a></li>
						</ul>
					</li>
					<li><a href="/vis.php" id="lang_53">Визы</a></li>
					<li><a href="http://www.kyivre.com/" target="_blank" id="lang_88">Страхование</a></li>
					<li><a href="#" class="submenu-link" id="lang_89">О нас</a>
						<ul class="submenu">
							<li><a href="/our.php"><div class="lang_89">О нас</div></a></li>
							<li><a href="/rev.php"><div class="lang_90">Отзывы</div></a></li>
							<li><a href="/feedback.php"><div class="lang_11">Контакты</div></a></li>
						</ul>
					</li>
					<li><a href="#" class="submenu-link" id="lang_91">Разное</a>
						<ul class="submenu">
							<li><a href="/po.php"><div class="lang_32">Программное обеспечение</div></a></li>
							<li><a href="/avto.php"><div class="lang_33">Заказ автомобилей</div></a></li>
							<li><a href="/blf.php"><div class="lang_58">Благотворительные фонды</div></a></li>
						</ul>
					</li>
				</ul>
				</nav>
			</div>
			<div class="box left">
				<a class="button" id="vv" rel="alternate"><span id="lang_99">Заявка</span></a>
				<select name="lang" id="lang">
				<option value="1" selected="selected">Русский</option>
				<option value="2">Polski</option>
				<option value="3">English</option>
				<option value="4">Español</option>
				<option value="5">Français</option>
			</select>
			</div>
		</div>
	</div>
	<div id="ifm1">
		<a class="hide"><img
			src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png"
			id="del1" /></a>
		<iframe id="iframem"
			src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2541.0743921724415!2d30.52062895097995!3d50.43971497937319!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40d4ceffb42714d5%3A0x594f58265e7d4158!2z0LLRg9C70LjRhtGPINCR0LDRgdC10LnQvdCwLCAxMiwg0JrQuNGX0LI!5e0!3m2!1sru!2sua!4v1487706875114"
			width="800" height="500" frameborder="0" style="border: 0"
			allowfullscreen></iframe>
	</div>

	<div id="ifm2">
		<a class="hide"><img
			src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png"
			id="del2" /></a>
		<iframe
			src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d8667.993672601573!2d23.4609060352321!3d51.13341006114667!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47239a4e912c3263%3A0xe24105ac8c241087!2zTHViZWxza2EgNTIsIENoZcWCbSwg0J_QvtC70YzRiNCw!5e0!3m2!1sru!2sua!4v1485418464097"
			width="800" height="500" frameborder="0" style="border: 0"
			allowfullscreen></iframe>
	</div>

	<div id="block-dr">
		<a class="hide-dr"><img
			src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png"
			id="deletedr" /></a>
		<h2 class="h2-title"><div class="lang_95">Форма Резюме</div></h2>
		<form id="for" method="post" action="include/send.php">
			<p id="reg_message"></p>
			<ul id="feedback">
				
			<li><input type="text" name="fio" placeholder="Ваше Имя" required />
			<input class="lang_104" type="text" name="city" placeholder="Город, Область" required /></li>
				
			<li><select  required name="age" id="age">
						<option value=""><div class="lang_97">Выбрать Возраст</div></option>
						<option value="16">До 16</option>
						<option value="16-18">16-18</option>
						<option value="18-20">18-20</option>
						<option value="20-25">20-25</option>
						<option value="25-40">25-40</option>
						<option value="40-50">40-50</option>
						<option value="50-55">50-55</option>
						<option value="55">55 и более</option>
			</select>
			<select  required name="vacancy" id="vacancy">
						<option value=""><div class="lang_97">Выбрать Вакансию</div></option>
<?php
define ( 'kop', true );
include ('include/db_connect.php');

$result = mysql_query ( "SELECT * FROM vacancies ORDER BY title ASC", $link );
if (mysql_num_rows ( $result ) > 0) {
	$row = mysql_fetch_array ( $result );
	do {
		echo '<option value="'.$row [id].'">'.$row [title].'</option>';
	} while ( $row = mysql_fetch_array ( $result ) );
}
?>
			</select>				
			</li>
				<div class="lang_102" id="radio">Наличие загран паспорта</div>
				<div>
					<input type="radio" name="passport" id="R1" value="да" required><label for="R1"><div class="lang_100" id="answer1">Да</label></div></div> 
				<div>
					<input type="radio" name="passport" id="R2" value="нет"><label for="R2"><div class="lang_101" id="answer2">Нет</label></div></div><br><br>
				<div class="lang_103" id="radio">Есть ли открытая виза</div>
				<div>
					<input type="radio" name="visa" id="R3" value="да" required><label for="R3"><div class="lang_100" id="answer1">Да</label></div></div> 
				<div>
					<input type="radio" name="visa" id="R4" value="нет"><label for="R4"><div class="lang_101" id="answer2">Нет</label></div></div> <br><br>  
			<li><select  required name="language" id="language">
						<option value="" class="lang_105">Знание польского языка</option>
						<option value="1" class="lang_106">не понимаю по польски</option>
						<option value="2" class="lang_107">понимаю много польских слов</option>
						<option value="3" class="lang_108">немного говорю по польски</option>
						<option value="4" class="lang_109">говорю по польски хорошо</option>
			</select>
				<input type="text" name="phon"	placeholder="Ваш Телефон" required />
			</li>
			<li>
				<input type="text" name="emai" id="mail" placeholder="E-mail" required />
			</li>
				<textarea name="text" placeholder="Пожелания" cols="34" rows="10"></textarea></li>
			<li>
					<div id="block-captch">
						<img src="/include/reg_captcha.php" /> <input type="text"
							name="reg_captch" id="reg_captcha" class="cvalue" />
						<p id="reloadcaptch" class="lang_75">Обновить</p>
					</div>
				</li>
			</ul>
			<input type="submit" name="send_message" id="submit" />
		</form>
	</div>
<div id="block-body">

<div class="box2">
	<div class="thumbbox"><img src="/images/thumbnails/84.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="/images/thumbnails/85.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="/images/thumbnails/86.jpg" class="thumbnail">
	</div>
</div>

<div id="on-inform" style="height:2100px;">

<div id="block-inform">

<h2 class="h2-titles"><div class="lang_">Слесарь</div></h2>
<div class="textons"><p align="justify"><h3>Слесарь (г. Люблин, Польша)</h3>
<p align="justify"><b>Ваши задачи и обязанности:</b> 
<br />- Работа (5-6 дней в неделю, 10-12 часов в день)
<br />- Умение пользоваться болгаркой 
<br />- Зачищать, шлифовать, обрезать болгаркой
<br />- Знание и чтение  технического  рисунка <b>(обязательно)</b>
<br />
<p align="justify"><a href="/feedback.php" style="color: green"><b>Нажмите чтобы узнать контактную информацию</a></b><br /> 
<br /><b>Ваши навыки и опыт:</b>
<br />- Более важен опыт, чем образование (иметь  опыт работы  на стройке  в данной сфере <b>обязательно</b>).
<br />- Знание польского языка <b>обязательно</b>, для понимания  выполнения задач.
<br />
<p align="justify"><b>Зарплата:</b>
<br />16 злотых в час (<b>Нетто</b>)
<br />Выплата «ЗП» выполняется с 10 по 15 число каждого месяца после закрытия актов выполненных работ .
<br />
<br /><b>Требования:</b>
<br />- Самодисциплина, мотивация к работе.
<br />- Добросовестное выполнение своих обязанностей.
<br />- Без вредных привычек
<br />- Необходима справка от врача <b>«психолога» и санитарная книжка</b> (о состояния здоровья) можно приезжать со справкой выданной  на  Украине.
<br />- Мужчины умеющие работать руками
<br />- Крепкое здоровье
<br />
<br /><b>Мы Вам предлагаем:
<br />Проживание:</b>  бесплатное  (за счет работодателя)  «снимаются квартиры для жилья»  фотографии жилья  будут доступны.
<br />Стабильную работу на основе трудового договора + бонусы в зависимости от результатов
<br />Необходимые инструменты для работы
<br />Возможность личного  и профессионального развития
<br />Страховку, больничные 
<br />Легальное трудоустройство 
<br />Новоприбывших встречают на вокзале, связь при пересечении границы  с менеджером  «Merkury Polska», который  будет вас сопровождать до места работы.
<br />
<br /><b>Проживание:</b>

</div>
<div style="height:10px;">
</div>
<div class="box2">
	<div class="thumbbox"><img src="/images/thumbnails/73.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="/images/thumbnails/74.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="/images/thumbnails/75.jpg" class="thumbnail">
	</div>
	
</div>
<div class="box2">
	<div class="thumbbox"><img src="/images/thumbnails/76.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="/images/thumbnails/77.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="/images/thumbnails/78.jpg" class="thumbnail">
	</div>
	
</div>
<div class="box2">
	<div class="thumbbox"><img src="/images/thumbnails/79.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="/images/thumbnails/80.jpg" class="thumbnail">
	</div>
	<div class="thumbbox"><img src="/images/thumbnails/81.jpg" class="thumbnail">
	</div>
</div>
<div class="box2">
	<div class="thumbbox"><img src="/images/thumbnails/82.jpg" class="thumbnail">
	</div>
</div>
</div>
</div>

<div id="footer">
	<div id="footer_center">
		<a href="/index.php"><img src="/images/header_logo.png" id="img_footer" /></a>
		<div id="footer-phone">
			<h4>	
				<div class="lang_27">Телефоны</div>
			</h4>
			<h3>+38068 324 66 25</h3>
			<h3>+38099 324 66 25</h3>
			<h3>+48 574 746 394</h3>
			<p class="lang_28">Пн. - Пт. 9:00-19:00</p>
		</div>
		<div id="mnnn">
			<h3 id="mnn">
				<div class="lang_11">Контакты</div>
			</h3>
			<p id="mn">
				Lubelska 52 <br />Chelm, Poland<br />wejście w łuk<br />piętro 3<br />
				<font class="geol">Геолокация</font>
			</p>
		</div>
		<div id="mnnn">
			<h3 id="mnn">
				<div class="lang_11">Контакты</div>
			</h3>
			<p id="mn">
				ул. Бассейная 12 <br />Киев <br />Украина <br /><br />
				<font class="geolm">Геолокация</font>
			</p>
		</div>
		<div id="nav_footer">
			<h3 id="nav_footer_title">
				<div class="lang_0">Навигация</div>
			</h3>
			<ul id="nav_footer_ul">
				<a href="/vis.php" class="footer_a"><li class="footer_li"><div
							class="lang_53">Визы</div></li></a>
				<a href="/rab.php" class="footer_a"><li class="footer_li"><div
							class="lang_70">Работа в Польше</div></li></a>
				<a href="http://www.kyivre.com/" target="_blank" class="footer_a"><li
					class="footer_li"><div class="lang_88">Страхование</div></li></a>
				<a href="/avto.php" class="footer_a"><li class="footer_li"><div
							class="lang_3">Заказ Автомобилей</div></li></a>
				<a href="/po.php" class="footer_a"><li class="footer_li"><div
							class="lang_2">Програмное Обеспечение</div></li></a>
				<a href="/feedback.php" class="footer_a"><li class="footer_li"><div
							class="lang_11">Контакты</div></li></a>
			</ul>
		</div>
		<div id="ss">
			<h3 id="title_ss">
				<div class="lang_30">Социальные сети</div>
			</h3>
			<div id="sss">
				<a href="https://vk.com/merkurypoland" target="_blank"><img
					src="/images/vk.png" class="img_ss" /></a> <a
					href="https://www.facebook.com/%D0%9B%D0%B5%D0%B3%D0%B0%D0%BB%D1%8C%D0%BD%D0%B0%D1%8F-%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0-%D0%B2-%D0%9F%D0%BE%D0%BB%D1%8C%D1%88%D0%B5-%D0%B2%D0%B8%D0%B7%D1%8B%D1%81%D1%82%D1%80%D0%B0%D1%85%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5-598380013705992/"
					target="_blank"><img src="/images/facebook.png" class="img_ss" /></a>
				<a href="https://twitter.com/Merkurij2016" target="_blank"><img
					src="/images/twitter.png" class="img_ss" /></a>
			</div>
			<div id="ros">
				<h3 id="title_ros">
					<div class="lang_31">Рассказать о сайте</div>
				</h3>
				<script src="//yastatic.net/es5-shims/0.0.2/es5-shims.min.js"></script>
				<script src="//yastatic.net/share2/share.js"></script>
				<div class="ya-share2" data-services="vkontakte,facebook,odnoklassniki,moimir,gplus,twitter,skype"></div>
			</div>
		</div>
	</div>
</div>
<div id="mc">Merkury Polska © 2015-2017</div>

<script src="/js/script.js"></script>
</body>
</html>

