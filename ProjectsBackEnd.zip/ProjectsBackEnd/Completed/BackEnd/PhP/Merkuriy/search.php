﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
<link href="css/reset.css" rel="stylesheet" type="text/css" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/slick.css" />
<link rel="stylesheet" href="css/slick-theme.css" />
<link rel="stylesheet" href="css/sweetalert.css" />
<script src="js/jquery-2.2.4.js"></script>
<script src="js/jquery-1.8.2.min.js"></script>
<script src="js/jquery.cookie.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/jcarousellite_1.0.1.js"></script>
<script src="js/jquery.form.js"></script>
<script src="js/jquery.validate.js"></script>
<script src="js/sweetalert.min.js"></script>
<script src="js/script.js"></script>
<script>
$(document).ready(function() {
    $('#rol').scrollTop(555);
});

window.onload = function() {
	window.scrollTo(0, 555);
}
</script>
<link rel="shortcut icon" type="image/x-icon" href="images/logo.png">
</head>
<body id="rol">

<div id="ifm1">
<a class="hide"><img src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png" id="del1" /></a>
<iframe id="iframem" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d317.6293282222681!2d30.6288265!3d50.4404557!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40d4c544852b445d%3A0x542edbec15f97f96!2z0KXQsNGA0LrRltCy0YHRjNC60LUg0YjQvtGB0LUsIDEsINCa0LjRl9Cy!5e0!3m2!1sru!2sua!4v1484583981914" width="800" height="500" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>

<div id="ifm2">
<a class="hide"><img src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png" id="del2" /></a>
<iframe id="iframe" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2503.957370594396!2d23.467716315292773!3d51.12769434621579!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47239a4d55b76421%3A0x309d0334a226ed9b!2zTHdvd3NrYSA1MSwgQ2hlxYJtLCDQn9C-0LvRjNGI0LA!5e0!3m2!1sru!2sru!4v1465999567612" width="800" height="500" frameborder="0" style="border: 0" title="Lwowska 51, Chelm, Poland, office 406" allowfullscreen></iframe>
</div>

<div id="navig">

<a class="hide"><img src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png" id="delete" /></a>
<h2 id="title_nav"><div class="lang_0">Навигация</div></h2>
<ul id="ul_nav">
<a href="index.php" class="li_a"><li class="li_nav"><div class="lang_1">Главная</div></li></a>
<a href="po.php" class="li_a"><li class="li_nav"><div class="lang_2">Програмное Обеспечение</div></li></a>
<a href="avto.php" class="li_a"><li class="li_nav"><div class="lang_3">Продажа Автомобилей</div></li></a>
<a href="vis.php" class="li_a"><li class="li_nav"><div class="lang_4">Польские Визы</div></li></a>
<a href="rab.php" class="li_a"><li class="li_nav"><div class="lang_70">Работа в Польше</div></li></a>
<a href="blf.php" class="li_a"><li class="li_nav"><div class="lang_5">Благотворительный Фонд</div></li></a>
<a href="feedback.php" class="li_a"><li class="li_nav"><div class="lang_6">Связь</div></li></a>
</ul>

</div>

<div id="block-body">

<div id="block-dr">
<a class="hide-dr"><img src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png" id="deletedr" /></a>
<h2 class="h2-title">Форма Резюме</h2>
<form id="for" method="post" action="include/send.php">
<p id="reg_message"></p>
<ul id="feedback">
<li><label>ФИО</label><input type="text" name="fio" placeholder="FIO" required /></li>
<li><label>Ваш E-mail</label><input type="text" name="emai" placeholder="E-mail" required /></li>
<li><label>Ваш Телефон</label><input type="text" name="phon" placeholder="Phone" required /></li>
<li><label>Вакансия</label>
<select name="vacancy" id="vacancy">
<?php
define('kop', true);
include('include/db_connect.php');

$result = mysql_query("SELECT * FROM vacancies ORDER BY title ASC", $link);
if (mysql_num_rows($result) > 0) {
	$row = mysql_fetch_array($result);	
do {

echo '<option value="'.$row[id].'">'.$row[title].'</option>';
}while ($row = mysql_fetch_array($result));
}
?>
</select>
</li>
<li><label>Пожелания</label><textarea name="text" placeholder="Message text" cols="34" rows="10"></textarea></li>
<li>
<div id="block-captch">
<img src="include/reg_captcha.php" />
<input type="text" name="reg_captch" id="reg_captcha" class="cvalue" />
<p id="reloadcaptch" class="lang_75">Обновить</p>
</div>
</li>
</ul>
<input type="submit" name="send_message" id="form_submit" />
</form>
</div>

<div class="main">
<a href="index.php"><img src="images/logo.png" class="imgsl" /></a>
<a class="show"><img src="images/img_nav.png" class="img_nav" /></a>
<a class="shide"><img src="images/img_nav.png" class="img_navhov" /></a>
<h3 class="ntsl1">+380 63 7497525<br />+380 0681747031<br />+48 666 911168</h3>
<select name="lang" class="lang">
<option value="1" selected="selected">Русский</option>
<option value="2">Polski</option>
<option value="3">English</option>
<option value="4">Español</option>
<option value="5">Français</option>
</select>
<h3 class="ntsl2">+380 97 7375547<br />+380 66 3693504<br />+48 666 911168</h3>
 <div class="sl">
  <div class="sl__slide">
  <img src="images/fpol.jpg" alt="Картинка слайда 1" class="sl__img" />
  </div>
  
  <div class="sl__slide">
  <img src="images/fukr.jpg" alt="Картинка слайда 2" class="sl__img" />
  </div>
  
  <div class="sl__slide">
  <img src="images/fshen.jpg" alt="Картинка слайда 3" class="sl__img" />
  </div>
 </div>
</div>

<div id="on-inform" style="height:11053px;">

<div id="block-inform">

<div id="nav-inform">
<a href="po.php" class="nav1"><img src="images/mpo.png" class="nav_img" /><div class="nav1_text"><div class="lang_7">ПО</div></div></a>
<a href="avto.php" class="nav2"><img src="images/mavto.png" class="nav_img" /><div class="nav2_text"><div class="lang_8">Авто</div></div></a>
<a href="vis.php" class="nav3"><img src="images/mvisa.png" class="nav_img" /><div class="nav3_text"><div class="lang_9">Визы</div></div></a>
<a href="rab.php" style="width:100px;height:auto;float:left;margin-right:1px;background-color:#FFF;cursor:pointer;padding-bottom:0;border-bottom:10px solid #187862;box-shadow:1px -1px 3px #CCC,-1px -1px 3px #CCC;"><img src="images/mrab.png" style="padding-bottom:10px;width:60px;height:60px;padding:20px;transform:translateY(-10px);" /><div style="font:16px sans-serif;text-align:center;color:#187862;transform:translateY(-10px);"><div class="lang_74">Работа</div></div></a>
<a href="blf.php" class="nav4"><img src="images/mbf.png" class="nav_img" /><div class="nav4_text"><div class="lang_10">БФ</div></div></a>
<a href="feedback.php" class="nav5"><img src="images/msv.png" class="nav_img" /><div class="nav5_text"><div class="lang_11">Связь</div></div></a>
</div>



<h2 class="h2-titless"><div class="lang_70">Работа в Польше</div></h2>
<div id="brp">
<div id="srp">

<ul class="filter-ul">
<li><a id="block-sort-name"><?php
include("include/db_connect.php");
$sorting = $_GET["sort"];
switch ($sorting) {
	case 'gold-asc';
	$sorting = 'gold ASC';
	$sort_name = 'Маленькие зарплаты ∨';
	$sortings = 'sort=gold-asc';
	break;
	case 'gold-desc';
	$sorting = 'gold DESC';
	$sort_name = 'Большие зарплаты ∨';
	$sortings = 'sort=gold-desc';
	break;
	case 'title';
	$sorting = 'title ASC';
	$sort_name = 'По алфавиту ∨';
	$sortings = 'sort=title';
	break;
	case 'news';
	$sorting = 'id DESC';
	$sort_name = 'По дате обновления ∨';
	$sortings = 'sort=news';
	break;
	case 'male';
	$sorting = "sort_sex = '1' DESC";
	$sort_name = 'Мужчины ∨';
	$sortings = 'sort=male';
	break;
	case 'female';
	$sorting = "sort_sex = '2' DESC";
	$sort_name = 'Женщины ∨';
	$sortings = 'sort=female';
	break;
	case 'age';
	$sorting = "age DESC";
	$sort_name = 'Возраст ∨';
	$sortings = 'sort=age';
	break;
	case 'exp';
	$sorting = "exp DESC";
	$sort_name = 'Возраст ∨';
	$sortings = 'sort=exp';
	break;
	default:
	$sorting = 'id DESC';
	$sort_name = 'Сортировка ∨';
	$sortings = 'q='.$search = $_GET["q"];
	break;
}
echo $sort_name;
?>
</a>
<ul id="block-sort-ul">
<li><a href="search.php?sort=title">По алфавиту</a></li>
<li><a href="search.php?sort=news">По дате обновления</a></li>
<li><a href="search.php?sort=gold-asc">Маленькие зарплаты</a></li>
<li><a href="search.php?sort=gold-desc">Большие зарплаты</a></li>
<li><a href="search.php?sort=male">Мужчины</a></li>
<li><a href="search.php?sort=female">Женщины</a></li>
<li><a href="search.php?sort=age">Возраст</a></li>
<li><a href="search.php?sort=exp">Опыт работы</a></li>
</ul>
</li>
</ul>

</div>
<div class="lines"></div>
<div id="srp">

<div id="block-paramater"> 
<form method="GET" action="search.php?q="> 

<ul class="filter-ul">
<li><a id="block-filter-name1"><?php
$filter_1 = $_GET["filter_1"];
switch ($filter_1) {
	case '1500';
	$filter_1 = "AND gold_filter = '1'";
	$filter_name = '1500 ∨';
	$sortings = 'filter_1=1500';
	break;
	case '1500-2000';
	$filter_1 = "AND gold_filter = '2'";
	$filter_name = '1500-2000 ∨';
	$sortings = 'filter_1=1500-2000';
	break;
	case '2000-2500';
	$filter_1 = "AND gold_filter = '3'";
	$filter_name = '2000-2500 ∨';
	$sortings = 'filter_1=2000-2500';
	break;
	case '2500-3000';
	$filter_1 = "AND gold_filter = '4'";
	$filter_name = '2500-3000 ∨';
	$sortings = 'filter_1=2500-3000';
	break;
	case '3000-4000';
	$filter_1 = "AND gold_filter = '5'";
	$filter_name = '3000-4000 ∨';
	$sortings = 'filter_1=3000-4000';
	break;
	case '4000-5000';
	$filter_1 = "AND gold_filter = '6'";
	$filter_name = '4000-5000 ∨';
	$sortings = 'filter_1=4000-5000';
	break;
	case '5000-7000';
	$filter_1 = "AND gold_filter = '7'";
	$filter_name = '5000-7000 ∨';
	$sortings = 'filter_1=5000-7000';
	break;
	case '7000-10000';
	$filter_1 = "AND gold_filter = '8'";
	$filter_name = '7000-10000 ∨';
	$sortings = 'filter_1=7000-10000';
	break;
	case '10000-15000';
	$filter_1 = "AND gold_filter = '9'";
	$filter_name = '10000-15000 ∨';
	$sortings = 'filter_1=10000-15000';
	break;
	case '15000';
	$filter_1 = "AND gold_filter = '10'";
	$filter_name = 'Более 15000 ∨';
	$sortings = 'filter_1=15000';
	break;
	default:
	$filter_1 = '';
	$filter_name = 'Зарплата ∨';
	break;
}
echo $filter_name;
?></a>
<ul id="block-filter-ul1">
<li><a href="search.php?filter_1=1500">1500PLN</a></li>
<li><a href="search.php?filter_1=1500-2000">1500-2000PLN</a></li>
<li><a href="search.php?filter_1=2000-2500">2000-2500PLN</a></li>
<li><a href="search.php?filter_1=2500-3000">2500-3000PLN</a></li>
<li><a href="search.php?filter_1=3000-4000">3000-4000PLN</a></li>
<li><a href="search.php?filter_1=4000-5000">4000-5000PLN</a></li>
<li><a href="search.php?filter_1=5000-7000">5000-7000PLN</a></li>
<li><a href="search.php?filter_1=7000-10000">7000-10000PLN</a></li>
<li><a href="search.php?filter_1=10000-15000">10000-15000PLN</a></li>
<li><a href="search.php?filter_1=15000">Более 15000PLN</a></li>
</ul>
</li>
</ul>

<ul class="filter-ul">
<li><a id="block-filter-name"><?php
$filter_2 = $_GET["filter_2"];
switch ($filter_2) {
	case 'day';
	$filter_2 = "AND date = 'day'";
	$filter_name = '1 день ∨';
	$sortings = 'filter_2=day';
	break;
	case 'week';
	$filter_2 = "AND date = 'week'";
	$filter_name = '1 неделя ∨';
	$sortings = 'filter_2=week';
	break;
	case 'weekend';
	$filter_2 = "AND date = 'weekend'";
	$filter_name = '2 недели ∨';
	$sortings = 'filter_2=weekend';
	break;
	case 'month';
	$filter_2 = "AND date = 'month'";
	$filter_name = '1 месяц ∨';
	$sortings = 'filter_2=month';
	break;
	case 'monthed';
	$filter_2 = "AND date = 'monthed'";
	$filter_name = '3 месяцa ∨';
	$sortings = 'filter_2=monthed';
	break;
	case 'monthend';
	$filter_2 = "AND date = 'monthend'";
	$filter_name = 'Более 3-х месяцев ∨';
	$sortings = 'filter_2=monthend';
	break;
	default:
	$filter_2 = '';
	$filter_name = 'Дата обновления ∨';
	break;
}
echo $filter_name;
?></a>
<ul id="block-filter-ul">
<li><a href="search.php?filter_2=day">1 день</a></li>
<li><a href="search.php?filter_2=week">1 неделя</a></li>
<li><a href="search.php?filter_2=weekend">2 недели</a></li>
<li><a href="search.php?filter_2=month">1 месяц</a></li>
<li><a href="search.php?filter_2=monthed">3 месяца</a></li>
<li><a href="search.php?filter_2=monthend">Более 3-х месяцев</a></li>
</ul>
</li>
</ul>

<ul class="filter-ul">
<li><a id="block-filter-name_2"><?php
$filter_3 = $_GET["filter_3"];
switch ($filter_3) {
	case 'male';
	$filter_3 = "AND sort_sex = '1'";
	$filter_name = 'Мужчины ∨';
	$sortings = 'filter_3=male';
	break;
	case 'female';
	$filter_3 = "AND sort_sex = '2'";
	$filter_name = 'Женщины ∨';
	$sortings = 'filter_3=female';
	break;
	case 'femamale';
	$filter_3 = "AND sort_sex = '3'";
	$filter_name = 'Муж. и Жен. ∨';
	$sortings = 'filter_3=femamale';
	break;
	case 'family';
	$filter_3 = "AND sort_sex = '4'";
	$filter_name = 'Семейные пары ∨';
	$sortings = 'filter_3=family';
	break;
	case 'other';
	$filter_3 = "AND sort_sex = '5'";
	$filter_name = 'Другие варианты ∨';
	$sortings = 'filter_3=other';
	break;
	default:
	$filter_3 = '';
	$filter_name = 'Пол ∨';
	break;
}
echo $filter_name;
?></a>
<ul id="block-filter-ul_2">
<li><a href="search.php?filter_3=male">Мужчины</a></li>
<li><a href="search.php?filter_3=female">Женщины</a></li>
<li><a href="search.php?filter_3=femamale">Муж. и Жен.</a></li>
<li><a href="search.php?filter_3=family">Семейные пары</a></li>
<li><a href="search.php?filter_3=other">Другие варианты</a></li>
</ul>
</li>
</ul>

<ul class="filter-ul">
<li><a id="block-filter-name_3"><?php
$filter_4 = $_GET["filter_4"];
switch ($filter_4) {
	case '20';
	$filter_4 = "AND age_filter = '1'";
	$filter_name = 'До 20-ти ∨';
	$sortings = 'filter_4=20';
	break;
	case '20-40';
	$filter_4 = "AND age_filter = '2'";
	$filter_name = '20-40 ∨';
	$sortings = 'filter_4=20-40';
	break;
	case '40-50';
	$filter_4 = "AND age_filter = '3'";
	$filter_name = '40-50 ∨';
	$sortings = 'filter_4=40-50';
	break;
	case 'age';
	$filter_4 = "AND age_filter = '4'";
	$filter_name = 'Не указан ∨';
	$sortings = 'filter_4=age';
	break;
	default:
	$filter_4 = '';
	$filter_name = 'Возраст ∨';
	break;
}
echo $filter_name;
?></a>
<ul id="block-filter-ul_3">
<li><a href="search.php?filter_4=20">До 20-ти</a></li>
<li><a href="search.php?filter_4=20-40">20-40</a></li>
<li><a href="search.php?filter_4=40-50">40-50</a></li>
<li><a href="search.php?filter_4=age">Не указан</a></li>
</ul>
</li>
</ul>

<ul class="filter-ul">
<li><a id="block-filter-name_4"><?php
$filter_5 = $_GET["filter_5"];
switch ($filter_5) {
	case 'wexp';
	$filter_5 = "AND exp_filter = '1'";
	$filter_name = 'С опытом ∨';
	$sortings = 'filter_5=wexp';
	break;
	case 'oexp';
	$filter_5 = "AND exp_filter = '2'";
	$filter_name = 'Без опыта ∨';
	$sortings = 'filter_5=oexp';
	break;
	default:
	$filter_5 = '';
	$filter_name = 'Опыт ∨';
	break;
}
echo $filter_name;
?></a>
<ul id="block-filter-ul_4">
<li><a href="search.php?filter_5=wexp">С опытом</a></li>
<li><a href="search.php?filter_5=oexp">Без опыта</a></li>
</ul>
</li>
</ul>

<ul class="filter_ul">
<input type="text" id="input-search" name="q" placeholder="Название профессии" autocomplete="off" value="<?php echo $search = $_GET["q"];?>" />
<ul id="result-search">
</ul>
</ul>
<center><input type="submit" id="search" value="Фильтры" /></center> 
</form>
</div>

</div>

<div id="drp">
<div id="zarp" class="lang_71">Изображение</div>
<div id="opis" class="lang_72">Описание</div>
<div id="zarp" class="lang_73">Зарплата</div>
</div>
</div>

<div id="workpol">
<?php
define('kop', true);
include('include/db_connect.php');

$search = $_GET["q"];

function uan ($first) {
	$second = 6.76;
	$summa = $first * $second;
	return $summa;
}
function usd ($first) {
	$second = 4.09;
	$summa = $first / $second;
	return $summa;
}
function eur ($first) {
	$second = 4.37;
	$summa = $first / $second;
	return $summa;
}


$num = 40;
$page = (int)$_GET['page'];
$count = mysql_query("SELECT COUNT(*) FROM vacancies WHERE title LIKE '%$search%' $filter_1 $filter_2 $filter_3 $filter_4 $filter_5", $link);
$temp = mysql_fetch_array($count);
if ($temp[0] > 0) {
	$tempcount = $temp[0];
	$total = (($tempcount - 1) / $num) + 1;
	$total = intval($total);
	$page = intval($page);
	if (empty($page) or $page < 0) $page = 1;
	if ($page > $total) $page = $total;
	$start = $page * $num - $num;
	$qury_start_num = "LIMIT $start, $num";
}

$result = mysql_query("SELECT * FROM vacancies WHERE title LIKE '%$search%' $filter_1 $filter_2 $filter_3 $filter_4 $filter_5 ORDER BY $sorting $qury_start_num", $link);
if (mysql_num_rows($result) > 0) {
	$row = mysql_fetch_array($result);	
do {
	echo '
	<ul>
	<div class="zarp">'.$row[gold].'<br />'.round($sum = uan ($row[gold])).'-'.round($sum = uan (substr($row[gold], 5))).' UAH <br />'.round($sum = usd ($row[gold])).'-'.round($sum = usd (substr($row[gold], 5))).' USD <br />'.round($sum = eur ($row[gold])).'-'.round($sum = eur (substr($row[gold], 5))).' EUR</div>
	<li>
	<img src="images/'.$row[image].'" />
	<a href="">'.$row[title].'</a>
	<p>Страна: '.$row[country].'</p>
	<p>Пол: '.$row[sex].'</p>
	<p>Возраст: '.$row[age].'</p>
	<p>Опыт работы: '.$row[exp].'</p>
	<p>Обязанности: '.$row[charge].'</p>
	<p>Условия проживания: '.$row[live].'</p>
	<p>Рабочий график: '.$row[work].'</p>
	</li>
	<div class="dr" id="'.$row[id].'">ДОБАВИТЬ РЕЗЮМЕ</div>
	</ul>
	';
}while ($row = mysql_fetch_array($result));
}
?>
</div>

<?php
if ($page != 1){ $pstr_prev = '<li><a class="pstr-prev" href="search.php?'.$sortings.'&page='.($page - 1).'">&lt;</a></li>';}
if ($page != $total) $pstr_next = '<li><a class="pstr-next" href="search.php?'.$sortings.'&page='.($page + 1).'">&gt;</a></li>';

if($page - 5 > 0) $page5left = '<li><a href="search.php?'.$sortings.'&page='.($page - 5).'">'.($page - 5).'</a></li>';
if($page - 4 > 0) $page4left = '<li><a href="search.php?'.$sortings.'&page='.($page - 4).'">'.($page - 4).'</a></li>';
if($page - 3 > 0) $page3left = '<li><a href="search.php?'.$sortings.'&page='.($page - 3).'">'.($page - 3).'</a></li>';
if($page - 2 > 0) $page2left = '<li><a href="search.php?'.$sortings.'&page='.($page - 2).'">'.($page - 2).'</a></li>';
if($page - 1 > 0) $page1left = '<li><a href="search.php?'.$sortings.'&page='.($page - 1).'">'.($page - 1).'</a></li>';
 
if($page + 5 <= $total) $page5right = '<li><a href="search.php?'.$sortings.'&page='.($page + 5).'">'.($page + 5).'</a></li>';

if($page + 4 <= $total) $page4right = '<li><a href="search.php?'.$sortings.'&page='.($page + 4).'">'.($page + 4).'</a></li>';
if($page + 3 <= $total) $page3right = '<li><a href="search.php?'.$sortings.'&page='.($page + 3).'">'.($page + 3).'</a></li>';
if($page + 2 <= $total) $page2right = '<li><a href="search.php?'.$sortings.'&page='.($page + 2).'">'.($page + 2).'</a></li>';
if($page + 1 <= $total) $page1right = '<li><a href="search.php?'.$sortings.'&page='.($page + 1).'">'.($page + 1).'</a></li>';
 
 
if ($page+5 < $total) {
    $strtotal = '<li><p class="nav-point">...</p></li><li><a href="search.php?'.$sortings.'&page='.$total.'">'.$total.'</a></li>';
}else {
    $strtotal = ""; 
}
if ($total > 1) {
    echo '
    <div class="pstrnav">
    <ul>
    ';
    echo $pstr_prev.$page5left.$page4left.$page3left.$page2left.$page1left."<li><a class='pstr-active' href='search.php?".$sortings."&page=".$page."'>".$page."</a></li>".$page1right.$page2right.$page3right.$page4right.$page5right.$strtotal.$pstr_next;
    echo '
    </ul>
    </div>
    ';
}
?>

</div>

</div>

</div>

<div id="footer">
<div id="footer_center">
<a href="index.php"><img src="images/logo.png" id="img_footer" /></a>
<div id="footer-phone">
<h4><div class="lang_27">Служба поддержки</div></h4>
<h3>+380 97 7375547</h3>
<p class="lang_28">
Режим работы:<br />Рабочие дни: Пн. - Пт. 9:00-19:00<br />Праздники - выходные
</p>
</div>
<div id="mnnn">
<h3 id="mnn"><div class="lang_29">Местонахождение</div></h3>
<p id="mn">
Lwowska 51 <br />Chelm <br />Poland <br />office 406<br /><font class="geol">Геолокация</font>
</p>
</div>
<div id="mnnn">
<h3 id="mnn"><div class="lang_29">Местонахождение</div></h3>
<p id="mn">
Харьковское шоссе 17а <br />Киев <br />Украина <br />секция 4 офис 1<br /><font class="geolm">Геолокация</font>
</p>
</div>
<div id="nav_footer">
<h3 id="nav_footer_title"><div class="lang_0">Навигация</div></h3>
<ul id="nav_footer_ul">
<a href="po.php" class="footer_a"><li class="footer_li"><div class="lang_2">Програмное Обеспечение</div></li></a>
<a href="avto.php" class="footer_a"><li class="footer_li"><div class="lang_3">Продажа Автомобилей</div></li></a>
<a href="vis.php" class="footer_a"><li class="footer_li"><div class="lang_4">Польские Визы</div></li></a>
<a href="rab.php" class="footer_a"><li class="footer_li"><div class="lang_70">Работа в Польше</div></li></a>
<a href="blf.php" class="footer_a"><li class="footer_li"><div class="lang_5">Благотворительный Фонд</div></li></a>
<a href="feedback.php" class="footer_a"><li class="footer_li"><div class="lang_6">Связь</div></li></a>
</ul>
</div>
<div id="ss">
<h3 id="title_ss"><div class="lang_30">Социальные сети</div></h3>
<div id="sss">
<a href="https://new.vk.com/merkurijpolska" target="_blank"><img src="images/vk.png" class="img_ss" /></a>
<a href="https://www.facebook.com/groups/1636266140034222/" target="_blank"><img src="images/facebook.png" class="img_ss" /></a>
<a href="https://twitter.com/Merkurij2016" target="_blank"><img src="images/twitter.png" class="img_ss" /></a>
</div>
<div id="ros">
<h3 id="title_ros"><div class="lang_31">Рассказать о сайте</div></h3>
<script type="text/javascript">(function() {
  if (window.pluso)if (typeof window.pluso.start == "function") return;
  if (window.ifpluso==undefined) { window.ifpluso = 1;
    var d = document, s = d.createElement('script'), g = 'getElementsByTagName';
    s.type = 'text/javascript'; s.charset='UTF-8'; s.async = true;
    s.src = ('https:' == window.location.protocol ? 'https' : 'http')  + '://share.pluso.ru/pluso-like.js';
    var h=d[g]('body')[0];
    h.appendChild(s);
  }})();</script>
<div class="pluso" data-background="#dbd6d6" data-options="small,square,line,horizontal,nocounter,theme=08" data-services="vkontakte,odnoklassniki,facebook,twitter,google,moimir,email,print" data-url="http://merkurij.pl/" data-title="merkurij" data-description="Продажа Польских/Шенгенских Виз, Работа в Польше, Программное Обеспечение, Заказ Автомобилей, Благотворительные Фонды."></div>
</div>
</div>
</div>
</div>
<div id="mc">Merkury Polska © 2015-2016</div>

<script src="js/slick.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>