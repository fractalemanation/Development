﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
<link rel="stylesheet" type="text/css" href="css/reset.css" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" href="css/slick.css" />
<link rel="stylesheet" href="css/slick-theme.css" />
<link rel="stylesheet" href="css/sweetalert.css" />
<script src="js/jquery-2.2.4.js"></script>
<script src="js/jquery-1.8.2.min.js"></script>
<script src="js/jquery.cookie.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/jcarousellite_1.0.1.js"></script>
<script src="js/jquery.form.js"></script>
<script src="js/jquery.validate.js"></script>
<script src="js/sweetalert.min.js"></script>
<script src="js/script.js"></script>
<link rel="shortcut icon" type="image/x-icon" href="images/logo.png">
</head>
<body>

<div id="ifm1">
<a class="hide"><img src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png" id="del1" /></a>
<iframe id="iframem" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d317.6293282222681!2d30.6288265!3d50.4404557!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40d4c544852b445d%3A0x542edbec15f97f96!2z0KXQsNGA0LrRltCy0YHRjNC60LUg0YjQvtGB0LUsIDEsINCa0LjRl9Cy!5e0!3m2!1sru!2sua!4v1484583981914" width="800" height="500" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>

<div id="ifm2">
<a class="hide"><img src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png" id="del2" /></a>
<iframe id="iframe" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2503.957370594396!2d23.467716315292773!3d51.12769434621579!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47239a4d55b76421%3A0x309d0334a226ed9b!2zTHdvd3NrYSA1MSwgQ2hlxYJtLCDQn9C-0LvRjNGI0LA!5e0!3m2!1sru!2sru!4v1465999567612" width="800" height="500" frameborder="0" style="border: 0" title="Lwowska 51, Chelm, Poland, office 406" allowfullscreen></iframe>
</div>

<div id="navig">

<a class="hide"><img src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png" id="delete" /></a>
<h2 id="title_nav"><div class="lang_0">Навигация</div></h2>
<ul id="ul_nav">
<a href="index.php" class="li_a"><li class="li_nav"><div class="lang_1">Главная</div></li></a>
<a href="po.php" class="li_a"><li class="li_nav"><div class="lang_2">Програмное Обеспечение</div></li></a>
<a href="avto.php" class="li_a"><li class="li_nav"><div class="lang_3">Продажа Автомобилей</div></li></a>
<a href="vis.php" class="li_a"><li class="li_nav"><div class="lang_4">Польские Визы</div></li></a>
<a href="rab.php" class="li_a"><li class="li_nav"><div class="lang_70">Работа в Польше</div></li></a>
<a href="blf.php" class="li_a"><li class="li_nav"><div class="lang_5">Благотворительный Фонд</div></li></a>
<a href="feedback.php" class="li_a"><li class="li_nav"><div class="lang_6">Связь</div></li></a>
</ul>

</div>

<div id="block-body">

<div class="main">
<a href="index.php"><img src="images/logo.png" class="imgsl" /></a>
<a class="show"><img src="images/img_nav.png" class="img_nav" /></a>
<a class="shide"><img src="images/img_nav.png" class="img_navhov" /></a>
<h3 class="ntsl1">+380 63 7497525<br />+380 0681747031<br />+48 666 911168</h3>
<select name="lang" class="lang">
<option value="1" selected="selected">Русский</option>
<option value="2">Polski</option>
<option value="3">English</option>
<option value="4">Español</option>
<option value="5">Français</option>
</select>
<h3 class="ntsl2">+380 97 7375547<br />+380 66 3693504<br />+48 666 911168</h3>
 <div class="sl">
  <div class="sl__slide">
  <img src="images/fpol.jpg" alt="Картинка слайда 1" class="sl__img" />
  <div class="sl__text">
  <h3 class="sl__zag">Merkury</h3>
  <p class="sl__desc"><div class="lang_12">Флаг Польши</div></p>
  </div>
  </div>
  
  <div class="sl__slide">
  <img src="images/fukr.jpg" alt="Картинка слайда 2" class="sl__img" />
  <div class="sl__text">
  <h3 class="sl__zag">Merkury</h3>
  <p class="sl__desc"><div class="lang_13">Флаг Украины</div></p>
  </div>
  </div>
  
  <div class="sl__slide">
  <img src="images/fshen.jpg" alt="Картинка слайда 3" class="sl__img" />
  <div class="sl__text">
  <h3 class="sl__zag">Merkury</h3>
  <p class="sl__desc"><div class="lang_14">Флаг Шенгена</div></p>
  </div>
  </div>
 </div>
</div>

<div id="on">
<img src="images/logo.png" class="imgon" />
<p class="lang_15"> Корпорация Merkriy - молодая амбициозная команда профессионалов, обеспечит Вас как базовой консультацией на тему трудоустройства в Европе, так и поможет заключить договор с иностранными работодателями. Предоставит полное консультационное сопровождение и помощь в оформлении пакета документов для получения рабочей Визы. Наша стратегия — предоставлять качественные услуги по трудоустройству за границей. Мы курируем своих клиентов на всех этапах трудоустройства, оказываем поддержку после Вашего выезда из Украины и продолжаем держать связь с клиентом до момента возвращения на родину. Мы курируем своих клиентов на всех этапах трудоустройства, оказываем поддержку после Вашего выезда из Украины и продолжаем держать связь с клиентом до момента возвращения на родину. Наши информационные базы охватывают вакансии практически всех специализаций и условий трудоустройства.<br /><br />
<a href="our.php" class="ondop">Подробнее</a></p>
</div>

<div id="imgnav">
<div id="nav">
<a href="po.php" class="nav1"><img src="images/mpo.png" class="nav_img" /><div class="nav1_text"><div class="lang_7">ПО</div></div></a>
<a href="avto.php" class="nav2"><img src="images/mavto.png" class="nav_img" /><div class="nav2_text"><div class="lang_8">Авто</div></div></a>
<a href="vis.php" class="nav3"><img src="images/mvisa.png" class="nav_img" /><div class="nav3_text"><div class="lang_9">Визы</div></div></a>
<a href="rab.php" class="nav6"><img src="images/mrab.png" class="nav_img" /><div class="nav6_text"><div class="lang_74">Работа</div></div></a>
<a href="blf.php" class="nav4"><img src="images/mbf.png" class="nav_img" /><div class="nav4_text"><div class="lang_10">БФ</div></div></a>
<a href="feedback.php" class="nav5"><img src="images/msv.png" class="nav_img" /><div class="nav5_text"><div class="lang_11">Связь</div></div></a>
</div>
</div>

<div id="tov">

<h2 class="tov"><div class="lang_16">Список новостей нашей компании</div>
</h2>
<div id="block-news">
<center><div id="news-prev"></div></center>
<div id="newsticker">
<ul>
<?php
define('kop', true);
include('include/db_connect.php');
$result = mysql_query("SELECT * FROM news ORDER BY id DESC", $link);
if (mysql_num_rows($result) > 0) {
	$row = mysql_fetch_array($result);	
do {
	echo '
	<li>
	<img src="images/'.$row[image].'" />
	<a href="">'.$row[title].'</a>
	<p>'.$row[text].'</p>
	<span>'.$row[date].'</span>
	</li>
	';
}while ($row = mysql_fetch_array($result));
}
?>
</ul>
</div>
<center><div id="news-next"></div></center>
</div>

<div id="block-news2">
<center><div id="news-prev2"></div></center>
<div id="newsticker2">
<ul>
<?php
define('kop', true);
include('include/db_connect.php');
$result = mysql_query("SELECT * FROM news ORDER BY id DESC", $link);
if (mysql_num_rows($result) > 0) {
	$row = mysql_fetch_array($result);	
do {
	echo '
	<li>
	<img src="images/'.$row[image].'" />
	<a href="">'.$row[title_pol].'</a>
	<p>'.$row[text_pol].'</p>
	<span>'.$row[date].'</span>
	</li>
	';
}while ($row = mysql_fetch_array($result));
}
?>
</ul>
</div>
<center><div id="news-next2"></div></center>
</div>

<div id="block-news3">
<center><div id="news-prev3"></div></center>
<div id="newsticker3">
<ul>
<?php
define('kop', true);
include('include/db_connect.php');
$result = mysql_query("SELECT * FROM news ORDER BY id DESC", $link);
if (mysql_num_rows($result) > 0) {
	$row = mysql_fetch_array($result);	
do {
	echo '
	<li>
	<img src="images/'.$row[image].'" />
	<a href="">'.$row[title_eng].'</a>
	<p>'.$row[text_eng].'</p>
	<span>'.$row[date].'</span>
	</li>
	';
}while ($row = mysql_fetch_array($result));
}
?>
</ul>
</div>
<center><div id="news-next3"></div></center>
</div>

<div id="block-news4">
<center><div id="news-prev4"></div></center>
<div id="newsticker4">
<ul>
<?php
define('kop', true);
include('include/db_connect.php');
$result = mysql_query("SELECT * FROM news ORDER BY id DESC", $link);
if (mysql_num_rows($result) > 0) {
	$row = mysql_fetch_array($result);	
do {
	echo '
	<li>
	<img src="images/'.$row[image].'" />
	<a href="">'.$row[title_esp].'</a>
	<p>'.$row[text_esp].'</p>
	<span>'.$row[date].'</span>
	</li>
	';
}while ($row = mysql_fetch_array($result));
}
?>
</ul>
</div>
<center><div id="news-next4"></div></center>
</div>

<div id="block-news5">
<center><div id="news-prev5"></div></center>
<div id="newsticker5">
<ul>
<?php
define('kop', true);
include('include/db_connect.php');
$result = mysql_query("SELECT * FROM news ORDER BY id DESC", $link);
if (mysql_num_rows($result) > 0) {
	$row = mysql_fetch_array($result);	
do {
	echo '
	<li>
	<img src="images/'.$row[image].'" />
	<a href="">'.$row[title_fran].'</a>
	<p>'.$row[text_fran].'</p>
	<span>'.$row[date].'</span>
	</li>
	';
}while ($row = mysql_fetch_array($result));
}
?>
</ul>
</div>
<center><div id="news-next5"></div></center>
</div>

</div>

<div id="imgot"></div>

<div id="ot">
<div class="otsivi"><div class="lang_17">Отзывы</div></div>

<div class="maining">
 <div class="sl">
 
  <div class="sl__slide">
  <img src="images/Visa.jpg" alt="Картинка слайда 1" class="sl_img" />
  <div class="sl_text">
  <h3 class="sl_zag"><div class="lang_18">АЛЕКСАНДР КОЛОСЮК</div></h3>
  <p class="lang_19">Покупатель виз в нашей компании «Меркурий», а также активный помощник в работе Благотворительного Фонда.</p>
  <p class="lang_20">«Очень благодарен компании «Меркурий». Оформление проходит быстро и профессионально. Спасибо Вам большое!</p>
  </div>
  </div>
  
  <div class="sl__slide">
  <img src="images/Visa.jpg" alt="Картинка слайда 2" class="sl_img" />
  <div class="sl_text">
  <h3 class="sl_zag"><div class="lang_21">ЛЮДМИЛА ПЕТРЕНКО</div></h3>
  <p class="lang_22">Работала с нами дистанционно. Постоянно была на связи.</p>
  <p class="lang_23">«Хочу выразить огромную благодарность компании «Меркурий», и особенно специалисту Людмиле Бондарь, за помощь в получении визы»</p>
  </div>
  </div>
  
  <div class="sl__slide">
  <img src="images/Visa.jpg" alt="Картинка слайда 3" class="sl_img" />
  <div class="sl_text">
  <h3 class="sl_zag"><div class="lang_24">ГЕННАДИЙ КУЛИШ</div></h3>
  <p class="lang_25">Покупатель виз, автомобилей, а также Программного обеспечения в нашей компании «Меркурий».</p>
  <p class="lang_26">«Ваша фирма действительно имеет хороший фундамент для крепкого будущего!»</p>
  </div>
  </div>
  
  <div class="sl__slide">
  <img src="images/Visa.jpg" alt="Картинка слайда 3" class="sl_img" />
  <div class="sl_text">
  <h3 class="sl_zag"><div class="lang_24">НАТАЛЬЯ ШАРКОВА</div></h3>
  <p class="lang_25">Получатель виз через Merkury Polska уже не первый раз и очень довольна сотрудничеством.</p>
  <p class="lang_26">Очень благодарна за получение польского Шенгена в такие краткие сроки! А так же за качественное обслуживание — объяснили подробно как правильно пересекать границы и какие могут быть тонкости.</p>
  </div>
  </div>
  
  <div class="sl__slide">
  <img src="images/Visa.jpg" alt="Картинка слайда 3" class="sl_img" />
  <div class="sl_text">
  <h3 class="sl_zag"><div class="lang_24">ЕЛЕНА ДЕГТЯРЕНКО</div></h3>
  <p class="lang_25">Получатель визы через Merkury Polska.</p>
  <p class="lang_26">Хочу поблагодарить фирму Merkury за  быстрое открытие рабочей визы! Сделали на пол года, в чистый паспорт. Я с этой визой уже съездила в Польшу на работу, осталась довольна!</p>
  </div>
  </div>
  
  <div class="sl__slide">
  <img src="images/Visa.jpg" alt="Картинка слайда 3" class="sl_img" />
  <div class="sl_text">
  <h3 class="sl_zag"><div class="lang_24">АНАСТАСИЯ БОНДАРЕНКО</div></h3>
  <p class="lang_25">Оформляла визу в нашей компании "Merkury".</p>
  <p class="lang_26">Впервые уезжала на роботу в Польшу  и менеджер Людмила была очень вежливая и отзывчивая спустя месяц после подписания договора уехала на роботу. Спасибо компании "Merkury". Всем рекомендую.</p>
  </div>
  </div>
  
 </div>
</div>
</div>

</div>

<div id="footer">
<div id="footer_center">
<a href="index.php"><img src="images/logo.png" id="img_footer" /></a>
<div id="footer-phone">
<h4><div class="lang_27">Служба поддержки</div></h4>
<h3>+380 97 7375547</h3>
<p class="lang_28">
Режим работы:<br />Рабочие дни: Пн. - Пт. 9:00-19:00<br />Праздники - выходные
</p>
</div>
<div id="mnnn">
<h3 id="mnn"><div class="lang_29">Местонахождение</div></h3>
<p id="mn">
Lwowska 51 <br />Chelm <br />Poland <br />office 406<br /><font class="geol">Геолокация</font>
</p>
</div>
<div id="mnnn">
<h3 id="mnn"><div class="lang_29">Местонахождение</div></h3>
<p id="mn">
Харьковское шоссе 17а <br />Киев <br />Украина <br />секция 4 офис 1<br /><font class="geolm">Геолокация</font>
</p>
</div>
<div id="nav_footer">
<h3 id="nav_footer_title"><div class="lang_0">Навигация</div></h3>
<ul id="nav_footer_ul">
<a href="po.php" class="footer_a"><li class="footer_li"><div class="lang_2">Програмное Обеспечение</div></li></a>
<a href="avto.php" class="footer_a"><li class="footer_li"><div class="lang_3">Продажа Автомобилей</div></li></a>
<a href="vis.php" class="footer_a"><li class="footer_li"><div class="lang_4">Польские Визы</div></li></a>
<a href="rab.php" class="footer_a"><li class="footer_li"><div class="lang_70">Работа в Польше</div></li></a>
<a href="blf.php" class="footer_a"><li class="footer_li"><div class="lang_5">Благотворительный Фонд</div></li></a>
<a href="feedback.php" class="footer_a"><li class="footer_li"><div class="lang_6">Связь</div></li></a>
</ul>
</div>
<div id="ss">
<h3 id="title_ss"><div class="lang_30">Социальные сети</div></h3>
<div id="sss">
<a href="https://new.vk.com/merkurijpolska" target="_blank"><img src="images/vk.png" class="img_ss" /></a>
<a href="https://www.facebook.com/groups/1636266140034222/" target="_blank"><img src="images/facebook.png" class="img_ss" /></a>
<a href="https://twitter.com/Merkurij2016" target="_blank"><img src="images/twitter.png" class="img_ss" /></a>
</div>
<div id="ros">
<h3 id="title_ros"><div class="lang_31">Рассказать о сайте</div></h3>
<script type="text/javascript">(function() {
  if (window.pluso)if (typeof window.pluso.start == "function") return;
  if (window.ifpluso==undefined) { window.ifpluso = 1;
    var d = document, s = d.createElement('script'), g = 'getElementsByTagName';
    s.type = 'text/javascript'; s.charset='UTF-8'; s.async = true;
    s.src = ('https:' == window.location.protocol ? 'https' : 'http')  + '://share.pluso.ru/pluso-like.js';
    var h=d[g]('body')[0];
    h.appendChild(s);
  }})();</script>
<div class="pluso" data-background="#dbd6d6" data-options="small,square,line,horizontal,nocounter,theme=08" data-services="vkontakte,odnoklassniki,facebook,twitter,google,moimir,email,print" data-url="http://merkurij.pl/" data-title="merkurij" data-description="Продажа Польских/Шенгенских Виз, работа в Польше, Программное Обеспечение, Заказ Автомобилей, Благотворительные Фонды."></div>
</div>
</div>
</div>
</div>
<div id="mc">Merkury Polska © 2015-2016</div>

<script src="js/slick.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>