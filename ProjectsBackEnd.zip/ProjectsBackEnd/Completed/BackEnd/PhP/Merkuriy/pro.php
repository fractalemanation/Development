﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Merkury</title>
<link rel="stylesheet" type="text/css" href="css/reset.css" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" href="css/slick.css" />
<link rel="stylesheet" href="css/slick-theme.css" />
<link rel="stylesheet" href="css/sweetalert.css" />
<script src="js/jquery-2.2.4.js"></script>
<script src="js/jquery-1.8.2.min.js"></script>
<script src="js/jquery.cookie.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/jcarousellite_1.0.1.js"></script>
<script src="js/jquery.form.js"></script>
<script src="js/jquery.validate.js"></script>
<script src="js/sweetalert.min.js"></script>
<script src="js/script.js"></script>
<link rel="shortcut icon" type="image/x-icon" href="images/logo.png">
</head>
<body>

<div id="ifm1">
<a class="hide"><img src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png" id="del1" /></a>
<iframe id="iframem" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d317.6293282222681!2d30.6288265!3d50.4404557!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40d4c544852b445d%3A0x542edbec15f97f96!2z0KXQsNGA0LrRltCy0YHRjNC60LUg0YjQvtGB0LUsIDEsINCa0LjRl9Cy!5e0!3m2!1sru!2sua!4v1484583981914" width="800" height="500" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>

<div id="ifm2">
<a class="hide"><img src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png" id="del2" /></a>
<iframe id="iframe" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2503.957370594396!2d23.467716315292773!3d51.12769434621579!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47239a4d55b76421%3A0x309d0334a226ed9b!2zTHdvd3NrYSA1MSwgQ2hlxYJtLCDQn9C-0LvRjNGI0LA!5e0!3m2!1sru!2sru!4v1465999567612" width="800" height="500" frameborder="0" style="border: 0" title="Lwowska 51, Chelm, Poland, office 406" allowfullscreen></iframe>
</div>

<div id="navig">

<a class="hide"><img src="http://www.free-icons-download.net/images/multiplication-symbols-63643.png" id="delete" /></a>
<h2 id="title_nav"><div class="lang_0">Навигация</div></h2>
<ul id="ul_nav">
<a href="index.php" class="li_a"><li class="li_nav"><div class="lang_1">Главная</div></li></a>
<a href="po.php" class="li_a"><li class="li_nav"><div class="lang_2">Програмное Обеспечение</div></li></a>
<a href="avto.php" class="li_a"><li class="li_nav"><div class="lang_3">Продажа Автомобилей</div></li></a>
<a href="vis.php" class="li_a"><li class="li_nav"><div class="lang_4">Польские Визы</div></li></a>
<a href="rab.php" class="li_a"><li class="li_nav"><div class="lang_70">Работа в Польше</div></li></a>
<a href="blf.php" class="li_a"><li class="li_nav"><div class="lang_5">Благотворительный Фонд</div></li></a>
<a href="feedback.php" class="li_a"><li class="li_nav"><div class="lang_6">Связь</div></li></a>
</ul>

</div>

<div id="block-body">

<div class="main">
<a href="index.php"><img src="images/logo.png" class="imgsl" /></a>
<a class="show"><img src="images/img_nav.png" class="img_nav" /></a>
<a class="shide"><img src="images/img_nav.png" class="img_navhov" /></a>
<h3 class="ntsl1">+380 63 7497525<br />+380 0681747031<br />+48 666 911168</h3>
<select name="lang" class="lang">
<option value="1" selected="selected">Русский</option>
<option value="2">Polski</option>
<option value="3">English</option>
<option value="4">Español</option>
<option value="5">Français</option>
</select>
<h3 class="ntsl2">+380 97 7375547<br />+380 66 3693504<br />+48 666 911168</h3>
 <div class="sl">
  <div class="sl__slide">
  <img src="images/fpol.jpg" alt="Картинка слайда 1" class="sl__img" />
  </div>
  
  <div class="sl__slide">
  <img src="images/fukr.jpg" alt="Картинка слайда 2" class="sl__img" />
  </div>
  
  <div class="sl__slide">
  <img src="images/fshen.jpg" alt="Картинка слайда 3" class="sl__img" />
  </div>
 </div>
</div>

<div id="on-inform" style="height:405px;">

<div id="block-inform">

<div id="nav-inform">
<a href="po.php" class="nav1"><img src="images/mpo.png" class="nav_img" /><div class="nav1_text"><div class="lang_7">ПО</div></div></a>
<a href="avto.php" class="nav2"><img src="images/mavto.png" class="nav_img" /><div class="nav2_text"><div class="lang_8">Авто</div></div></a>
<a href="vis.php" style="width:100px;height:auto;float:left;margin-right:1px;background-color:#FFF;cursor:pointer;padding-bottom:0;border-bottom:10px solid #e67f35;box-shadow:1px -1px 3px #CCC,-1px -1px 3px #CCC;"><img src="images/mvisa.png" style="padding-bottom:10px;width:60px;height:60px;padding:20px;transform:translateY(-10px);" /><div style="font:16px sans-serif;text-align:center;color:#e67f35;transform:translateY(-10px);"><div class="lang_9">Визы</div></div></a>
<a href="rab.php" class="nav6"><img src="images/mrab.png" class="nav_img" /><div class="nav6_text"><div class="lang_74">Работа</div></div></a>
<a href="blf.php" class="nav4"><img src="images/mbf.png" class="nav_img" /><div class="nav4_text"><div class="lang_10">БФ</div></div></a>
<a class="nav5" href="feedback.php"><img src="images/msv.png" class="nav_img" /><div class="nav5_text"><div class="lang_11">Связь</div></div></a>
</div>

<h2 class="h2-titles">Процедура оформления</h2>
<div class="textons">Процедура оформленния договора, вносится предоплата на карту банка в размере 50 евро, в гривне по курсу НБУ. Заполненная Вами анкета и резюме, отправляется нашим заграничным партнерам на рассмотрение.
<br />Потом, когда придет подтверждение, что Вы востребованы, мы начинаем готовить Вам пакет документов на получение приглашения от заграничного работодателя (после первоначального взноса 1450 (на 10.01.2017), на которые мы осуществляем переговоры с работодателем, пересылку всех документов за рубеж, оплачиваем почтовую доставку приглашения на Украину, данная сумма в случае Вашего отказа не возвращается)
<br />После получения приглашения, наша корпорация поможет Вам в оформлении всего пакета документов, для получения Польской Рабочей визы.
<br />Подача документов в Посольство Польши или Визовый Центр осуществляется лично.
<br />Наши менеджеры, когда будет открыта виза, предлагают Вам ряд актуальных вакансии на данный период.
<br />После выбора Вами вакансии, мы поможем Вам с покупкой билета(за Ваши средства) также выдается подробный план проезда до места работы.
<br />На территории Польши, по приезду Вас будет ждать представитель нашей компании.
<br />Весь период наши менеджер будут с вами на связи (24 часа в сутки, 7 дней в неделю)</div>

</div>

</div>

</div>

<div id="footer">
<div id="footer_center">
<a href="index.php"><img src="images/logo.png" id="img_footer" /></a>
<div id="footer-phone">
<h4><div class="lang_27">Служба поддержки</div></h4>
<h3>+380 97 7375547</h3>
<p class="lang_28">
Режим работы:<br />Рабочие дни: Пн. - Пт. 9:00-19:00<br />Праздники - выходные
</p>
</div>
<div id="mnnn">
<h3 id="mnn"><div class="lang_29">Местонахождение</div></h3>
<p id="mn">
Lwowska 51 <br />Chelm <br />Poland <br />office 406<br /><font class="geol">Геолокация</font>
</p>
</div>
<div id="mnnn">
<h3 id="mnn"><div class="lang_29">Местонахождение</div></h3>
<p id="mn">
Харьковское шоссе 17а <br />Киев <br />Украина <br />секция 4 офис 1<br /><font class="geolm">Геолокация</font>
</p>
</div>
<div id="nav_footer">
<h3 id="nav_footer_title"><div class="lang_0">Навигация</div></h3>
<ul id="nav_footer_ul">
<a href="po.php" class="footer_a"><li class="footer_li"><div class="lang_2">Програмное Обеспечение</div></li></a>
<a href="avto.php" class="footer_a"><li class="footer_li"><div class="lang_3">Продажа Автомобилей</div></li></a>
<a href="vis.php" class="footer_a"><li class="footer_li"><div class="lang_4">Польские Визы</div></li></a>
<a href="rab.php" class="footer_a"><li class="footer_li"><div class="lang_70">Работа в Польше</div></li></a>
<a href="blf.php" class="footer_a"><li class="footer_li"><div class="lang_5">Благотворительный Фонд</div></li></a>
<a href="feedback.php" class="footer_a"><li class="footer_li"><div class="lang_6">Связь</div></li></a>
</ul>
</div>
<div id="ss">
<h3 id="title_ss"><div class="lang_30">Социальные сети</div></h3>
<div id="sss">
<a href="https://new.vk.com/merkurijpolska" target="_blank"><img src="images/vk.png" class="img_ss" /></a>
<a href="https://www.facebook.com/groups/1636266140034222/" target="_blank"><img src="images/facebook.png" class="img_ss" /></a>
<a href="https://twitter.com/Merkurij2016" target="_blank"><img src="images/twitter.png" class="img_ss" /></a>
</div>
<div id="ros">
<h3 id="title_ros"><div class="lang_31">Рассказать о сайте</div></h3>
<script type="text/javascript">(function() {
  if (window.pluso)if (typeof window.pluso.start == "function") return;
  if (window.ifpluso==undefined) { window.ifpluso = 1;
    var d = document, s = d.createElement('script'), g = 'getElementsByTagName';
    s.type = 'text/javascript'; s.charset='UTF-8'; s.async = true;
    s.src = ('https:' == window.location.protocol ? 'https' : 'http')  + '://share.pluso.ru/pluso-like.js';
    var h=d[g]('body')[0];
    h.appendChild(s);
  }})();</script>
<div class="pluso" data-background="#dbd6d6" data-options="small,square,line,horizontal,nocounter,theme=08" data-services="vkontakte,odnoklassniki,facebook,twitter,google,moimir,email,print" data-url="http://merkurij.pl/" data-title="merkurij" data-description="Продажа Польских/Шенгенских Виз, работа в Польше, Программное Обеспечение, Заказ Автомобилей, Благотворительные Фонды."></div>
</div>
</div>
</div>
</div>
<div id="mc">Merkury Polska © 2015-2016</div>

<script src="js/slick.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>