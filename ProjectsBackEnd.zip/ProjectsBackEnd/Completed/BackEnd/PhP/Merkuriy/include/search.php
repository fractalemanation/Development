﻿<?php
	define('kop', true);
	include("db_connect.php");
	$search = $_POST['text'];
	$result = mysql_query("SELECT * FROM vacancies WHERE title LIKE '%$search%'",$link);
	if (mysql_num_rows($result) > 0) {
		$result = mysql_query("SELECT * FROM vacancies WHERE title LIKE '%$search%' LIMIT 10",$link);
		$row = mysql_fetch_array($result);
		do {
			echo '
			<li><a href="search.php?q='.$row["title"].'">'.$row["title"].'</a></li>
			';
			}
			while ($row = mysql_fetch_array($result));
			}
?>