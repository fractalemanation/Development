﻿<?php
$recepient = "danyy385@gmail.com";
$sitename = "merkurij.pl";

$fio = trim($_POST["fio"]);
$email = trim($_POST["emai"]);
$phone = trim($_POST["phon"]);
$vacancy = trim($_POST["vacancy"]);
$text = trim($_POST["text"]);

$message = "Имя: $fio \nEmail: $email \nТелефон: $phone \nВакансия: $vacancy \nТекст: $text";

$pagetitle = "Новая заявка с сайта \"$sitename\"";
mail($recepient, $pagetitle, $message, "Content-type: text/plain; charset=\"utf-8\"\n From: $recepient");
mail($email, $pagetitle, "Ваш отзыв успешно отправлен!\n".$message, "Content-type: text/plain; charset=\"utf-8\"\n From: $recepient");

$link = mysqli_connect("localhost", "id250819_root", "diablo0365", "id250819_host"); 
mysqli_query($link, "INSERT INTO `send` VALUES('', '".$fio."', '".$email."', '".$phone."', '".$vacancy."', '".$text."', NOW())");
?>