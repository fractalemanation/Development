﻿<?php
$recepient = "danyy385@gmail.com";
$sitename = "merkurij.pl";

$name = trim($_POST["name"]);
$email = trim($_POST["email"]);
$phone = trim($_POST["phone"]);
$text = trim($_POST["text"]);
$message = "Имя: $name \nEmail: $email \nТелефон: $phone \nТекст: $text";

$pagetitle = "Новая заявка с сайта \"$sitename\"";
mail($recepient, $pagetitle, $message, "Content-type: text/plain; charset=\"utf-8\"\n From: $recepient");
mail($email, $pagetitle, "Ваш отзыв успешно отправлен!\n".$message, "Content-type: text/plain; charset=\"utf-8\"\n From: $recepient");

$link = mysqli_connect("localhost", "id250819_root", "diablo0365", "id250819_host");
mysqli_query($link, "INSERT INTO `mail` VALUES('', '".$name."', '".$email."', '".$phone."', '".$text."')");
?>