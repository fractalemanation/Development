<?php
if (!$_SESSION['confirm']['code']) not_found();

top('Подтверждение');
?>

<div class="textCenter">
<h1>Подтверждение</h1>
<p><input type="text" id="code" placeholder="Код" /></p>
<p><button onclick="send_post('gform', 'confirm', 'code')">Подтвердить</button></p>
</div>

<?php bottom(); ?>