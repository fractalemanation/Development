<?php top('Вход'); ?>

<div class="textCenter">
<h1>Вход</h1>
<p><input type="text" id="email" placeholder="E-mail" /></p>
<p><input type="password" id="password" placeholder="Пароль" /></p>
<p><input type="text" id="captcha" placeholder="<?=captcha_show()?>" /></p>
<p><button onclick="send_post('gform', 'login', 'email.password.captcha')">Вход</button></p>
<p><button onclick="go('recovery')">Восстановление пароля</button></p>
</div>

<?php bottom(); ?>