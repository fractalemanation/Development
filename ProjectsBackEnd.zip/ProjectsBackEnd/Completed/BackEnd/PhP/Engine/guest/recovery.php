<?php top('Восстановление пароля'); ?>

<div class="textCenter">
<h1>Восстановление пароля</h1>
<p><input type="text" id="email" placeholder="E-mail" /></p>
<p><input type="text" id="captcha" placeholder="<?=captcha_show()?>" /></p>
<p><button onclick="send_post('gform', 'recovery', 'email.captcha')">Восстановить</button></p>
</div>

<?php bottom(); ?>