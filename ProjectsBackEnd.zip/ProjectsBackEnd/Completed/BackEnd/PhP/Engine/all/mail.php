<?php
if ($_POST['contact_f']) {
	email_valid();
	if (strlen($_POST['message']) < 10) message('Длина сообщения должна быть не меньше 10 символов!');
	captcha_valid();
	send_mail('danyy385@gmail.com', 'Обращение в службу поддержки', "E-mail отправителя сообщения: $_POST[email]<br/><br/>Сообщение: ".htmlspecialchars($_POST['message']), 'From: site-admin@000webhost.com');
	message('Ваше сообщение успешно отправлено.');
}