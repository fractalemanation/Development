<?php top('Вход в Панель Администратора'); ?>

<div class="textCenter">
<h1>Вход в Панель Администратора</h1>
<p><input type="password" id="password" placeholder="Пароль" /></p>
<p><input type="text" id="captcha" placeholder="<?=captcha_show()?>" /></p>
<p><button onclick="send_post('a_auth', 'login', 'password.captcha')">Вход</button></p>
</div>

<?php bottom(); ?>