<?php top() ?>

<div class="textCenter"><h1>Добро пожаловать!</h1></div>

<?php bottom() ?>