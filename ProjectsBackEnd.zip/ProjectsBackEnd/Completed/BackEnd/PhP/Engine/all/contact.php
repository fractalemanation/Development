<?php top('Обратная связь'); ?>

<div class="textCenter"><h1>Форма обратной связи</h1></div>
<p><input type="text" id="email" placeholder="E-mail" value="<?=$_SESSION['email']?>" /></p>
<p><textarea id="message" placeholder="Текст сообщения"></textarea></p>
<p><input type="text" id="captcha" placeholder="<?=captcha_show()?>" /></p>
<p><button onclick="send_post('mail', 'contact', 'email.message.captcha')">Отправить</button></p>

<?php bottom(); ?>