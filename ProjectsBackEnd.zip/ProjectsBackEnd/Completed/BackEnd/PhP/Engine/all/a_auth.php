<?php
if ($_POST['login_f']) {
	if ($_POST['password'] != '0365' or $_SERVER['REMOTE_ADDR'] != '93.79.67.67') message('Доступ запрещен!');
	captcha_valid();
	$_SESSION['admin'] = 1;
	go('a_main');
}
?>