<?php
$handle = @fopen('ban.txt', 'r');
if ($handle) {
	while (($buffer = fgets($handle, 4096)) != false) {
		if (trim($buffer) == $_SERVER['REMOTE_ADDR']) exit('<center><h1 style="font:bold 75px sans-serif">Доступ запрещен</h1></center>');
	}
	if (!feof($handle)) echo 'Error: unexpected fgets() fail';
	fclose($handle);
}

if (is_numeric($_GET['ref'])) {
	setcookie('ref', $_GET['ref'], strtotime('+1 week'));
	header('Location: /');
}

if ($_SERVER['REQUEST_URI'] == '/') $page = 'main';
else {
	$page = substr($_SERVER['REQUEST_URI'], 1);
	if (!preg_match('/^[A-z0-9]{2,20}$/', $page)) exit('<center><h1 style="font:bold 75px sans-serif">Error URL</h1></center>');
}

$CONNECT = mysqli_connect('localhost', 'id7604627_rabean', 'password0365', 'id7604627_rabean');
if (!$CONNECT) exit('<center><h1 style="font:bold 75px sans-serif">Не подключена База Данных!</h1></center>');

session_start();

if (file_exists('all/'.$page.'.php')) include 'all/'.$page.'.php';
else if ($_SESSION['id'] and file_exists('auth/'.$page.'.php')) include 'auth/'.$page.'.php';
else if (!$_SESSION['id'] and file_exists('guest/'.$page.'.php')) include 'guest/'.$page.'.php';
else if ($_SESSION['admin'] and file_exists('admin/'.$page.'.php')) include 'admin/'.$page.'.php';
else not_found();

function message ($text) {
	exit('{"message": "'.$text.'"}');
}

function go ($url) {
	exit('{"go": "'.$url.'"}');
}

function captcha_show () {
	$questions = array(1 => 'Столица Роcсии?', 2 => 'Столица Украины?', 3 => 'Столица Белорусии?', 4 => 'Столица Польши?', 5 => 'Столица Италии?', 6 => 'Столица Англии?', 7 => 'Столица США?');
	$num = mt_rand(1, count($questions));
	$_SESSION['captcha'] = $num;
	echo $questions[$num];
}

function captcha_valid () {
	$answers = array(1 => 'москва', 2 => 'киев', 3 => 'минск', 4 => 'варшава', 5 => 'рим', 6 => 'лондон', 7 => 'вашингтон');
	if ($_SESSION['captcha'] != array_search(mb_strtolower($_POST['captcha']), $answers)) message('Ответ на вопрос капчи неправильный!');
}

function random_str ($num = 30) {
	return substr(str_shuffle('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, $num);
}

function email_valid () {
	if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) message('E-mail указан неправильно!');
}

function password_valid () {
	if (!preg_match('/^[A-z0-9]{5,50}$/', $_POST['password'])) message('Пароль указан неправильно и может содержать от 5 до 50 символов!');
	$_POST['password'] = md5($_POST['password']);
}

function not_found () {
	exit('<center><h1 style="font:bold 250px sans-serif">404</h1><h2 style="margin-top:-150px;font:bold 28px sans-serif">Страница не найдена! Перейдите на главную - <a href="/" style="text-decoration:none;color:black;text-shadow:0 0 2px red">Главная</a></h2></center>');
}

function services_price ($id) {
	$array = array(1 => 10, 2 => 50, 3 => 200);
	return $array[$id];
}

function services_promo ($code) {
	$array = array('promo1code10' => 10, 'promo2code50' => 50);
	return $array[$code];
}

function calc_promo ($id) {
	if ($_SESSION['promo']) $promo = $_SESSION['promo'];
	else $promo = 0;

	$per = (services_price($id) * $promo) / 100;
	return (services_price($id) - $per);
}

function send_mail ($email, $title, $text) {
	mail($email, $title, '<!DOCTYPE html><html><head><title>'.$title.'</title></head><body style="margin: 0"><div style="margin: 0; padding: 0; font-size: 18px; font-family: Arial, sans-serif; font-weight: bold; text-align: center; background-color: #FCFCFD"><div style="margin: 0; background-color: #464E78; padding: 25px; color: #FFF">'.$title.'</div><div style="padding: 30px"><div style="background-color: #FFF; border-radius: 4px; padding: 25px; border: 1px solid #EEEFF2">'.$text.'</div></div></div></body></html>', "From: site-admin@000webhost.com\r\nMIME-Version: 1.0\r\nContent-type: text/html; charset=UTF-8");
}

function work () {
	if (!in_array($_SERVER['REMOTE_ADDR'], array('93.79.67.67', '93.79.67.671', '93.79.67.672'))) exit('<center><h1 style="font:bold 100px sans-serif">Ведутся технические работы</h1></center>');
}

function bbcode ($text) {
	$search = array('[b]','[/b]', '[i]','[/i]', '[url=','=name=','[/url]', '[img]','[/img]', '[audio]','[/audio]', '[video]','[/video]');
	$replace = array('<b>','</b>', '<i>','</i>', '<a target="_blank" href="','">','</a>', '<img width="400" height="400" src="','"></img>', '<audio src="','" controls></audio>', '<video width="400" height="400" src="','" controls></video>');
	return str_replace($search, $replace, $text);
}

function top ($title) {
	echo '
	<!DOCTYPE html>
	<html>
	<head>
	<title>'.$title.'</title>
	<link rel="stylesheet" href="/css/style.css" />
	<script src="/js/jquery.js"></script>
	<script src="/js/script.js"></script>
	</head>
	<body>
	<div class="wrapper">
	<div class="menu">
	<a href="/">Главная</a>';
	if ($_SESSION['id'] and !$_SESSION['admin']) {
		echo '
		<a href="/profile">Профиль</a>
		<a href="/news">Новости</a>
		<a href="/chat">Чат</a>
		<a href="/history">История</a>
		<a href="/services">Услуги</a>
		<a href="/referral">Рефералы</a>
		<a href="/logout">Выход</a>
		';
	} else if ($_SESSION['admin']) {
		echo '
		<a href="/a_main">Панель</a>
		<a href="/a_logout">Выход</a>
		';
	} else {
		echo '
		<a href="/login">Вход</a>
		<a href="/registration">Регистрация</a>
		';
	}
	echo '
	<a href="/contact">Обратная связь</a>
	</div>
	<div class="content">
	<div class="block">
	';
}

function bottom () {
	echo '
	</div>
	</div>
	</div>
	<script type="text/javascript">
(function(){ var widget_id = "MmvGiMa4n4";var d=document;var w=window;function l(){
var s = document.createElement("script"); s.type = "text/javascript"; s.async = true; s.src = "//code.jivosite.com/script/widget/"+widget_id; var ss = document.getElementsByTagName("script")[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=="complete"){l();}else{if(w.attachEvent){w.attachEvent("onload",l);}else{w.addEventListener("load",l,false);}}})();</script>
	</body>
	</html>
	';
}
?>