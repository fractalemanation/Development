<?php top('Профиль'); ?>

<div class="textCenter">
<h1>Редактировать</h1>
<p><input type="password" id="password" placeholder="Пароль" /></p>
<p><input type="text" id="ip" placeholder="Список IP" value="<?=$_SESSION['ip']?>" /></p>
<p><select id="protected"><?=str_replace('"'.$_SESSION['protected'].'"', '"'.$_SESSION['protected'].'" selected', '<option value="0">Подтверждение входа выключено</option><option value="1">Подтверждение входа включено</option>')?></select></p>
<p>Текущий баланс: <b><?=$_SESSION['balance']?> $</b></p>
<p><button onclick="send_post('aform', 'edit', 'password.ip.protected')">Сохранить</button></p>
</div>

<?php bottom(); ?>