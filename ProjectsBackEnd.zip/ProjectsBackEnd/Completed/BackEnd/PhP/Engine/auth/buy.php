<?php
if ($_POST['services_f']) {
	$sid = array_pop($_POST);
	$price = services_price($sid);
	if (!$price) message('Ошибка при покупке услуги!');
	$price = calc_promo($sid);
	if ($price > $_SESSION['balance']) message('У вас недостаточно средств для покупки услуги!');
	$_SESSION['balance'] -= $price;
	mysqli_query($CONNECT, "UPDATE `users` SET `balance` = $_SESSION[balance] WHERE `id` = $_SESSION[id]");
	mysqli_query($CONNECT, 'INSERT INTO `history` VALUES("", "'.$_SESSION['id'].'", "Покупка услуги: '.$sid.'")');
	message('Услуга успешно приобретена.');
} else if ($_POST['promo_f']) {
	$disc = services_promo($_POST['code']);
	if (!$disc) message('Указаный вами промокод не существует!');
	$_SESSION['promo'] = $disc;
	go('services');
}
?>