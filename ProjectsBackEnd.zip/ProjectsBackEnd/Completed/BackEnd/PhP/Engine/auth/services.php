<?php top('Услуги'); ?>

<div class="textCenter"><h1>Услуги</h1></div>
<table>
<tr><td>Услуга 1</td><td>Услуга 2</td><td>Услуга 2</td></tr>
<tr><td><?=calc_promo(1)?> $</td><td><?=calc_promo(2)?> $</td><td><?=calc_promo(3)?> $</td></tr>
<tr><td><input type="hidden" id="sid1" value="1" /><button onclick="send_post('buy', 'services', 'sid1')">Купить</button></td><td><input type="hidden" id="sid2" value="2" /><button onclick="send_post('buy', 'services', 'sid2')">Купить</button></td><td><input type="hidden" id="sid3" value="3" /><button onclick="send_post('buy', 'services', 'sid3')">Купить</button></td></tr>
</table>

<div class="textCenter">
<h1>Получить скидку</h1>
<p><input type="text" placeholder="Промокод" id="code" /></p>
<button onclick="send_post('buy', 'promo', 'code')">Отправить</button>
</div>

<?php bottom(); ?>