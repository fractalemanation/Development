<?php top('Рефералы'); ?>

<div class="textCenter"><h1>Рефералы</h1></div>
<p>Ваша реферальная ссылка: <b>http://lolki.000webhostapp.com?ref=<?=$_SESSION['id']?></b></p>
<?php
$query = mysqli_query($CONNECT, "SELECT `email` FROM `users` WHERE `ref` = $_SESSION[id]");
if (!mysqli_num_rows($query)) echo '<p>Список рефералов пуст!</p>';
$i = 1;
while ($row = mysqli_fetch_assoc($query)) echo '<p>'.$i++.' '.$row['email'].'</p>';
?>

<?php bottom(); ?>