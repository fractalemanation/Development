<?php
$_SESSION['loader'] = 0;

top('История');
?>

<script type="text/javascript">
function load_history () {
	$.get('/loaderh', function (data) {
		if (data == 'empty') $('#space').text('История пуста!');
		else if (data != 'end') $('#space').append(data);
	});
}
$(document).ready(function () {
	load_history();
});
</script>

<div class="textCenter"><h1>История</h1></div>
<p><button class="buttonw" onclick="load_history()">Загрузить</button></p>
<div id="space"></div>

<?php bottom(); ?>