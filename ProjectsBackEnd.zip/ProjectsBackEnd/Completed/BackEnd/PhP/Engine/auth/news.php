<?php
$_SESSION['loader'] = 0;

top('Новости');
?>

<script type="text/javascript">
function load_history () {
	$.get('/loader', function (data) {
		if (data == 'empty') $('#space').text('Новостей нет!');
		else if (data != 'end') $('#space').append(data);
	});
}
$(document).ready(function () {
	load_history();
});
</script>

<div class="textCenter"><h1>Новости</h1></div>
<p><button class="buttonw" onclick="load_history()">Загрузить</button></p>
<div id="space"></div>
<?php if ($_SESSION['id']) if ($_SESSION['email'] == 'danyy385@gmail.com') echo '<p><textarea id="message" placeholder="Текст новости""></textarea></p><p><button class="buttonw" onclick="'."send_post('add', 'news', 'message')".'">Добавить</button></p>'; ?>

<?php bottom(); ?>