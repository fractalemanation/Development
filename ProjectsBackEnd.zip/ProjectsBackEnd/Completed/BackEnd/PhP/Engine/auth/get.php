<?php
$query = mysqli_query($CONNECT, 'SELECT `text`, `uid` FROM `chat` ORDER BY `id` DESC');
if (!mysqli_num_rows($query)) echo '<p>Сообщений в чате нет!</p>';
while ($row = mysqli_fetch_assoc($query)) {
	$user = mysqli_fetch_assoc(mysqli_query($CONNECT, "SELECT `email` FROM `users` WHERE `id` = $row[uid]"));
	echo '<div class="chat"><span>'.$user['email'].'</span>'.bbcode(nl2br(htmlspecialchars($row['text']), false)).'</div>';
}
?>