<?php top('Чат'); ?>

<script type="text/javascript">
function load_history() {
	$.ajax({
	type: "POST",
	url: "/get",
	dataType: "html",
	cache: false,
	success: function(data) {
		$('.chatBox').html(data);
	}
});
}
$(document).ready(function () {
	load_history();
});
</script>

<div class="textCenter">
<h1>Чат</h1>
<p><button class="bb" onclick="bbcode('url')">Ссылка</button> <button class="bb" onclick="bbcode('img')">Картинка</button> <button class="bb" onclick="bbcode('audio')">Аудио</button> <button class="bb" onclick="bbcode('video')">Видео</button></p>
</div>
<p><textarea id="message" placeholder="Текст сообщения"></textarea></p>
<p><button class="buttonw" onclick="send_post('add', 'chat', 'message')">Отправить</button></p>
<p><button class="buttonw" onclick="load_history()">Обновить</button></p>
<div class="chatBox"></div>

<?php bottom(); ?>