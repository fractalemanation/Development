<?php
$query = mysqli_query($CONNECT, 'SELECT `text` FROM `history` WHERE `uid` = '.$_SESSION['id'].' ORDER BY `id` DESC LIMIT '.$_SESSION['loader'].', 2');
if (!mysqli_num_rows($query)) {
	if ($_SESSION['loader'] == 0) exit('empty');
	else exit('end');
	exit;
}
$_SESSION['loader'] += 2;
while ($row = mysqli_fetch_assoc($query)) {
	echo '<p>'.nl2br(htmlspecialchars($row['text']), false).'</p>';
}
?>