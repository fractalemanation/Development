<?php
if ($_POST['chat_f']) {
	if (strlen($_POST['message']) < 1) message('Длина сообщения должна быть не меньше 1 символа!');
	$arr = array('b', 'i', 'img', 'audio', 'video');
	foreach ($arr as $val) {
		if (substr_count($_POST['message'], "[$val]") != substr_count($_POST['message'], "[/$val]")) message('Найден лишний или не закрытый тег в вашем сообщении!');
	}
	$url_arr = array(substr_count($_POST['message'], '[url='), substr_count($_POST['message'], '=name='), substr_count($_POST['message'], '[/url]'));
	if (count(array_count_values($url_arr)) != 1) message('Найден лишний или не закртый тег в вашем сообщении!');
	mysqli_query($CONNECT, 'INSERT INTO `chat` VALUES("", "'.$_SESSION['id'].'", "'.mysqli_real_escape_string($CONNECT, $_POST['message']).'")');
	go('chat');
} else if ($_POST['news_f']) {
	if (strlen($_POST['message']) < 10) message('Длина сообщения должна быть не меньше 1 символа!');
	mysqli_query($CONNECT, 'INSERT INTO `news` VALUES("", "'.mysqli_real_escape_string($CONNECT, $_POST['message']).'")');
	go('news');
}
?>