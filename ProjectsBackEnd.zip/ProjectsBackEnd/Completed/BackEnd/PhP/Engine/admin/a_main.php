<?php top() ?>

<div class="textCenter"><h1>Панель Администратора</h1></div>

<?php bottom() ?>