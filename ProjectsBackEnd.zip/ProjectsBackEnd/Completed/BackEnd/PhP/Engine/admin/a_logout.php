<?php
unset($_SESSION['admin']);
header('location: /a_login');
?>