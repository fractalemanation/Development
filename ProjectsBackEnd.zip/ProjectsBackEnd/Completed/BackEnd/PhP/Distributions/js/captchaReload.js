(function() {
	var button = document.getElementById('reload');
	button.addEventListener('click', function(e) {
		grecaptcha.reset();
	});
})();