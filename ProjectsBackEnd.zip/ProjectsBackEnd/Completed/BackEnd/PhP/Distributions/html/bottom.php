</div>
	<div class="slide">
		<div><img src="/img/banner.png" alt="Реклама" /></div>
		<div><img src="/img/banner.png" alt="Реклама" /></div>
		<div><img src="/img/banner.png" alt="Реклама" /></div>
	</div>
</div>
</body>
</html>