<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'id7605044_robean');
define('DB_PASSWORD', 'password0365');
define('DB_NAME', 'id7605044_robean');
define('RECAPTCHA_HTML', '6LeCo3YUAAAAAMLiBUYhAooXKCQZn7g4H2StvCKd');
define('RECAPTCHA_SECRET', '6LeCo3YUAAAAADr62QpDPUmm1RLpUVgY9iuUa_PZ');
define('MIN_BONUS', '10');
define('MAX_BONUS', '50');
define('PAYER_SECRET', '04TDFNC0dYgnllSU');
define('PAYER_ID', '367529406');
define('PAYER_ACCOUNT', 'P67653724');
define('MIN_PAY', '10');
define('REF_BONUS', '3');
define('ADMIN_LOGIN', 'admin');
define('ADMIN_PASSWORD', '0365');
define('ADMIN_IP', '93.171.128.53');
define('ADMIN_EMAIL', 'warcraft0385@mail.ru');
?>