<?php
init_db();
$informer1 = mysqli_fetch_row(mysqli_query($db, 'SELECT COUNT(`id`) FROM `users`'));
$informer2 = mysqli_fetch_row(mysqli_query($db, 'SELECT COUNT(`id`) FROM `users` WHERE `ref` != 0'));
$informer3 = mysqli_fetch_row(mysqli_query($db, 'SELECT SUM(`sum`) FROM `history`'));
$informer4 = mysqli_fetch_row(mysqli_query($db, 'SELECT SUM(`total`) FROM `users`'));

top('Главная страница Панели Администратора');
?>

<script src='https://www.google.com/recaptcha/api.js'></script>

<div class="textCenter"><h1>Главная страница Панели Администратора</h1></div>
<p>Всего пользователей: <?=$informer1[0]?></p>
<p>Всего рефералов: <?=$informer2[0]?></p>
<p>Всего обычных: <?=$informer1[0] - $informer2[0]?></p>
<p>Всего выплачено: <?=r2f($informer3[0])?></p>
<p>Всего выдано бонусов: <?=$informer4[0]?></p>

<?php bottom(); ?>