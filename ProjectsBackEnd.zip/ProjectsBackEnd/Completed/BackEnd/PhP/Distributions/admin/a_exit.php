<?php
unset($_SESSION['admin']);
location('a_login');
?>