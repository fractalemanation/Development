<?php
init_db();

if ($_POST['edit_f']) {
	$id = array_pop($_POST);
	if (!is_numeric($id)) message('ID пользователя указан неправильно!');
	$_SESSION['edit_id'] = $id;
	go('a_edit');
} else if ($_POST['save_f']) {
	if (!is_numeric($_POST['ref'])) message('ID реферала указано неправильно!');
	valid_name();
	valid_wallet();
	if (!is_numeric($_POST['balance'])) message('Баланс указан неправильно!');
	if (!is_numeric($_POST['total'])) message('Общее количество бонусов указано неправильно!');
	if (!filter_var($_POST['ip'], FILTER_VALIDATE_IP)) message('IP указан неправильно!');
	if ($_POST['protect'] != 1 and $_POST['protect'] != 0) message('Проверка входа по IP указана неправильно!');
	if ($_POST['ban'] != 1 and $_POST['ban'] != 0) message('Блокировка указана неправильно!');
	mysqli_query($db, "UPDATE `users` SET `ref` = $_POST[ref], `name` = '$_POST[name]', `wallet` = '$_POST[wallet]', `balance` = $_POST[balance], `total` = $_POST[total], `ip` = '$_POST[ip]', `protect` = $_POST[protect], `ban` = $_POST[ban] WHERE `id` = $_SESSION[edit_id]");
	message('Данные сохранены.');
}

$row = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM `users` WHERE `id` = $_SESSION[edit_id]"));

top('Редактор пользователя');
?>

<div class="textCenter">
	<h1>Информация о <?=$row['name']?></h1>
	<p>Реферал</p>
	<p><input type="text" id="ref" placeholder="Реферал" value="<?=$row['ref']?>" /></p>
	<p>Псевдоним</p>
	<p><input type="text" id="name" placeholder="Псевдоним" value="<?=$row['name']?>" /></p>
	<p>Кошелек</p>
	<p><input type="text" id="wallet" placeholder="Кошелек" value="<?=$row['wallet']?>" /></p>
	<p>Баланс</p>
	<p><input type="text" id="balance" placeholder="Баланс" value="<?=$row['balance']?>" /></p>
	<p>Всего получено бонусов</p>
	<p><input type="text" id="total" placeholder="Всего получено бонусов" value="<?=$row['total']?>" /></p>
	<p>IP</p>
	<p><input type="text" id="ip" placeholder="IP" value="<?=$row['ip']?>" /></p>
	<p>Проверка входа по IP</p>
	<p><select id="protect"><?=str_replace('value="'.$row['protect'].'"', 'value="'.$row['protect'].'" selected', '<option value="0">Выключено</option><option value="1">Включено</option></select>')?></p>
	<p>Блокировка</p>
	<p><select id="ban"><?=str_replace('value="'.$row['ban'].'"', 'value="'.$row['ban'].'" selected', '<option value="0">Выключено</option><option value="1">Включено</option></select>')?></p>
	<p><button onclick="send_post('a_edit', 'save', 'ref.name.wallet.balance.ip.total.protect.ban')">Сохранить</button></p>
</div>

<?php bottom() ?>