<?php
if ($_POST['save_f']) {
	$data = "<?php\r\n";
	array_shift($_POST);
	foreach ($_POST as $key => $val) $data .= "define('$key', '$val');\r\n";
	$data .= "?>";
	file_put_contents('config.php', $data);
	message('Данные сохранены.');
}

top('Редактор конфига');
?>

<div class="textCenter">
	<h1>Конфиг сайта</h1>
	<?php
	$file = file('config.php');
	array_shift($file);
	array_pop($file);
	foreach ($file as $key => $val) {
		$val = substr($val, 8);
		$val = substr($val, 0, -5);//До изменений файла -4, после изменений на сайте -5
		$exp = explode("', '", $val);
		$input .= ".$exp[0]";
		echo '<p>'.$exp[0].'</p><p><input type="text" id="'.$exp[0].'" placeholder="Поле информации" value="'.$exp[1].'" /></p>';
	}
	?>
	<p><button onclick="send_post('a_config', 'save', '<?=substr($input, 1)?>')">Сохранить</button></p>
</div>

<?php bottom() ?>