<?php top('Профиль'); ?>

<script src='https://www.google.com/recaptcha/api.js'></script>

<div class="textCenter"><h1><?=$_SESSION['name']?></h1></div>
<p>Ваш баланс: <?=r2f($_SESSION['balance'])?> руб.</p>
<p>Всего получено бонусов: <?=$_SESSION['total']?></p>
<p>Регистрационный IP: <?=$_SESSION['ip']?></p>
<p>Реферальная ссылка: http://lolki.000webhostapp.com/<?=$_SESSION['id']?></p>

<?php if ($_SESSION['protect'] == 1): ?>
<input type="hidden" id="protect" value="0" />
<button class="buttonProfile" onclick="send_post('account', 'protect', 'protect')">Выключить проверку по IP</button>
<?php else : ?>
<input type="hidden" id="protect" value="1" />
<button class="buttonProfile" onclick="send_post('account', 'protect', 'protect')">Включить проверку по IP</button>
<?php endif; ?>

<p><button class="buttonProfile" onclick="send_post('account', 'pay')">Заказать выплату</button></p>

<p><button class="buttonProfile" onclick="send_post('account', 'logout', '')">Выход из аккаунта</button></p>

<div class="textCenter"><h1>Список рефералов</h1></div>
<table>
	<tr><th>Номер</th><th>Псевдоним</th><th>Баланс</th></tr>
	<?php
	if ($_SESSION['reflist']) foreach ($_SESSION['reflist'] as $key => $val) echo '<tr><td>'.($key + 1).'</td><td>'.$val[0].'</td><td>'.r2f($val[1]).' руб.</td></tr>';
	else echo '<tr><td>N/A</td><td>N/A</td><td>N/A</td></tr>';
	?>
</table>

<?php bottom(); ?>