<?php
session_destroy();
location('login');
?>