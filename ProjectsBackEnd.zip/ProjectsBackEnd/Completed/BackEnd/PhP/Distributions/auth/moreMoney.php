<?php top('Заработать больше'); ?>

<script src='https://www.google.com/recaptcha/api.js'></script>

<div class="textCenter">
	<h1>Лотерея</h1>
	<p>Успех это засыпать с мыслью о том, что ты сделал все на что был способен.</p>
	<p><input type="text" id="lottery_sum" placeholder="Укажите сумму, которой готовы рискнуть" /></p>
	<input type="hidden" id="chest1" value="1" />
	<input type="hidden" id="chest2" value="2" />
	<input type="hidden" id="chest3" value="3" />
	<input type="hidden" id="chest4" value="4" />
	<input type="hidden" id="chest5" value="5" />
	<input type="hidden" id="chest6" value="6" />
	<input type="hidden" id="chest7" value="7" />
	<input type="hidden" id="chest8" value="8" />
	<p>
	<img onclick="send_post('account', 'lottery', 'lottery_sum.chest1')" src="/img/chest.jpg" alt="Угадай" width="175px" height="160px" />
	<img onclick="send_post('account', 'lottery', 'lottery_sum.chest2')" src="/img/chest.jpg" alt="Угадай" width="175px" height="160px" />
	<img onclick="send_post('account', 'lottery', 'lottery_sum.chest3')" src="/img/chest.jpg" alt="Угадай" width="175px" height="160px" />
	<img onclick="send_post('account', 'lottery', 'lottery_sum.chest4')" src="/img/chest.jpg" alt="Угадай" width="175px" height="160px" />
	</p>
	<p>
	<img onclick="send_post('account', 'lottery', 'lottery_sum.chest5')" src="/img/chest.jpg" alt="Угадай" width="175px" height="160px" />
	<img onclick="send_post('account', 'lottery', 'lottery_sum.chest6')" src="/img/chest.jpg" alt="Угадай" width="175px" height="160px" />
	<img onclick="send_post('account', 'lottery', 'lottery_sum.chest7')" src="/img/chest.jpg" alt="Угадай" width="175px" height="160px" />
	<img onclick="send_post('account', 'lottery', 'lottery_sum.chest8')" src="/img/chest.jpg" alt="Угадай" width="175px" height="160px" />
	</p>
	<h1>Правила игры</h1>
	<p>Укажите сумму не менее 5 рублей.</p>
	<p>Выберите сундук в котором лежит выигрыш.</p>
	<p>При выигрыше ваша ставка будет удвоенна и начислена вам на счет.</p>
</div>

<?php bottom(); ?>