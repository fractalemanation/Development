<?php
if ($_POST['send_f']) {
	if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) message('E-mail указан неправильно!');
	else if (strlen($_POST['message']) < 10 or strlen($_POST['message']) > 1000) message('Текст сообщения должен быть от 10 до 1000 символов!');
	valid_captcha();
	$result = mail(ADMIN_EMAIL, 'New Support Message', "Email: $_POST[email]"."\r\n\r\nСообщение: ".htmlspecialchars($_POST['message']));
	if ($result) message('Спасибо, ваше сообщение успешно отправлено.');
	else message('Ошибка отправки сообщения, пожалуйста повторите попытку.');
}

top('Служба поддержки');
?>

<script src='https://www.google.com/recaptcha/api.js'></script>

<div class="textCenter">
	<h1>Форма обратной связи</h1>
	<p><input type="text" id="email" placeholder="E-mail" /></p>
	<p><textarea id="message" placeholder="Сообщение"></textarea></p>
	<div class="g-recaptcha" data-sitekey="<?=RECAPTCHA_HTML?>"></div>
	<p><button onclick="send_post('support', 'send', 'email.message.g-recaptcha-response')">Отправить</button></p>
</div>

<?php bottom(); ?>