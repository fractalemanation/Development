<?php
init_db();

$num1 = 1;
$query = mysqli_query($db, "SELECT `id`, `name`, `total` FROM `users` ORDER BY `total` DESC LIMIT 10");
if (mysqli_num_rows($query)) while ($row = mysqli_fetch_assoc($query)) $str .= '<tr><td>'.$num1++.'</td><td>'.$row['name'].'</td><td>'.$row['total'].'</td></tr>';
else $str = '<tr><td>N/A</td><td>N/A</td><td>N/A</td></tr>';
file_put_contents('cache/top1.txt', $str);
$str = '';
$num2 = 1;
$query = mysqli_query($db, "SELECT * FROM `history` ORDER BY `sum` DESC LIMIT 10");
if (mysqli_num_rows($query)) while ($row = mysqli_fetch_assoc($query)) $str .= '<tr><td>'.$num2++.'</td><td>'.$row['name'].'</td><td>'.r2f($row['sum']).'</td><td>'.$row['date'].'</td></tr>';
else $str = '<tr><td>N/A</td><td>N/A</td><td>N/A</td><td>N/A</td></tr>';
file_put_contents('cache/top2.txt', $str);
?>