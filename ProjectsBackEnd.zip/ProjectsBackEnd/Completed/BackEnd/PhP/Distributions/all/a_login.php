<?php 
if ($_POST['login_f']) {
	if ($_POST['login'] != ADMIN_LOGIN or $_POST['password'] != ADMIN_PASSWORD) message('Неправильный логин или пароль!');
	else if (ADMIN_IP and $_SERVER['REMOTE_ADDR'] != ADMIN_IP) message('Доступ с вашего IP запрещен!');
	valid_captcha();
	$_SESSION['admin'] = 1;
	go('a_main');
}

top('Вход для Администратора');
?>

<script src='https://www.google.com/recaptcha/api.js'></script>

<div class="textCenter">
	<h1>Вход для Администратора</h1>
	<p><input type="text" id="login" placeholder="Логин" /></p>
	<p><input type="password" id="password" placeholder="Пароль" /></p>
	<div class="g-recaptcha" data-sitekey="<?=RECAPTCHA_HTML?>"></div>
	<p><button onclick="send_post('a_login', 'login', 'login.password.g-recaptcha-response')">Войти в панель Администратора</button></p>
</div>

<?php bottom(); ?>