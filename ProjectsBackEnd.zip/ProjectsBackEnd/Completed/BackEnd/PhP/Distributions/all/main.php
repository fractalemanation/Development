<?php top('Главная страница'); ?>

<script src='https://www.google.com/recaptcha/api.js'></script>

<div class="textCenter">
	<h1>Получи бонус</h1>
	<p>Получи бесплатно бонус до 0.1 руб.</p>
	<div class="g-recaptcha" data-sitekey="<?=RECAPTCHA_HTML?>"></div>
	<p><button id="reload" onclick="send_post('account', 'bonus', 'g-recaptcha-response')">Получить</button></p>

	<h1>ТОП самых активных пользователей</h1>
	<table>
		<tr><th>Номер</th><th>Псевдоним</th><th>Получено бонусов</th></tr>
		<?php include 'cache/top1.txt'; ?>
	</table>

	<h1>Последние выплаты пользователям</h1>
	<table>
		<tr><th>Номер</th><th>Псевдоним</th><th>Сумма</th><th>Дата</th></tr>
		<?php include 'cache/top2.txt'; ?>
	</table>
</div>
<script src="/js/captchaReload.js"></script>

<?php bottom(); ?>